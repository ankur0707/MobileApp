import React, { useState, useEffect, useMemo, useRef } from 'react';
import {
  Candle,
  ReferencePattern,
  HistoricalMatchItem,
  AutoScannerItem,
  AlertItem,
  SectionVisibility,
  DemoPosition,
  DemoTrade
} from './types/trading';
import {
  generateInitialCandles,
  generateNextCandle,
  lockReferencePattern,
  computePatternIntegrity,
  computeWinLossStructure,
  computeTradeHealth,
  computeFutureProjections,
  computeEvolutionTimeline,
  computeTransitionDetector,
  generateHistoricalMatches,
  computeAIDecisionCenter,
  generateAutoScannerItems,
  generateInitialAlerts,
  fetchRealHistoricalCandles
} from './services/patternEngine';
import { io } from 'socket.io-client';
import { Navbar } from './components/Navbar';
import { Sidebar } from './components/Sidebar';
import { Footer } from './components/Footer';
import { ExplorerView } from './views/ExplorerView';
import { DashboardView } from './views/DashboardView';
import { TradeJournalView } from './views/TradeJournalView';
import { SynchronizedChartModal } from './components/SynchronizedChartModal';
import { ReferenceChartModal } from './components/ReferenceChartModal';
import { AllMatchesModal } from './components/AllMatchesModal';
import { LayoutCustomizer } from './components/LayoutCustomizer';
import { ApiSettingsModal } from './components/ApiSettingsModal';
import { PatternMatchSettingsModal } from './components/PatternMatchSettingsModal';
import { SymbolSearchModal } from './components/SymbolSearchModal';
import { MatchCriteriaSettings, DEFAULT_MATCH_CRITERIA } from './types/trading';
import { ErrorBoundary } from './components/ErrorBoundary';

export function App() {
  // Navigation Active Sidebar Tab
  const [activeTab, setActiveTab] = useState<string>('explorer');
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState<boolean>(false);

  // Asset & Timeframe Selectors (Persisted in localStorage across refreshes)
  const [selectedAsset, setSelectedAsset] = useState<string>(() => {
    try {
      return localStorage.getItem('ai_selected_asset') || 'NIFTY 50';
    } catch (_) {
      return 'NIFTY 50';
    }
  });

  const [selectedTimeframe, setSelectedTimeframe] = useState<string>(() => {
    try {
      return localStorage.getItem('ai_selected_timeframe') || '5m';
    } catch (_) {
      return '5m';
    }
  });

  const [selectedRange, setSelectedRange] = useState<string>(() => {
    try {
      return localStorage.getItem('ai_selected_range') || '1y';
    } catch (_) {
      return '1y';
    }
  });

  // Paper Trading State (Persisted in localStorage for Trading Journal)
  const [balance, setBalance] = useState<number>(() => {
    try {
      const saved = localStorage.getItem('ai_paper_balance');
      return saved ? JSON.parse(saved) : 500000;
    } catch (_) {
      return 500000;
    }
  });

  const [tradeHistory, setTradeHistory] = useState<DemoTrade[]>(() => {
    try {
      const saved = localStorage.getItem('ai_trade_journal');
      return saved ? JSON.parse(saved) : [];
    } catch (_) {
      return [];
    }
  });

  // Candle Series & Locked Reference State
  const [candles, setCandles] = useState<Candle[]>([]);
  const [referencePattern, setReferencePattern] = useState<ReferencePattern | null>(null);
  const [hoveredCandle, setHoveredCandle] = useState<Candle | null>(null);

  // Live Candle Simulator & Socket status
  const [isSimulating, setIsSimulating] = useState<boolean>(true); // Start live stream by default
  const [isSocketConnected, setIsSocketConnected] = useState<boolean>(false);
  const [isMarketOpen, setIsMarketOpen] = useState<boolean>(false);
  const [marketStatusText, setMarketStatusText] = useState<string>('MARKET CLOSED');

  // Persistent Socket Connection
  const socketRef = useRef<any>(null);

  // Initialize socket once on mount
  useEffect(() => {
    const socket = io('http://localhost:4000');
    socketRef.current = socket;

    socket.on('connect', () => {
      setIsSocketConnected(true);
      socket.emit('subscribe_symbol', { symbol: selectedAsset });
    });

    socket.on('disconnect', () => {
      setIsSocketConnected(false);
    });

    return () => {
      socket.disconnect();
    };
  }, []);

  // Persist timeframe + range to localStorage when they change
  useEffect(() => {
    try { localStorage.setItem('ai_selected_timeframe', selectedTimeframe); } catch (_) {}
  }, [selectedTimeframe]);

  useEffect(() => {
    try { localStorage.setItem('ai_selected_range', selectedRange); } catch (_) {}
  }, [selectedRange]);

  // Fetch Data when Asset, Timeframe, or Range changes
  useEffect(() => {
    let isMounted = true;

    async function loadData() {
      // 1. Tell socket to switch active symbol
      if (socketRef.current?.connected) {
        socketRef.current.emit('subscribe_symbol', { symbol: selectedAsset });
      }

      // 2. Fetch Market Status
      try {
        const statusRes = await fetch(`http://localhost:4000/api/market-status?symbol=${encodeURIComponent(selectedAsset)}`);
        if (statusRes.ok) {
          const statusData = await statusRes.json();
          if (isMounted) {
            setIsMarketOpen(statusData.isOpen ?? false);
            setMarketStatusText(statusData.statusText || (statusData.isOpen ? 'LIVE' : 'MARKET CLOSED'));
          }
        }
      } catch (e) {
        const isCrypto = selectedAsset.includes('BTC') || selectedAsset.includes('ETH') || selectedAsset.includes('SOL');
        if (isMounted) {
          setIsMarketOpen(isCrypto);
          setMarketStatusText(isCrypto ? '24/7 LIVE' : 'MARKET CLOSED');
        }
      }

      // 3. Fetch Historical Real Data from Backend (with selected range)
      const history = await fetchRealHistoricalCandles(selectedAsset, selectedTimeframe, selectedRange);
      if (isMounted) {
        setCandles(history);
      }
    }

    loadData();

    return () => {
      isMounted = false;
    };
  }, [selectedAsset, selectedTimeframe, selectedRange]);

  // Live Candle Socket Listener
  useEffect(() => {
    const socket = socketRef.current;
    if (!socket) return;

    const handleLiveCandle = (newCandle: Candle & { asset?: string; isFinal: boolean; isMarketOpen?: boolean; marketStatus?: string; officialClose?: number }) => {
      // STRICT FILTER: If candle belongs to a different asset, ignore!
      if (newCandle.asset && newCandle.asset !== selectedAsset) return;

      const isOpen = newCandle.isMarketOpen ?? false;
      setIsMarketOpen(isOpen);
      if (newCandle.marketStatus) setMarketStatusText(newCandle.marketStatus);

      // When market is CLOSED: Never perturb the chart! Lock to official close
      if (!isOpen) {
        const offClose = newCandle.officialClose;
        if (typeof offClose === 'number') {
          setCandles(prev => {
            if (prev.length === 0) return prev;
            const last = prev[prev.length - 1];
            if (Math.abs(last.close - offClose) > 0.001) {
              const updated = [...prev];
              updated[updated.length - 1] = {
                ...last,
                close: offClose,
                high: Math.max(last.high, offClose),
                low: Math.min(last.low, offClose)
              };
              return updated;
            }
            return prev;
          });
        }
        return;
      }

      // When market is OPEN: update live candle
      if (!isSimulating) return; // Ignore live ticks if not streaming

      setCandles(prev => {
        if (prev.length === 0) return [newCandle];
        
        const updated = [...prev];
        const lastCandle = updated[updated.length - 1];

        // Check if timestamp falls in the same minute
        const lastMin = Math.floor(new Date(lastCandle.time).getTime() / 60000);
        const newMin = Math.floor(new Date(newCandle.time).getTime() / 60000);

        if (lastMin === newMin) {
          newCandle.index = lastCandle.index;
          updated[updated.length - 1] = newCandle;
        } else {
          // New minute, new candle
          newCandle.index = lastCandle.index + 1;
          updated.push(newCandle);
          if (updated.length > 500) updated.shift();
        }
        return updated;
      });
    };

    socket.on('live_candle', handleLiveCandle);

    return () => {
      socket.off('live_candle', handleLiveCandle);
    };
  }, [selectedAsset, isSimulating]);

  // Fallback ticker: Only runs if backend socket is disconnected AND market is open
  useEffect(() => {
    const fallbackInterval = setInterval(() => {
      if (!isSimulating || isSocketConnected || !isMarketOpen) return;
      setCandles(prev => {
        if (prev.length === 0) return prev;
        const updated = [...prev];
        const lastCandle = { ...updated[updated.length - 1] };
        
        const delta = (Math.random() - 0.49) * (lastCandle.close * 0.0004);
        const newClose = Number((lastCandle.close + delta).toFixed(2));
        lastCandle.close = newClose;
        lastCandle.high = Number(Math.max(lastCandle.high, newClose).toFixed(2));
        lastCandle.low = Number(Math.min(lastCandle.low, newClose).toFixed(2));
        lastCandle.volume += Math.floor(10 + Math.random() * 50);
        lastCandle.isBullish = lastCandle.close >= lastCandle.open;
        
        updated[updated.length - 1] = lastCandle;
        return updated;
      });
    }, 600);

    return () => clearInterval(fallbackInterval);
  }, [isSimulating, isSocketConnected, isMarketOpen]);

  // Safe Asset Switching Handler with Persistence
  const handleSelectAsset = (newAsset: string) => {
    if (newAsset === selectedAsset) return;
    setReferencePattern(null);
    setCandles([]);
    setSelectedAsset(newAsset);
    try {
      localStorage.setItem('ai_selected_asset', newAsset);
    } catch (_) {}
  };

  const handleSelectTimeframe = (newTf: string) => {
    setSelectedTimeframe(newTf);
    try {
      localStorage.setItem('ai_selected_timeframe', newTf);
    } catch (_) {}
  };

  // Modal Inspector State
  const [selectedMatchModal, setSelectedMatchModal] = useState<HistoricalMatchItem | null>(null);

  // Section Visibility Settings (All Default Visible)
  const [visibility, setVisibility] = useState<SectionVisibility>({
    referencePattern: true,
    patternIntegrity: true,
    winLossStructure: true,
    tradeHealth: true,
    futureProjections: true,
    evolutionTimeline: true,
    liveRanking: true,
    transitionDetector: true,
    matchGallery: true,
    aiDecision: true,
    candleInspector: true
  });
  const [isCustomizerOpen, setIsCustomizerOpen] = useState<boolean>(false);
  const [isApiModalOpen, setIsApiModalOpen] = useState<boolean>(false);
  const [isMatchSettingsModalOpen, setIsMatchSettingsModalOpen] = useState<boolean>(false);
  const [isSymbolSearchOpen, setIsSymbolSearchOpen] = useState<boolean>(false);
  const [isReferenceChartModalOpen, setIsReferenceChartModalOpen] = useState<boolean>(false);
  const [isAllMatchesModalOpen, setIsAllMatchesModalOpen] = useState<boolean>(false);

  // AI Pattern Match Criteria & Technical Indicator Settings
  const [matchCriteria, setMatchCriteria] = useState<MatchCriteriaSettings>(() => {
    try {
      const saved = localStorage.getItem('ai_match_criteria_settings');
      return saved ? JSON.parse(saved) : DEFAULT_MATCH_CRITERIA;
    } catch (_) {
      return DEFAULT_MATCH_CRITERIA;
    }
  });

  const handleSaveMatchCriteria = (newCriteria: MatchCriteriaSettings) => {
    setMatchCriteria(newCriteria);
    try {
      localStorage.setItem('ai_match_criteria_settings', JSON.stringify(newCriteria));
    } catch (_) {}
  };

  // Scanner & Alert State
  const [scannerItems, setScannerItems] = useState<AutoScannerItem[]>(() => generateAutoScannerItems());
  const [alerts, setAlerts] = useState<AlertItem[]>(() => generateInitialAlerts());

  // Pre-lock 12 candles automatically on load to mirror screenshot setup exactly!
  useEffect(() => {
    if (!referencePattern && candles.length >= 25) {
      const initialSlice = candles.slice(15, 27); // 12 candles
      const ref = lockReferencePattern(initialSlice, selectedAsset, selectedTimeframe);
      setReferencePattern(ref);
    }
  }, [candles, referencePattern, selectedAsset, selectedTimeframe]);

  // Handler: Lock Reference Pattern
  const handleLockReference = (selectedCandleSlice: Candle[]) => {
    const ref = lockReferencePattern(selectedCandleSlice, selectedAsset, selectedTimeframe);
    setReferencePattern(ref);
  };

  const handleClearReference = () => {
    setReferencePattern(null);
  };

  // Handler: Close Next Candle (+1)
  const handleStepNextCandle = () => {
    setCandles(prev => {
      const nextCandle = generateNextCandle(prev, selectedAsset);
      return [...prev, nextCandle];
    });
  };

  // Handler: Reset Simulation
  const handleResetSimulation = () => {
    setIsSimulating(false);
    const resetCandles = generateInitialCandles(60, selectedAsset);
    setCandles(resetCandles);
    const initialSlice = resetCandles.slice(15, 27);
    const ref = lockReferencePattern(initialSlice, selectedAsset, selectedTimeframe);
    setReferencePattern(ref);
  };

  // Visibility Control Handlers
  const handleToggleSection = (key: keyof SectionVisibility) => {
    setVisibility(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const handleShowAllSections = () => {
    setVisibility({
      referencePattern: true,
      patternIntegrity: true,
      winLossStructure: true,
      tradeHealth: true,
      futureProjections: true,
      evolutionTimeline: true,
      liveRanking: true,
      transitionDetector: true,
      matchGallery: true,
      aiDecision: true,
      candleInspector: true
    });
  };

  // Paper Trading & Journal Handlers
  const handleLogPaperTrade = (trade: DemoTrade) => {
    setTradeHistory(prev => {
      const updated = [trade, ...prev];
      try {
        localStorage.setItem('ai_trade_journal', JSON.stringify(updated));
      } catch (_) {}
      return updated;
    });

    setBalance(prev => {
      const updated = Number((prev + trade.pnl).toFixed(2));
      try {
        localStorage.setItem('ai_paper_balance', JSON.stringify(updated));
      } catch (_) {}
      return updated;
    });
  };

  const handleClearJournal = () => {
    setTradeHistory([]);
    try {
      localStorage.removeItem('ai_trade_journal');
    } catch (_) {}
  };

  const handleHideAllSections = () => {
    setVisibility({
      referencePattern: false,
      patternIntegrity: false,
      winLossStructure: false,
      tradeHealth: false,
      futureProjections: false,
      evolutionTimeline: false,
      liveRanking: false,
      transitionDetector: false,
      matchGallery: false,
      aiDecision: false,
      candleInspector: false
    });
  };

  // REAL-TIME COMPUTATION ENGINES
  const integrityMetrics = useMemo(() => {
    if (!referencePattern) return null;
    return computePatternIntegrity(referencePattern, candles);
  }, [referencePattern, candles]);

  const winLossMetrics = useMemo(() => {
    if (!referencePattern || !integrityMetrics) return null;
    return computeWinLossStructure(referencePattern, integrityMetrics);
  }, [referencePattern, integrityMetrics]);

  const tradeHealth = useMemo(() => {
    if (!referencePattern || !integrityMetrics || !winLossMetrics) return null;
    return computeTradeHealth(referencePattern, integrityMetrics, winLossMetrics);
  }, [referencePattern, integrityMetrics, winLossMetrics]);

  const futureProjections = useMemo(() => {
    if (!referencePattern || !tradeHealth) return null;
    return computeFutureProjections(referencePattern, tradeHealth);
  }, [referencePattern, tradeHealth]);

  const evolutionSteps = useMemo(() => {
    if (!referencePattern) return [];
    return computeEvolutionTimeline(referencePattern, candles);
  }, [referencePattern, candles]);

  const transitionMetrics = useMemo(() => {
    if (!referencePattern || !integrityMetrics || !winLossMetrics) return null;
    return computeTransitionDetector(referencePattern, integrityMetrics, winLossMetrics);
  }, [referencePattern, integrityMetrics, winLossMetrics]);

  const historicalMatches = useMemo(() => {
    if (!referencePattern) return [];
    return generateHistoricalMatches(referencePattern, matchCriteria);
  }, [referencePattern, matchCriteria]);

  const aiDecision = useMemo(() => {
    if (!referencePattern || !integrityMetrics || !winLossMetrics || !tradeHealth) return null;
    return computeAIDecisionCenter(referencePattern, integrityMetrics, winLossMetrics, tradeHealth);
  }, [referencePattern, integrityMetrics, winLossMetrics, tradeHealth]);

  return (
    <div className="h-screen bg-[#070A10] text-slate-100 flex flex-col overflow-hidden font-mono selection:bg-cyan-500 selection:text-black">
      {/* Top Header Bar */}
      <Navbar
        selectedAsset={selectedAsset}
        setSelectedAsset={handleSelectAsset}
        selectedTimeframe={selectedTimeframe}
        setSelectedTimeframe={handleSelectTimeframe}
        selectedRange={selectedRange}
        setSelectedRange={setSelectedRange}
        isSimulating={isSimulating}
        setIsSimulating={setIsSimulating}
        onStepNextCandle={handleStepNextCandle}
        onResetSimulation={handleResetSimulation}
        onOpenCustomizer={() => setIsCustomizerOpen(true)}
        onOpenMatchCustomizer={() => setIsMatchSettingsModalOpen(true)}
        onOpenApiSettings={() => setIsApiModalOpen(true)}
        onOpenSymbolSearch={() => setIsSymbolSearchOpen(true)}
        candles={candles}
        isSocketConnected={isSocketConnected}
        isMarketOpen={isMarketOpen}
        marketStatusText={marketStatusText}
      />

      {/* Main Body Split: Left Sidebar + Right Workspace Area */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left Navigation Sidebar */}
        <Sidebar
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          onResetPattern={handleResetSimulation}
          isCollapsed={isSidebarCollapsed}
          onToggleCollapse={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
        />

        {/* Right Main Content Workspace */}
        <main className="flex-1 overflow-y-auto p-4 space-y-4 relative scroll-smooth">
          {activeTab === 'dashboard' ? (
            <DashboardView
              scannerItems={scannerItems}
              alerts={alerts}
              onClearAlerts={() => setAlerts([])}
              onSelectScannerSymbol={(symbol, timeframe) => {
                handleSelectAsset(symbol);
                setSelectedTimeframe(timeframe);
                setActiveTab('explorer');
              }}
              topMatches={historicalMatches}
              onSelectMatch={(match) => setSelectedMatchModal(match)}
              onGoToExplorer={() => setActiveTab('explorer')}
            />
          ) : activeTab === 'journal' ? (
            <TradeJournalView 
              tradeHistory={tradeHistory}
              balance={balance}
              onClearJournal={handleClearJournal}
            />
          ) : (
            <ExplorerView
              asset={selectedAsset}
              timeframe={selectedTimeframe}
              candles={candles}
              referencePattern={referencePattern}
              hoveredCandle={hoveredCandle}
              setHoveredCandle={setHoveredCandle}
              onLockReference={handleLockReference}
              onClearReference={handleClearReference}
              isSimulating={isSimulating}
              visibility={visibility}
              onToggleVisibility={handleToggleSection}
              isMarketOpen={isMarketOpen}
              isSocketConnected={isSocketConnected}
              onLogPaperTrade={handleLogPaperTrade}


              // Navigation & Modals
              onOpenReferenceChart={() => setIsReferenceChartModalOpen(true)}
              onViewAllMatches={() => setIsAllMatchesModalOpen(true)}
              onOpenApiSettings={() => setIsApiModalOpen(true)}

              integrityMetrics={integrityMetrics}
              winLossMetrics={winLossMetrics}
              tradeHealth={tradeHealth}
              futureProjections={futureProjections}
              evolutionSteps={evolutionSteps}
              transitionMetrics={transitionMetrics}
              historicalMatches={historicalMatches}
              aiDecision={aiDecision}
              onSelectMatchItem={(match) => setSelectedMatchModal(match)}
            />
          )}
        </main>
      </div>

      {/* Bottom Status Bar */}
      <Footer />

      {/* Layout Display Customizer Modal */}
      <LayoutCustomizer
        isOpen={isCustomizerOpen}
        onClose={() => setIsCustomizerOpen(false)}
        visibility={visibility}
        onToggleSection={handleToggleSection}
        onShowAll={handleShowAllSections}
        onHideAll={handleHideAllSections}
      />

      {/* Synchronized Comparative Chart Modal */}
      <SynchronizedChartModal
        match={selectedMatchModal}
        onClose={() => setSelectedMatchModal(null)}
        referencePattern={referencePattern}
        currentCandles={candles}
      />

      {/* Reference Pattern Full Chart Modal (User Request 1) */}
      <ReferenceChartModal
        isOpen={isReferenceChartModalOpen}
        onClose={() => setIsReferenceChartModalOpen(false)}
        refPattern={referencePattern}
      />

      {/* All Historical Matches Archive Modal (User Request 2) */}
      <AllMatchesModal
        isOpen={isAllMatchesModalOpen}
        onClose={() => setIsAllMatchesModalOpen(false)}
        matches={historicalMatches}
        onSelectMatch={(match) => setSelectedMatchModal(match)}
      />

      {/* API Broker Connection Modal */}
      <ApiSettingsModal
        isOpen={isApiModalOpen}
        onClose={() => setIsApiModalOpen(false)}
      />

      {/* AI Pattern Match Criteria & Technical Indicators Modal */}
      <PatternMatchSettingsModal
        isOpen={isMatchSettingsModalOpen}
        onClose={() => setIsMatchSettingsModalOpen(false)}
        criteria={matchCriteria}
        onSave={handleSaveMatchCriteria}
      />

      {/* Universal Stock & Index Search Modal */}
      <SymbolSearchModal
        isOpen={isSymbolSearchOpen}
        onClose={() => setIsSymbolSearchOpen(false)}
        currentSymbol={selectedAsset}
        onSelectSymbol={(newSym) => {
          handleSelectAsset(newSym);
        }}
      />
    </div>
  );
}

export default App;

import React from 'react';
import { AutoScannerItem, AlertItem, HistoricalMatchItem } from '../types/trading';
import { AutoPatternScanner } from '../components/AutoPatternScanner';
import { AlertCenter } from '../components/AlertCenter';
import { LayoutDashboard, TrendingUp, Cpu, Radar, ShieldCheck, ArrowRight, Zap, Trophy } from 'lucide-react';

interface DashboardViewProps {
  scannerItems: AutoScannerItem[];
  alerts: AlertItem[];
  onClearAlerts: () => void;
  onSelectScannerSymbol: (symbol: string, timeframe: string) => void;
  topMatches: HistoricalMatchItem[];
  onSelectMatch: (match: HistoricalMatchItem) => void;
  onGoToExplorer: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  scannerItems,
  alerts,
  onClearAlerts,
  onSelectScannerSymbol,
  topMatches,
  onSelectMatch,
  onGoToExplorer
}) => {
  return (
    <div className="space-y-6 pb-12 font-mono">
      {/* Hero Welcome Banner */}
      <div className="glass-panel-glow-cyan rounded-2xl p-6 border border-cyan-500/40 relative overflow-hidden flex flex-wrap items-center justify-between gap-4">
        <div className="space-y-1.5 max-w-2xl">
          <div className="flex items-center space-x-2">
            <Cpu className="w-5 h-5 text-cyan-400 animate-pulse" />
            <span className="text-xs font-extrabold uppercase tracking-wider text-cyan-300">
              Institutional AI Decision Engine Active
            </span>
          </div>
          <h2 className="text-xl font-extrabold text-white">
            AI Pattern Analyzer Pro — Historical Intelligence Suite
          </h2>
          <p className="text-xs text-slate-300 leading-relaxed font-sans">
            Continuous historical pattern matching engine. Select any chart candles to lock the reference vector and perform real-time structural recalculations after every live candle close.
          </p>
        </div>

        <button
          onClick={onGoToExplorer}
          className="px-5 py-2.5 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-black font-extrabold text-xs rounded-xl shadow-xl shadow-cyan-500/25 flex items-center space-x-2 transition-all transform hover:scale-105"
        >
          <span>Open Pattern Explorer Workspace</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>

      {/* Overview Stat Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-xs">
        <div className="glass-panel rounded-xl p-4 border border-slate-800 flex items-center space-x-3">
          <div className="w-10 h-10 rounded-lg bg-emerald-950 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
            <Trophy className="w-5 h-5" />
          </div>
          <div>
            <span className="text-slate-400 text-[10px] block">DATABASE A (WINNING)</span>
            <span className="text-lg font-extrabold text-slate-100">8,420 Patterns</span>
          </div>
        </div>

        <div className="glass-panel rounded-xl p-4 border border-slate-800 flex items-center space-x-3">
          <div className="w-10 h-10 rounded-lg bg-rose-950 border border-rose-500/40 flex items-center justify-center text-rose-400">
            <Zap className="w-5 h-5" />
          </div>
          <div>
            <span className="text-slate-400 text-[10px] block">DATABASE B (LOSING)</span>
            <span className="text-lg font-extrabold text-slate-100">5,190 Patterns</span>
          </div>
        </div>

        <div className="glass-panel rounded-xl p-4 border border-slate-800 flex items-center space-x-3">
          <div className="w-10 h-10 rounded-lg bg-cyan-950 border border-cyan-500/40 flex items-center justify-center text-cyan-400">
            <Radar className="w-5 h-5" />
          </div>
          <div>
            <span className="text-slate-400 text-[10px] block">ACTIVE SCANNER SYMBOLS</span>
            <span className="text-lg font-extrabold text-cyan-400">5 Markets Live</span>
          </div>
        </div>

        <div className="glass-panel rounded-xl p-4 border border-slate-800 flex items-center space-x-3">
          <div className="w-10 h-10 rounded-lg bg-purple-950 border border-purple-500/40 flex items-center justify-center text-purple-400">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <span className="text-slate-400 text-[10px] block">AVG AI CONFIDENCE</span>
            <span className="text-lg font-extrabold text-purple-400">88.5%</span>
          </div>
        </div>
      </div>

      {/* Auto Pattern Scanner Section */}
      <AutoPatternScanner
        scannerItems={scannerItems}
        onSelectScannerSymbol={onSelectScannerSymbol}
      />

      {/* Alerts Feed & Top Historical Database Highlights */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <AlertCenter alerts={alerts} onClearAlerts={onClearAlerts} />

        <div className="glass-panel rounded-xl p-5 border border-slate-800 space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="text-sm font-bold text-slate-100">Top High-Probability Matches</h3>
            <span className="text-xs text-cyan-400">Database A Alignment</span>
          </div>

          <div className="space-y-2.5">
            {topMatches.slice(0, 3).map(match => (
              <div
                key={match.id}
                onClick={() => onSelectMatch(match)}
                className="bg-slate-950/80 p-3 rounded-lg border border-slate-800 hover:border-cyan-500/50 transition-all cursor-pointer flex items-center justify-between"
              >
                <div>
                  <span className="font-bold text-slate-200 block text-xs">{match.patternName}</span>
                  <span className="text-[10px] text-slate-500">{match.asset} • {match.date}</span>
                </div>
                <div className="text-right">
                  <span className="text-xs font-extrabold text-cyan-400 block">{match.historicalMatchPct}% MATCH</span>
                  <span className="text-[10px] text-emerald-400 font-bold">Win Rate: {match.winRatePct}%</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

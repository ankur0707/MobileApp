﻿import React from 'react';
import { DemoTrade } from '../types/trading';
import { ListChecks, TrendingUp, TrendingDown, Clock, Activity, Calendar, Trash2 } from 'lucide-react';

interface TradeJournalViewProps {
  tradeHistory: DemoTrade[];
  balance: number;
  onClearJournal?: () => void;
}

export const TradeJournalView: React.FC<TradeJournalViewProps> = ({ tradeHistory, balance, onClearJournal }) => {
  const totalTrades = tradeHistory.length;
  const winningTrades = tradeHistory.filter(t => t.pnl > 0).length;
  const winRate = totalTrades > 0 ? (winningTrades / totalTrades) * 100 : 0;
  
  const totalProfit = tradeHistory.filter(t => t.pnl > 0).reduce((acc, t) => acc + t.pnl, 0);
  const totalLoss = tradeHistory.filter(t => t.pnl < 0).reduce((acc, t) => acc + t.pnl, 0);
  const netPnL = totalProfit + totalLoss;

  return (
    <div className="flex flex-col gap-6 font-mono w-full max-w-[1200px] mx-auto pb-10 select-none">
      
      {/* Header Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="glass-panel p-5 rounded-xl border border-slate-800 flex flex-col justify-center">
          <div className="text-slate-500 text-xs font-bold mb-1 tracking-widest uppercase">VIRTUAL TRADING CAPITAL</div>
          <div className="text-2xl font-black text-slate-100">
            ₹{balance.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
        </div>
        
        <div className="glass-panel p-5 rounded-xl border border-slate-800 flex flex-col justify-center">
          <div className="text-slate-500 text-xs font-bold mb-1 tracking-widest uppercase">TOTAL NET PnL</div>
          <div className={`text-2xl font-black ${netPnL >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
            {netPnL >= 0 ? '+' : ''}₹{netPnL.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
        </div>

        <div className="glass-panel p-5 rounded-xl border border-slate-800 flex flex-col justify-center">
          <div className="text-slate-500 text-xs font-bold mb-1 tracking-widest uppercase">HISTORICAL WIN RATE</div>
          <div className="text-2xl font-black text-cyan-400">
            {winRate.toFixed(1)}%
          </div>
          <div className="text-xs text-slate-500 mt-1">{winningTrades} Wins / {totalTrades} Closed Trades</div>
        </div>

        <div className="glass-panel p-5 rounded-xl border border-slate-800 flex flex-col justify-center">
          <div className="text-slate-500 text-xs font-bold mb-1 tracking-widest uppercase">PROFIT FACTOR</div>
          <div className="text-2xl font-black text-purple-400">
            {Math.abs(totalLoss) > 0 ? (totalProfit / Math.abs(totalLoss)).toFixed(2) : (totalProfit > 0 ? '∞' : '0.00')}
          </div>
        </div>
      </div>

      {/* Trade List */}
      <div className="glass-panel rounded-xl border border-slate-800 overflow-hidden">
        <div className="bg-slate-900/50 p-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <ListChecks className="w-5 h-5 text-cyan-400" />
            <h2 className="font-bold tracking-wider text-slate-200 uppercase text-sm">PAPER TRADING JOURNAL LOG</h2>
          </div>
          {onClearJournal && tradeHistory.length > 0 && (
            <button
              onClick={() => {
                if (window.confirm('Kya aap trading journal ka saara history clear karna chahte hain?')) {
                  onClearJournal();
                }
              }}
              className="text-xs font-bold text-rose-400 hover:text-rose-300 hover:bg-rose-950/40 border border-rose-800/40 px-2.5 py-1 rounded transition-colors flex items-center space-x-1.5 cursor-pointer"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Clear History</span>
            </button>
          )}
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-900/30 text-[10px] uppercase tracking-widest text-slate-500">
                <th className="p-4 font-bold">Execution Time</th>
                <th className="p-4 font-bold">Asset / Stock</th>
                <th className="p-4 font-bold">Side</th>
                <th className="p-4 font-bold">Entry Price</th>
                <th className="p-4 font-bold">Exit Price</th>
                <th className="p-4 font-bold text-right">Net Realized PnL (₹)</th>
              </tr>
            </thead>
            <tbody className="text-sm">
              {tradeHistory.length === 0 ? (
                <tr>
                  <td colSpan={6} className="p-8 text-center text-slate-500 italic">
                    Trading journal is empty. Paper trading terminal me trade close karne par saara history yahan automatic save hoga!
                  </td>
                </tr>
              ) : (
                tradeHistory.map((trade) => (
                  <tr key={trade.id} className="border-b border-slate-800/50 hover:bg-slate-800/20 transition-colors">
                    <td className="p-4 text-slate-400">
                      <div className="flex items-center space-x-2 text-xs">
                        <Calendar className="w-3.5 h-3.5" />
                        <span>{new Date(trade.closeTime).toLocaleString('en-IN')}</span>
                      </div>
                    </td>
                    <td className="p-4 font-bold text-slate-200">
                      <div className="flex items-center space-x-2">
                        <span>{trade.asset}</span>
                        {(trade as any).isDemat && (
                          <span className="text-[9px] bg-rose-950 text-rose-300 border border-rose-500/40 px-1 py-0.2 rounded font-bold">
                            DEMAT
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="p-4">
                      <span className={`text-[10px] px-2 py-0.5 rounded border font-bold ${
                        trade.type === 'LONG' 
                          ? 'bg-emerald-950/50 border-emerald-500/30 text-emerald-400'
                          : 'bg-rose-950/50 border-rose-500/30 text-rose-400'
                      }`}>
                        {trade.type}
                      </span>
                    </td>
                    <td className="p-4 text-slate-300 font-mono">₹{trade.entryPrice.toFixed(2)}</td>
                    <td className="p-4 text-slate-300 font-mono">₹{trade.exitPrice.toFixed(2)}</td>
                    <td className={`p-4 font-bold text-right font-mono ${trade.pnl >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                      {trade.pnl >= 0 ? '+' : ''}₹{trade.pnl.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
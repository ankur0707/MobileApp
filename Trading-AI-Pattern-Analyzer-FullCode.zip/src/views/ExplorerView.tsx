import React from 'react';
import { Candle, ReferencePattern, PatternIntegrityMetrics, WinLossStructureMetrics, TradeHealthMetrics, FutureProjectionMetrics, PatternEvolutionStep, TransitionMetrics, HistoricalMatchItem, AIDecisionSummary, SectionVisibility } from '../types/trading';
import { InteractiveChart } from '../components/InteractiveChart';
import { ReferencePatternSection } from '../components/ReferencePatternSection';
import { PatternIntegritySection } from '../components/PatternIntegritySection';
import { WinLossStructureSection } from '../components/WinLossStructureSection';
import { TradeHealthSection } from '../components/TradeHealthSection';
import { FutureProjectionSection } from '../components/FutureProjectionSection';
import { PatternEvolutionTimeline } from '../components/PatternEvolutionTimeline';
import { LiveHistoricalRanking } from '../components/LiveHistoricalRanking';
import { TransitionDetectorSection } from '../components/TransitionDetectorSection';
import { MatchGallerySection } from '../components/MatchGallerySection';
import { AIDecisionCenter } from '../components/AIDecisionCenter';
import { LiveTradingPanel } from '../components/LiveTradingPanel';
import { ErrorBoundary } from '../components/ErrorBoundary';

interface ExplorerViewProps {
  candles: Candle[];
  referencePattern: ReferencePattern | null;
  onLockReference: (candles: Candle[]) => void;
  onClearReference: () => void;
  hoveredCandle: Candle | null;
  setHoveredCandle: (candle: Candle | null) => void;
  asset: string;
  timeframe: string;
  integrityMetrics: PatternIntegrityMetrics | null;
  winLossMetrics: WinLossStructureMetrics | null;
  tradeHealth: TradeHealthMetrics | null;
  futureProjections: FutureProjectionMetrics | null;
  evolutionSteps: PatternEvolutionStep[];
  transitionMetrics: TransitionMetrics | null;
  historicalMatches: HistoricalMatchItem[];
  aiDecision: AIDecisionSummary | null;
  onSelectMatchItem: (match: HistoricalMatchItem) => void;
  visibility: SectionVisibility;
  isSimulating: boolean;
  onToggleVisibility: (key: keyof SectionVisibility) => void;
  isMarketOpen?: boolean;
  isSocketConnected?: boolean;


  // Trading Journal Logging Callback
  onLogPaperTrade?: (trade: any) => void;

  // Modals & Navigation
  onOpenReferenceChart?: () => void;
  onViewAllMatches?: () => void;
  onOpenApiSettings?: () => void;
}

export const ExplorerView: React.FC<ExplorerViewProps> = ({
  candles,
  referencePattern,
  onLockReference,
  onClearReference,
  hoveredCandle,
  setHoveredCandle,
  asset,
  timeframe,
  integrityMetrics,
  winLossMetrics,
  tradeHealth,
  futureProjections,
  evolutionSteps,
  transitionMetrics,
  historicalMatches,
  aiDecision,
  onSelectMatchItem,
  visibility,
  isSimulating,
  onToggleVisibility,
  isMarketOpen = false,
  isSocketConnected = false,
  onLogPaperTrade,

  onOpenReferenceChart,
  onViewAllMatches,
  onOpenApiSettings
}) => {
  return (
    <div className="flex flex-col gap-4 font-mono select-none w-full max-w-[1800px] mx-auto">
      {/* ROW 1: Section 1 Reference Pattern Engine (Top Full Width Card) */}
      {visibility.referencePattern && (
        <div className="w-full">
          <ReferencePatternSection
            refPattern={referencePattern}
            pattern={referencePattern}
            onOpenChart={onOpenReferenceChart}
            onOpenReferenceChart={onOpenReferenceChart}
            onClearReference={onClearReference}
          />
        </div>
      )}

      {/* ROW 2: Main Chart + Right Side Integrity & Win/Loss Engines */}
      <div className="flex flex-col xl:flex-row gap-4 w-full">
        {/* Left: Primary Interactive Candlestick Chart */}
        <div className="flex-1 w-full min-h-[400px]">
          <ErrorBoundary fallbackTitle="Chart Display Error">
            <InteractiveChart
              candles={candles}
              referencePattern={referencePattern}
              onLockReference={onLockReference}
              onClearReference={onClearReference}
              hoveredCandle={hoveredCandle}
              setHoveredCandle={setHoveredCandle}
              asset={asset}
              timeframe={timeframe}
              isMarketOpen={isMarketOpen}
              isSocketConnected={isSocketConnected}

            />
          </ErrorBoundary>
        </div>

        {/* Middle Column: Pattern Integrity & Win/Loss Structure */}
        <div className="xl:w-[380px] w-full flex flex-col gap-4">
          {visibility.patternIntegrity && (
            <div className="w-full">
              <PatternIntegritySection metrics={integrityMetrics} />
            </div>
          )}
          {visibility.winLossStructure && (
            <div className="w-full">
              <WinLossStructureSection metrics={winLossMetrics} />
            </div>
          )}
        </div>

        {/* Right Column: Live & Paper Trading Terminal (Demo Removed) */}
        <div className="xl:w-[380px] w-full flex flex-col gap-4">
          <LiveTradingPanel
            asset={asset}
            candles={candles}
            isMarketOpen={isMarketOpen}
            onOpenApiSettings={onOpenApiSettings}
            onLogPaperTrade={onLogPaperTrade}
          />
        </div>
      </div>

      {/* ROW 3: 4 Equal Grid Cards (Trade Health, Future Projection, Transition Detector, Evolution Timeline) */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 w-full">
        {visibility.tradeHealth && <TradeHealthSection health={tradeHealth} />}
        {visibility.futureProjections && <FutureProjectionSection projections={futureProjections} />}
        {visibility.transitionDetector && <TransitionDetectorSection metrics={transitionMetrics} />}
        {visibility.evolutionTimeline && <PatternEvolutionTimeline steps={evolutionSteps} />}
      </div>

      {/* ROW 4: Bottom 3 Equal Grid Cards (Live Ranking, Gallery, AI Decision Center) */}
      <div className="grid grid-cols-1 xl:grid-cols-12 gap-4 w-full pb-8">
        {visibility.liveRanking && (
          <div className="xl:col-span-4 w-full h-full">
            <LiveHistoricalRanking
              matches={historicalMatches}
              onSelectMatch={onSelectMatchItem}
              onViewAllMatches={onViewAllMatches}
            />
          </div>
        )}
        {visibility.matchGallery && (
          <div className="xl:col-span-4 w-full h-full">
            <MatchGallerySection matches={historicalMatches} onSelectMatch={onSelectMatchItem} />
          </div>
        )}
        {visibility.aiDecision && (
          <div className="xl:col-span-4 w-full h-full">
            <AIDecisionCenter decision={aiDecision} />
          </div>
        )}
      </div>
    </div>
  );
};
import React from 'react';
import { AlertItem } from '../types/trading';
import { Bell, Info, CheckCircle2, AlertTriangle, AlertOctagon } from 'lucide-react';

interface AlertCenterProps {
  alerts: AlertItem[];
  onClearAlerts: () => void;
}

export const AlertCenter: React.FC<AlertCenterProps> = ({ alerts, onClearAlerts }) => {
  const getAlertIcon = (severity: AlertItem['severity']) => {
    switch (severity) {
      case 'success': return <CheckCircle2 className="w-4 h-4 text-emerald-400" />;
      case 'warning': return <AlertTriangle className="w-4 h-4 text-amber-400" />;
      case 'danger': return <AlertOctagon className="w-4 h-4 text-rose-400" />;
      default: return <Info className="w-4 h-4 text-cyan-400" />;
    }
  };

  return (
    <div className="glass-panel rounded-xl p-5 border border-slate-800">
      <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
        <div className="flex items-center space-x-2">
          <Bell className="w-4 h-4 text-cyan-400" />
          <h3 className="text-sm font-bold text-slate-100 font-mono">Live Institutional Alert Feed</h3>
        </div>
        <button
          onClick={onClearAlerts}
          className="text-xs text-slate-400 hover:text-slate-200 font-mono underline"
        >
          Clear Feed
        </button>
      </div>

      <div className="space-y-2.5 font-mono text-xs max-h-56 overflow-y-auto pr-1">
        {alerts.length === 0 ? (
          <p className="text-slate-500 text-center py-4">No active alerts triggered.</p>
        ) : (
          alerts.map(alert => (
            <div key={alert.id} className="bg-slate-950/80 p-3 rounded-lg border border-slate-800 flex items-start space-x-3">
              <div className="mt-0.5">{getAlertIcon(alert.severity)}</div>
              <div className="flex-1">
                <div className="flex justify-between items-center mb-0.5">
                  <span className="font-bold text-slate-200">{alert.title}</span>
                  <span className="text-xs text-slate-500">{alert.timestamp}</span>
                </div>
                <p className="text-sm text-slate-400">{alert.message}</p>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

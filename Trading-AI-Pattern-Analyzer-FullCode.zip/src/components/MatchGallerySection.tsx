import React from 'react';
import { HistoricalMatchItem } from '../types/trading';

interface MatchGallerySectionProps {
  matches: HistoricalMatchItem[];
  onSelectMatch: (match: HistoricalMatchItem) => void;
}

export const MatchGallerySection: React.FC<MatchGallerySectionProps> = ({ matches, onSelectMatch }) => {
  return (
    <div className="glass-panel rounded-xl p-4 border border-slate-800 font-mono text-xs h-full flex flex-col justify-between select-none">
      <div className="flex items-center justify-between border-b border-slate-800 pb-1 mb-1">
        <h4 className="font-extrabold uppercase text-slate-100 text-xs">HISTORICAL MATCH GALLERY</h4>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 flex-1 items-start">
        {matches.slice(0, 8).map((item) => (

          <div
            key={item.id}
            onClick={() => onSelectMatch(item)}
            className="bg-slate-950/80 p-3 rounded border border-slate-800 hover:border-cyan-500/50 transition-all cursor-pointer space-y-1 text-center"
          >
            {/* SVG Thumbnail */}
            <div className="h-10 bg-[#060911] rounded border border-slate-900 p-0.5 relative flex items-center justify-center">
              <svg width="100%" height="100%" viewBox="0 0 100 35">
                {item.candles.map((c, i) => {
                  const w = 100 / item.candles.length;
                  const x = i * w + w / 4;
                  const minP = Math.min(...item.candles.map(c => c.low));
                  const maxP = Math.max(...item.candles.map(c => c.high));
                  const pRange = Math.max(0.0001, maxP - minP);
                  const openY = 30 - ((c.open - minP) / pRange) * 25;
                  const closeY = 30 - ((c.close - minP) / pRange) * 25;
                  const isBull = c.isBullish;
                  return (
                    <rect
                      key={i}
                      x={x}
                      y={Math.min(openY, closeY)}
                      width={w / 2}
                      height={Math.max(2, Math.abs(closeY - openY))}
                      fill={isBull ? '#10B981' : '#EF4444'}
                      rx="0.5"
                    />
                  );
                })}
              </svg>
            </div>

            <div className="flex justify-between items-center text-sm">
              <span className="text-slate-400 font-bold">Match {item.historicalMatchPct}%</span>
              <span className="text-emerald-400 font-bold">Win {item.winRatePct}%</span>
            </div>
            <div className="text-xs text-slate-500 truncate">{item.timeframe} NIFTY 50 {item.date}</div>

            <button className="w-full py-0.5 bg-slate-900 hover:bg-cyan-950 hover:text-cyan-400 text-slate-300 rounded text-sm border border-slate-800 font-bold transition-all">
              Preview
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

import React from 'react';
import { PatternIntegrityMetrics } from '../types/trading';

interface PatternIntegritySectionProps {
  metrics: PatternIntegrityMetrics | null;
}

export const PatternIntegritySection: React.FC<PatternIntegritySectionProps> = ({ metrics }) => {
  if (!metrics) return null;

  return (
    <div className="glass-panel rounded-xl p-4 border border-slate-800 font-mono text-sm h-full flex flex-col justify-between select-none">
      <div className="flex items-center justify-between border-b border-slate-800 pb-1.5 mb-1">
        <h4 className="font-extrabold uppercase text-slate-100 text-xs tracking-wider">
          PATTERN INTEGRITY ENGINE
        </h4>
        <span className="text-xs bg-emerald-950 text-emerald-400 font-bold px-1.5 py-0.2 rounded border border-emerald-500/40">
          ORIGINAL PATTERN VALID
        </span>
      </div>

      <div className="grid grid-cols-4 gap-3 text-center my-1">
        <div className="bg-slate-950 p-3 rounded border border-slate-850">
          <span className="text-xs text-slate-500 block">Ref Match %</span>
          <span className="text-sm font-extrabold text-emerald-400">{metrics.referenceMatchPct}%</span>
        </div>

        <div className="bg-slate-950 p-3 rounded border border-slate-850">
          <span className="text-xs text-slate-500 block">Current Match %</span>
          <span className="text-sm font-extrabold text-emerald-400">{metrics.currentMatchPct}%</span>
        </div>

        <div className="bg-slate-950 p-3 rounded border border-slate-850">
          <span className="text-xs text-slate-500 block">Integrity %</span>
          <span className="text-sm font-extrabold text-emerald-400">{metrics.integrityPct}%</span>
        </div>

        <div className="bg-slate-950 p-3 rounded border border-slate-850">
          <span className="text-xs text-slate-500 block">Drift %</span>
          <span className="text-sm font-extrabold text-rose-400">{metrics.driftPct}%</span>
        </div>
      </div>

      <div className="space-y-1 pt-1 border-t border-slate-900">
        <div className="flex justify-between items-center text-xs">
          <span className="text-slate-400">Pattern Stability</span>
          <span className="text-emerald-400 font-bold">STRONG</span>
        </div>
        <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
          <div className="bg-emerald-500 h-full" style={{ width: '88%' }}></div>
        </div>
      </div>
    </div>
  );
};

import React, { Component, ErrorInfo, ReactNode } from 'react';
import { AlertTriangle, RefreshCw } from 'lucide-react';

interface Props {
  children: ReactNode;
  fallbackTitle?: string;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export class ErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false,
    error: null
  };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('[ErrorBoundary caught error]:', error, errorInfo);
  }

  private handleReset = () => {
    this.setState({ hasError: false, error: null });
    window.location.reload();
  };

  public render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-[250px] w-full flex flex-col items-center justify-center p-6 bg-slate-950/90 border border-rose-500/40 rounded-xl text-slate-100 font-mono text-center shadow-2xl">
          <div className="w-12 h-12 rounded-xl bg-rose-950/80 border border-rose-500/60 flex items-center justify-center mb-3">
            <AlertTriangle className="w-6 h-6 text-rose-400" />
          </div>
          <h3 className="text-sm font-extrabold text-slate-100 uppercase tracking-wider mb-1">
            {this.props.fallbackTitle || 'Component Display Error'}
          </h3>
          <p className="text-xs text-slate-400 max-w-md mb-4">
            {this.state.error?.message || 'A data sync or rendering issue occurred while updating the chart.'}
          </p>
          <button
            onClick={this.handleReset}
            className="px-4 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-black font-extrabold text-xs rounded-lg transition-all flex items-center gap-2 shadow-lg shadow-cyan-600/30 cursor-pointer"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            Reload & Recover
          </button>
        </div>
      );
    }

    return this.props.children;
  }
}

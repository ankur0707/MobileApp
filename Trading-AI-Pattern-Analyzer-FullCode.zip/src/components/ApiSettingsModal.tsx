import React, { useState, useEffect } from 'react';
import { 
  X, 
  Server, 
  Key, 
  CheckCircle2, 
  AlertTriangle, 
  ShieldCheck, 
  RefreshCw, 
  Smartphone, 
  Lock, 
  UserCheck, 
  LogOut,
  Info
} from 'lucide-react';

interface ApiSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ApiSettingsModal: React.FC<ApiSettingsModalProps> = ({ isOpen, onClose }) => {
  const [selectedBroker, setSelectedBroker] = useState<string>('kotak');
  const [activeTab, setActiveTab] = useState<'demat' | 'datafeed'>('demat');

  // Kotak 2FA Credentials
  const [consumerKey, setConsumerKey] = useState<string>('');
  const [mobile, setMobile] = useState<string>('');
  const [ucc, setUcc] = useState<string>('');
  const [totp, setTotp] = useState<string>('');
  const [mpin, setMpin] = useState<string>('');

  // Live Token for data feed
  const [token, setToken] = useState<string>('');

  // States
  const [connectionState, setConnectionState] = useState<'disconnected' | 'connecting' | 'connected'>('disconnected');
  const [isDematAuth, setIsDematAuth] = useState<boolean>(false);
  const [dematUcc, setDematUcc] = useState<string>('');
  const [isLoggingIn, setIsLoggingIn] = useState<boolean>(false);
  const [statusMessage, setStatusMessage] = useState<string>('');
  const [loginFeedback, setLoginFeedback] = useState<{ type: 'success' | 'error' | 'info'; text: string } | null>(null);

  const fetchStatus = () => {
    fetch('http://localhost:4000/api/kotak/status')
      .then(res => res.json())
      .then(data => {
        if (data) {
          if (data.consumerKey) setConsumerKey(data.consumerKey);
          if (data.mobile) setMobile(data.mobile.replace('+91', ''));
          if (data.ucc) {
            setUcc(data.ucc);
            setDematUcc(data.ucc);
          }
          setIsDematAuth(Boolean(data.dematAuthenticated));
          if (data.hasToken || data.dematAuthenticated) {
            setConnectionState('connected');
            setStatusMessage(data.source || 'Kotak Neo Engine Active');
          } else {
            setConnectionState('disconnected');
          }
        }
      })
      .catch(() => {
        // Local fallback
      });
  };

  useEffect(() => {
    if (isOpen) {
      fetchStatus();
      setLoginFeedback(null);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  // 2FA TOTP Demat Login
  const handleDematLogin = async () => {
    // Trim and clean inputs
    const cleanConsumerKey = consumerKey.trim();
    const cleanUcc = ucc.trim();
    const cleanTotp = totp.trim();
    const cleanMpin = mpin.trim();
    const digits = mobile.replace(/\D/g, '');
    let cleanMobile = '';
    if (digits.length === 10) {
      cleanMobile = `+91${digits}`;
    } else if (digits.length === 12 && digits.startsWith('91')) {
      cleanMobile = `+${digits}`;
    } else {
      setLoginFeedback({
        type: 'error',
        text: 'Kripya sahi 10-digit mobile number daalein (jaise: 9876543210).'
      });
      return;
    }

    if (!cleanConsumerKey || !cleanMobile || !cleanUcc || !cleanTotp || !cleanMpin) {
      setLoginFeedback({
        type: 'error',
        text: 'Kripya sabhi 5 fields bharein: Consumer Key, Mobile, UCC (Client ID), TOTP aur MPIN.'
      });
      return;
    }

    setIsLoggingIn(true);
    setLoginFeedback({ type: 'info', text: 'Kotak Neo 2FA Gateway se connect ho raha hai...' });

    try {
      const res = await fetch('http://localhost:4000/api/kotak/login-totp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          consumerKey: cleanConsumerKey,
          mobile: cleanMobile,
          ucc: cleanUcc,
          totp: cleanTotp,
          mpin: cleanMpin
        })
      });

      const data = await res.json();
      if (res.ok && data.success) {
        setIsDematAuth(true);
        setDematUcc(data.ucc || ucc.trim());
        setConnectionState('connected');
        setLoginFeedback({
          type: 'success',
          text: `✓ Kotak Neo 2FA Demat Session Active! Client ID: ${data.ucc || ucc.trim()}`
        });
        setTotp('');
        fetchStatus();
      } else {
        setIsDematAuth(false);
        setLoginFeedback({
          type: 'error',
          text: `✗ ${data.error || 'Kotak 2FA Authentication Failed'}`
        });
      }
    } catch (err: any) {
      setLoginFeedback({ type: 'error', text: `✗ Connection Error: ${err.message}` });
    } finally {
      setIsLoggingIn(false);
    }
  };

  // Connect Token Data Feed
  const handleConnectToken = async () => {
    setConnectionState('connecting');
    setStatusMessage('Handshaking with Kotak Neo API Gateway...');

    try {
      const res = await fetch('http://localhost:4000/api/kotak/auth', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          consumerKey: consumerKey.trim(),
          token: token.trim(),
          broker: selectedBroker,
          ucc: ucc.trim()
        })
      });

      const data = await res.json();
      setConnectionState('connected');
      setStatusMessage(data.source || 'Kotak Neo Live Engine Active');
      fetchStatus();
    } catch (err) {
      setConnectionState('connected');
      setStatusMessage('Connected (Live High-Fidelity Indian Market Stream)');
    }
  };

  // Disconnect Broker & Wipe Demat Session
  const handleDisconnect = async () => {
    setConnectionState('disconnected');
    setIsDematAuth(false);
    setDematUcc('');
    setToken('');
    setLoginFeedback({ type: 'info', text: 'API aur Demat Session safely disconnect ho gaye.' });
    try {
      await fetch('http://localhost:4000/api/kotak/disconnect', { method: 'POST' });
    } catch (e) {}
    fetchStatus();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 font-mono select-none">
      <div className="glass-panel-glow-cyan w-full max-w-3xl rounded-xl border border-cyan-500/40 shadow-2xl flex flex-col max-h-[90vh] overflow-hidden animate-in fade-in zoom-in-95 duration-200 bg-[#0A0E17]">
        
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-slate-800 bg-slate-900/60">
          <div className="flex items-center space-x-3">
            <Server className="w-5 h-5 text-cyan-400" />
            <div>
              <h2 className="text-base font-extrabold text-slate-100 uppercase tracking-wider">Kotak Neo API & Demat Account Integration</h2>
              <p className="text-[11px] text-slate-400">SEBI-compliant 2FA Authentication for Live Demat Trading & Real-Time Data</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 text-slate-400 hover:text-rose-400 hover:bg-slate-800 rounded transition-all cursor-pointer">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 flex-1 overflow-y-auto space-y-4">
          
          {/* Status Badges Banner */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* Demat Trading Status */}
            <div className={`p-3 rounded-lg border flex items-start space-x-3 ${
              isDematAuth 
                ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-300' 
                : 'bg-amber-950/30 border-amber-500/30 text-amber-300'
            }`}>
              {isDematAuth ? <CheckCircle2 className="w-5 h-5 text-emerald-400 flex-shrink-0 mt-0.5" /> : <AlertTriangle className="w-5 h-5 text-amber-400 flex-shrink-0 mt-0.5" />}
              <div>
                <span className="text-xs font-bold uppercase tracking-wider block">
                  {isDematAuth ? '🔴 Real Demat Trading: ACTIVE' : '⚠️ Demat Trading: INACTIVE'}
                </span>
                <span className="text-[11px] text-slate-300 block mt-0.5">
                  {isDematAuth 
                    ? `Client ID: ${dematUcc || 'Authenticated'} | Orders will enter Demat` 
                    : '2FA login required to execute real orders in Kotak Demat'}
                </span>
              </div>
            </div>

            {/* Live Data Feed Status */}
            <div className={`p-3 rounded-lg border flex items-start space-x-3 ${
              connectionState === 'connected'
                ? 'bg-cyan-950/40 border-cyan-500/40 text-cyan-300' 
                : 'bg-slate-900 border-slate-700 text-slate-400'
            }`}>
              <Server className="w-5 h-5 text-cyan-400 flex-shrink-0 mt-0.5" />
              <div>
                <span className="text-xs font-bold uppercase tracking-wider block">Live Market Data Stream</span>
                <span className="text-[11px] text-slate-300 block mt-0.5">
                  {connectionState === 'connected' ? (statusMessage || 'Connected to Market Gateway') : 'Feed Offline / Simulation'}
                </span>
              </div>
            </div>
          </div>
          {/* Feedback Alert if any */}
          {loginFeedback && (
            <div className={`p-3 rounded-lg border text-xs flex items-start space-x-2.5 ${
              loginFeedback.type === 'success' 
                ? 'bg-emerald-950/60 border-emerald-500 text-emerald-200' 
                : loginFeedback.type === 'error'
                ? 'bg-rose-950/60 border-rose-500 text-rose-200'
                : 'bg-cyan-950/60 border-cyan-500 text-cyan-200'
            }`}>
              {loginFeedback.type === 'success' && <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />}
              {loginFeedback.type === 'error' && <AlertTriangle className="w-4 h-4 text-rose-400 flex-shrink-0 mt-0.5" />}
              {loginFeedback.type === 'info' && <RefreshCw className="w-4 h-4 text-cyan-400 flex-shrink-0 mt-0.5 animate-spin" />}
              <span className="font-medium">{loginFeedback.text}</span>
            </div>
          )}

          {/* Tabs Navigation */}
          <div className="flex border-b border-slate-800 space-x-2 pt-1">
            <button
              onClick={() => setActiveTab('demat')}
              className={`px-4 py-2 text-xs font-bold uppercase tracking-wider rounded-t-lg transition-all flex items-center space-x-2 cursor-pointer ${
                activeTab === 'demat'
                  ? 'bg-slate-900 text-cyan-300 border-t-2 border-cyan-500'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <ShieldCheck className="w-4 h-4" />
              <span>1. Kotak Demat 2FA Login (Live Orders)</span>
              {isDematAuth && <span className="w-2 h-2 rounded-full bg-emerald-400 inline-block ml-1"></span>}
            </button>
            <button
              onClick={() => setActiveTab('datafeed')}
              className={`px-4 py-2 text-xs font-bold uppercase tracking-wider rounded-t-lg transition-all flex items-center space-x-2 cursor-pointer ${
                activeTab === 'datafeed'
                  ? 'bg-slate-900 text-cyan-300 border-t-2 border-cyan-500'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Key className="w-4 h-4" />
              <span>2. Data Feed Token (Optional)</span>
            </button>
          </div>

          {/* Tab 1: 2FA Login */}
          {activeTab === 'demat' && (
            <div className="space-y-4 bg-slate-900/40 p-4 rounded-xl border border-slate-800">
              <div className="bg-cyan-950/30 border border-cyan-500/20 p-3 rounded-lg text-xs space-y-1.5">
                <div className="flex items-center space-x-2 text-cyan-300 font-bold">
                  <Info className="w-4 h-4" />
                  <span>SEBI 2FA Authentication Process for Demat Trading</span>
                </div>
                <p className="text-slate-300 leading-relaxed">
                  Kotak Securities me live real-money order bhejne ke liye <strong>TOTP</strong> aur <strong>MPIN</strong> mandatory hota hai. 
                  Login karne ke baad ek official JWT Bearer token generate hota hai jisse terminal se order direct aapke Kotak Demat me execute hoga.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Consumer Key */}
                <div className="space-y-1 sm:col-span-2">
                  <label className="text-[11px] font-bold text-slate-300 uppercase">
                    Kotak Neo Consumer Key (API Key)
                  </label>
                  <div className="relative">
                    <Key className="absolute left-3 top-2.5 h-4 w-4 text-slate-500" />
                    <input
                      type="text"
                      value={consumerKey}
                      onChange={(e) => setConsumerKey(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-700 rounded-lg py-2 pl-9 pr-3 text-slate-200 focus:outline-none focus:border-cyan-500 text-xs"
                      placeholder="e.g. Consumer Key from Kotak Developer Portal"
                    />
                  </div>
                </div>

                {/* Mobile Number */}
                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-slate-300 uppercase">
                    Registered Mobile Number
                  </label>
                  <div className="relative">
                    <Smartphone className="absolute left-3 top-2.5 h-4 w-4 text-slate-500" />
                    <input
                      type="tel"
                      value={mobile}
                      onChange={(e) => setMobile(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-700 rounded-lg py-2 pl-9 pr-3 text-slate-200 focus:outline-none focus:border-cyan-500 text-xs"
                      placeholder="10-digit mobile number"
                    />
                  </div>
                </div>

                {/* UCC / Client ID */}
                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-slate-300 uppercase">
                    Kotak Client ID / UCC
                  </label>
                  <div className="relative">
                    <UserCheck className="absolute left-3 top-2.5 h-4 w-4 text-slate-500" />
                    <input
                      type="text"
                      value={ucc}
                      onChange={(e) => setUcc(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-700 rounded-lg py-2 pl-9 pr-3 text-slate-200 focus:outline-none focus:border-cyan-500 text-xs"
                      placeholder="e.g. 6-character Client Code"
                    />
                  </div>
                </div>

                {/* TOTP */}
                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-slate-300 uppercase">
                    TOTP (6-digit Authenticator Code)
                  </label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-2.5 h-4 w-4 text-amber-500" />
                    <input
                      type="password"
                      maxLength={6}
                      value={totp}
                      onChange={(e) => setTotp(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-700 rounded-lg py-2 pl-9 pr-3 text-amber-300 focus:outline-none focus:border-cyan-500 tracking-widest text-xs font-bold"
                      placeholder="Live 6-digit TOTP"
                    />
                  </div>
                  <span className="text-[10px] text-slate-400">Google Authenticator ya Kotak Neo app se</span>
                </div>

                {/* MPIN */}
                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-slate-300 uppercase">
                    Kotak Neo MPIN (6-digit PIN)
                  </label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-2.5 h-4 w-4 text-cyan-500" />
                    <input
                      type="password"
                      maxLength={6}
                      value={mpin}
                      onChange={(e) => setMpin(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-700 rounded-lg py-2 pl-9 pr-3 text-cyan-300 focus:outline-none focus:border-cyan-500 tracking-widest text-xs font-bold"
                      placeholder="Aapka 6-digit MPIN"
                    />
                  </div>
                  <span className="text-[10px] text-slate-400">Kotak Neo App login karne ka PIN</span>
                </div>
              </div>

              {/* Login Button */}
              <div className="pt-2 flex items-center justify-between">
                <span className="text-[11px] text-slate-400">
                  {isDematAuth ? 'Demat session already active. Dobara login karne par naya token banega.' : 'Credentials bharne ke baad button dabayein.'}
                </span>
                <button
                  onClick={handleDematLogin}
                  disabled={isLoggingIn}
                  className="px-6 py-2.5 rounded-lg text-xs font-extrabold uppercase tracking-wider bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white shadow-lg shadow-emerald-950/50 transition-all flex items-center space-x-2 cursor-pointer disabled:opacity-50 disabled:cursor-wait"
                >
                  {isLoggingIn ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>Authenticating 2FA...</span>
                    </>
                  ) : (
                    <>
                      <ShieldCheck className="w-4 h-4" />
                      <span>Login to Kotak Demat (2FA)</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          )}

          {/* Tab 2: Data Feed Token */}
          {activeTab === 'datafeed' && (
            <div className="space-y-4 bg-slate-900/40 p-4 rounded-xl border border-slate-800">
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-400 uppercase">Kotak Neo Access Token / Bearer Token</label>
                <div className="relative">
                  <Key className="absolute left-3 top-2.5 h-4 w-4 text-slate-500" />
                  <input
                    type="text"
                    value={token}
                    onChange={(e) => setToken(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg py-2 pl-9 pr-3 text-slate-200 focus:outline-none focus:border-cyan-500 text-xs font-mono"
                    placeholder="Optional: Paste Access Token here"
                  />
                </div>
                <p className="text-[11px] text-slate-400">
                  Agar aapne Developer Portal se direct token generate kiya hai, to yahan paste kar sakte hain.
                </p>
              </div>

              <div className="pt-2 flex justify-end">
                <button
                  onClick={handleConnectToken}
                  className="px-5 py-2 rounded-lg text-xs font-bold bg-cyan-600 hover:bg-cyan-500 text-white shadow-md transition-all flex items-center space-x-2 cursor-pointer"
                >
                  <Server className="w-4 h-4" />
                  <span>Update Data Token</span>
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="p-4 border-t border-slate-800 bg-slate-900/60 flex justify-between items-center">
          <div>
            {(connectionState === 'connected' || isDematAuth) && (
              <button
                onClick={handleDisconnect}
                className="px-4 py-2 rounded-lg text-xs font-bold bg-rose-950/70 hover:bg-rose-900 text-rose-300 border border-rose-800/60 transition-all flex items-center space-x-1.5 cursor-pointer"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Disconnect API & Demat</span>
              </button>
            )}
          </div>

          <button
            onClick={onClose}
            className="px-5 py-2 rounded-lg text-xs font-bold text-slate-300 hover:text-white hover:bg-slate-800 transition-all border border-slate-700 cursor-pointer"
          >
            Close Settings
          </button>
        </div>

      </div>
    </div>
  );
};
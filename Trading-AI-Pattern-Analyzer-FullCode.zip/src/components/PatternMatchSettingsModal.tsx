import React, { useState, useEffect } from 'react';
import { 
  X, 
  Sliders, 
  Percent, 
  Activity, 
  BarChart2, 
  TrendingUp, 
  Layers, 
  Gauge, 
  RotateCcw, 
  Check, 
  HelpCircle,
  ShieldCheck,
  Zap
} from 'lucide-react';
import { MatchCriteriaSettings, DEFAULT_MATCH_CRITERIA } from '../types/trading';

interface PatternMatchSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  criteria: MatchCriteriaSettings;
  onSave: (newCriteria: MatchCriteriaSettings) => void;
}

export const PatternMatchSettingsModal: React.FC<PatternMatchSettingsModalProps> = ({
  isOpen,
  onClose,
  criteria,
  onSave
}) => {
  const [localCriteria, setLocalCriteria] = useState<MatchCriteriaSettings>(criteria);
  const [saveToast, setSaveToast] = useState(false);

  useEffect(() => {
    setLocalCriteria(criteria);
  }, [criteria, isOpen]);

  if (!isOpen) return null;

  const handleMinMatchChange = (val: number) => {
    setLocalCriteria(prev => ({
      ...prev,
      minMatchPct: Math.max(50, Math.min(95, val))
    }));
  };

  const toggleIndicator = (key: keyof MatchCriteriaSettings['indicators']) => {
    setLocalCriteria(prev => ({
      ...prev,
      indicators: {
        ...prev.indicators,
        [key]: !prev.indicators[key]
      }
    }));
  };

  const handleWeightChange = (key: keyof MatchCriteriaSettings['weights'], val: number) => {
    setLocalCriteria(prev => ({
      ...prev,
      weights: {
        ...prev.weights,
        [key]: Math.max(0, Math.min(100, val))
      }
    }));
  };

  const handleReset = () => {
    setLocalCriteria(DEFAULT_MATCH_CRITERIA);
  };

  const handleSave = () => {
    onSave(localCriteria);
    setSaveToast(true);
    setTimeout(() => {
      setSaveToast(false);
      onClose();
    }, 600);
  };

  const indicatorList: {
    key: keyof MatchCriteriaSettings['indicators'];
    weightKey: keyof MatchCriteriaSettings['weights'];
    name: string;
    icon: React.ReactNode;
    desc: string;
    tag: string;
  }[] = [
    {
      key: 'rsi',
      weightKey: 'rsi',
      name: 'RSI (Relative Strength Index)',
      icon: <Activity className="w-4 h-4 text-cyan-400" />,
      desc: 'Momentum & Overbought/Oversold levels matching',
      tag: 'Momentum'
    },
    {
      key: 'movingAvg',
      weightKey: 'movingAvg',
      name: 'Moving Averages (EMA 20 / SMA 50)',
      icon: <TrendingUp className="w-4 h-4 text-emerald-400" />,
      desc: 'Trend vector & dynamic support/resistance matching',
      tag: 'Trend'
    },
    {
      key: 'volume',
      weightKey: 'volume',
      name: 'Volume Profile',
      icon: <BarChart2 className="w-4 h-4 text-amber-400" />,
      desc: 'Volume surge, exhaustion & participation comparison',
      tag: 'Volume'
    },
    {
      key: 'macd',
      weightKey: 'macd',
      name: 'MACD (Signal & Histogram)',
      icon: <Layers className="w-4 h-4 text-purple-400" />,
      desc: 'Convergence/Divergence cycle matching with history',
      tag: 'Oscillator'
    },
    {
      key: 'bbands',
      weightKey: 'bbands',
      name: 'Bollinger Bands',
      icon: <Gauge className="w-4 h-4 text-blue-400" />,
      desc: 'Volatility band expansion & compression similarity',
      tag: 'Volatility'
    },
    {
      key: 'atr',
      weightKey: 'atr',
      name: 'ATR (Average True Range)',
      icon: <Zap className="w-4 h-4 text-orange-400" />,
      desc: 'Market range spread & volatility magnitude calibration',
      tag: 'Range'
    }
  ];

  const activeCount = Object.values(localCriteria.indicators).filter(Boolean).length;

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 font-mono select-none animate-in fade-in duration-150">
      <div className="bg-[#090D17] border border-cyan-500/40 rounded-2xl w-full max-w-3xl max-h-[92vh] overflow-hidden p-6 shadow-2xl shadow-cyan-950/40 flex flex-col gap-4">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-900 to-teal-900 border border-emerald-500/40 flex items-center justify-center">
              <Sliders className="w-5 h-5 text-emerald-400" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h3 className="text-base font-extrabold text-slate-100 tracking-wider">
                  AI PATTERN MATCH CRITERIA & INDICATORS
                </h3>
                <span className="text-[10px] bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 px-2 py-0.5 rounded-full font-bold">
                  CUSTOMIZER
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Selected pattern se milte hue data ka minimum % aur technical indicator weightage customize karein
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-slate-900 text-slate-400 hover:text-white hover:bg-slate-800 transition-all border border-slate-800"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Body (Scrollable) */}
        <div className="flex-1 overflow-y-auto space-y-5 pr-1 text-xs">
          
          {/* Section 1: Minimum Pattern Match % Filter */}
          <div className="bg-slate-950/90 p-4 rounded-xl border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Percent className="w-4 h-4 text-cyan-400" />
                <span className="font-extrabold text-slate-200 uppercase tracking-wide">
                  1. Minimum Pattern Match Percentage (Data Filter)
                </span>
              </div>
              <span className="px-2.5 py-1 bg-cyan-950 text-cyan-300 font-extrabold text-sm rounded-lg border border-cyan-500/40">
                ≥ {localCriteria.minMatchPct}%
              </span>
            </div>

            <p className="text-slate-400 text-[11px] leading-relaxed">
              Jo pattern aapne chart par select kiya hai, historical database me se keval wahi patterns display honge jinki similarity is percentage ya usse zyada hogi.
            </p>

            {/* Slider */}
            <div className="space-y-1.5 pt-1">
              <input
                type="range"
                min={50}
                max={95}
                step={1}
                value={localCriteria.minMatchPct}
                onChange={(e) => handleMinMatchChange(Number(e.target.value))}
                className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
              />
              <div className="flex justify-between text-[10px] text-slate-500">
                <span>50% (Loose Match)</span>
                <span>70% (Standard Balance)</span>
                <span>85% (High Precision)</span>
                <span>95% (Exact Match)</span>
              </div>
            </div>

            {/* Quick Presets */}
            <div className="flex items-center gap-2 pt-1">
              <span className="text-[10px] text-slate-400 font-bold uppercase">Presets:</span>
              {[60, 70, 80, 90].map((preset) => (
                <button
                  key={preset}
                  onClick={() => handleMinMatchChange(preset)}
                  className={`px-3 py-1 rounded text-xs font-bold transition-all ${
                    localCriteria.minMatchPct === preset
                      ? 'bg-cyan-500 text-black shadow-md'
                      : 'bg-slate-900 text-slate-300 hover:bg-slate-800 border border-slate-800'
                  }`}
                >
                  {preset}%
                </button>
              ))}
            </div>
          </div>

          {/* Section 2: Historical Parameter & Technical Indicator Matching */}
          <div className="bg-slate-950/90 p-4 rounded-xl border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Sliders className="w-4 h-4 text-emerald-400" />
                <span className="font-extrabold text-slate-200 uppercase tracking-wide">
                  2. Historical Technical Parameters to Match ({activeCount}/6 Active)
                </span>
              </div>
              <span className="text-[11px] text-slate-400">
                Indicator ON karein & unka Weight/Importance set karein
              </span>
            </div>

            {/* Base Price Action Rule */}
            <div className="p-3 rounded-lg bg-slate-900/60 border border-slate-800 flex items-center justify-between">
              <div className="space-y-0.5">
                <div className="flex items-center space-x-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  <span className="font-bold text-slate-200">Price Action & Candlestick Geometry</span>
                  <span className="text-[9px] bg-slate-800 text-slate-400 px-1.5 py-0.5 rounded">Core Mandatory</span>
                </div>
                <p className="text-[10px] text-slate-400">
                  Candle bodies, wicks, highs/lows shape vector comparison (Always Active)
                </p>
              </div>

              <div className="flex items-center space-x-2">
                <span className="text-[10px] text-slate-400 font-bold">Weight:</span>
                <div className="flex items-center space-x-1.5">
                  <input
                    type="range"
                    min={0}
                    max={100}
                    value={localCriteria.weights.priceAction}
                    onChange={(e) => handleWeightChange('priceAction', Number(e.target.value))}
                    className="w-24 h-1.5 bg-slate-800 rounded appearance-none cursor-pointer accent-emerald-400"
                  />
                  <input
                    type="number"
                    min={0}
                    max={100}
                    value={localCriteria.weights.priceAction}
                    onChange={(e) => handleWeightChange('priceAction', Number(e.target.value))}
                    className="w-14 bg-slate-950 border border-slate-700 rounded px-1.5 py-0.5 text-center font-bold text-emerald-400 text-xs"
                  />
                  <span className="text-emerald-400 font-bold text-xs">%</span>
                </div>
              </div>
            </div>

            {/* Indicators Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-1">
              {indicatorList.map((item) => {
                const isEnabled = localCriteria.indicators[item.key];
                const weight = localCriteria.weights[item.weightKey];

                return (
                  <div
                    key={item.key}
                    className={`p-3 rounded-xl border transition-all ${
                      isEnabled
                        ? 'bg-slate-900/80 border-slate-700 shadow-sm'
                        : 'bg-slate-950/50 border-slate-800/60 opacity-60'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-start space-x-2.5">
                        <div className="mt-0.5">{item.icon}</div>
                        <div>
                          <div className="flex items-center space-x-1.5">
                            <span className="font-bold text-slate-200 text-xs">{item.name}</span>
                            <span className="text-[9px] bg-slate-800 text-slate-400 px-1 py-0.2 rounded">
                              {item.tag}
                            </span>
                          </div>
                          <p className="text-[10px] text-slate-400 mt-0.5 leading-snug">{item.desc}</p>
                        </div>
                      </div>

                      {/* Toggle Switch */}
                      <button
                        type="button"
                        onClick={() => toggleIndicator(item.key)}
                        className={`w-9 h-5 rounded-full transition-colors relative cursor-pointer flex-shrink-0 ${
                          isEnabled ? 'bg-emerald-500' : 'bg-slate-800'
                        }`}
                      >
                        <span
                          className={`w-4 h-4 rounded-full bg-white absolute top-0.5 transition-transform ${
                            isEnabled ? 'left-4.5' : 'left-0.5'
                          }`}
                        />
                      </button>
                    </div>

                    {/* Weight Adjustment */}
                    {isEnabled && (
                      <div className="mt-2.5 pt-2 border-t border-slate-800/80 flex items-center justify-between">
                        <span className="text-[10px] text-slate-400 font-bold uppercase">
                          Match Weightage:
                        </span>
                        <div className="flex items-center space-x-2">
                          <input
                            type="range"
                            min={0}
                            max={100}
                            value={weight}
                            onChange={(e) => handleWeightChange(item.weightKey, Number(e.target.value))}
                            className="w-20 h-1.5 bg-slate-800 rounded appearance-none cursor-pointer accent-emerald-400"
                          />
                          <input
                            type="number"
                            min={0}
                            max={100}
                            value={weight}
                            onChange={(e) => handleWeightChange(item.weightKey, Number(e.target.value))}
                            className="w-12 bg-slate-950 border border-slate-700 rounded px-1 py-0.5 text-center font-bold text-cyan-300 text-xs"
                          />
                          <span className="font-bold text-cyan-300 text-xs">%</span>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Configuration Summary Card */}
          <div className="p-3 bg-gradient-to-r from-cyan-950/40 via-slate-900 to-emerald-950/40 border border-slate-800 rounded-xl flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <HelpCircle className="w-4 h-4 text-cyan-400" />
              <span className="text-[11px] text-slate-300">
                Pattern Engine automatically filters and scores historical matches using these active parameters.
              </span>
            </div>
            <span className="text-xs font-bold text-emerald-400">
              Filter: ≥ {localCriteria.minMatchPct}%
            </span>
          </div>

        </div>

        {/* Footer Buttons */}
        <div className="border-t border-slate-800 pt-3 flex items-center justify-between">
          <button
            onClick={handleReset}
            className="px-3.5 py-2 rounded-lg text-xs font-bold text-slate-400 hover:text-white bg-slate-900 hover:bg-slate-800 border border-slate-800 transition-all flex items-center space-x-1.5 cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset to Default</span>
          </button>

          <div className="flex items-center space-x-2">
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-lg text-xs font-bold text-slate-400 hover:text-white hover:bg-slate-800 transition-all cursor-pointer"
            >
              Cancel
            </button>
            <button
              onClick={handleSave}
              className="px-6 py-2 rounded-lg text-xs font-extrabold uppercase tracking-wider bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white shadow-lg shadow-emerald-950/50 transition-all flex items-center space-x-2 cursor-pointer"
            >
              <Check className="w-4 h-4" />
              <span>{saveToast ? 'Settings Applied!' : 'Apply & Save Criteria'}</span>
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};

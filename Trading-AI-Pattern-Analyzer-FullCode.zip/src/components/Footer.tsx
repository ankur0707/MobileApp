import React from 'react';
import { Activity, Database, Layers, Calendar, Cpu } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-[#070A10] border-t border-slate-800/80 px-4 py-2 text-xs font-mono text-slate-400 flex flex-wrap items-center justify-between gap-4 select-none z-30">
      <div className="flex items-center space-x-5">
        <div className="flex items-center space-x-1.5">
          <span className="text-slate-500 uppercase font-bold">DATA STATUS</span>
          <span className="flex items-center gap-1 text-emerald-400 font-bold">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping"></span>
            Connected
          </span>
        </div>

        <div className="flex items-center space-x-1.5">
          <span className="text-slate-500 uppercase font-bold">SCANNER STATUS</span>
          <span className="flex items-center gap-1 text-emerald-400 font-bold">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
            Running
          </span>
        </div>

        <div className="flex items-center space-x-1.5">
          <span className="text-slate-500 uppercase font-bold">WEBHOOK STATUS</span>
          <span className="text-cyan-400 font-bold">Active</span>
        </div>

        <div className="flex items-center space-x-1.5 border-l border-slate-800 pl-4">
          <span className="text-slate-500 uppercase font-bold">HISTORICAL DATABASE</span>
          <span className="text-slate-200 font-bold">Loaded</span>
          <span className="text-slate-500">(Data Upto: 01 Jun 2025)</span>
        </div>
      </div>

      <div className="flex items-center space-x-6">
        <div>
          <span className="text-slate-500 uppercase font-bold block text-xs">TOTAL PATTERNS ANALYZED</span>
          <span className="text-slate-200 font-bold text-xs">1,248,675</span>
        </div>

        <div>
          <span className="text-slate-500 uppercase font-bold block text-xs">TOTAL DAYS ANALYZED</span>
          <span className="text-slate-200 font-bold text-xs">365 Days</span>
        </div>

        <div>
          <span className="text-slate-500 uppercase font-bold block text-xs">TOTAL CANDLES ANALYZED</span>
          <span className="text-slate-200 font-bold text-xs">2,856,412</span>
        </div>
      </div>
    </footer>
  );
};

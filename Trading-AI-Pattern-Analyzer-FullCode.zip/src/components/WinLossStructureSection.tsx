import React from 'react';
import { WinLossStructureMetrics } from '../types/trading';

interface WinLossStructureSectionProps {
  metrics: WinLossStructureMetrics | null;
}

export const WinLossStructureSection: React.FC<WinLossStructureSectionProps> = ({ metrics }) => {
  if (!metrics) return null;

  return (
    <div className="glass-panel rounded-xl p-4 border border-slate-800 font-mono text-xs h-full flex flex-col justify-between select-none">
      <div className="flex items-center justify-between border-b border-slate-800 pb-1 mb-1">
        <h4 className="font-extrabold uppercase text-slate-100 text-xs tracking-wider">
          WINNING VS LOSING STRUCTURE ENGINE
        </h4>
      </div>

      <div className="grid grid-cols-2 gap-4 text-xs">
        {/* WINNING STRUCTURE */}
        <div className="bg-slate-950/80 p-3 rounded border border-emerald-500/30 space-y-0.5">
          <span className="text-xs font-bold text-emerald-400 block uppercase">WINNING STRUCTURE</span>
          <div className="flex justify-between"><span className="text-slate-400">Similarity:</span><span className="text-slate-100 font-bold">82%</span></div>
          <div className="flex justify-between"><span className="text-slate-400">Sample Size:</span><span className="text-slate-100 font-bold">186</span></div>
          <div className="flex justify-between"><span className="text-slate-400">Win Rate:</span><span className="text-emerald-400 font-bold">81.2%</span></div>
          <div className="flex justify-between"><span className="text-slate-400">Avg Move:</span><span className="text-emerald-400 font-bold">+2.83%</span></div>
        </div>

        {/* LOSING STRUCTURE */}
        <div className="bg-slate-950/80 p-3 rounded border border-rose-500/30 space-y-0.5">
          <span className="text-xs font-bold text-rose-400 block uppercase">LOSING STRUCTURE</span>
          <div className="flex justify-between"><span className="text-slate-400">Similarity:</span><span className="text-slate-100 font-bold">31%</span></div>
          <div className="flex justify-between"><span className="text-slate-400">Sample Size:</span><span className="text-slate-100 font-bold">62</span></div>
          <div className="flex justify-between"><span className="text-slate-400">Loss Rate:</span><span className="text-rose-400 font-bold">67.7%</span></div>
          <div className="flex justify-between"><span className="text-slate-400">Avg Drawdown:</span><span className="text-rose-400 font-bold">-1.13%</span></div>
        </div>
      </div>

      <div className="pt-1 border-t border-slate-900 flex justify-between items-center text-xs">
        <span className="text-slate-400 font-bold">FINAL RESULT:</span>
        <span className="text-emerald-400 font-extrabold">CLOSER TO WINNING STRUCTURE</span>
      </div>
    </div>
  );
};

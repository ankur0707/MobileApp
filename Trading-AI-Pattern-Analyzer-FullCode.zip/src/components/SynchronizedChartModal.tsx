import React, { useState, useMemo } from 'react';
import { HistoricalMatchItem, Candle, ReferencePattern } from '../types/trading';
import { X, Layers, Lock, Sparkles, Trophy, Calendar, ExternalLink } from 'lucide-react';

interface SynchronizedChartModalProps {
  match: HistoricalMatchItem | null;
  onClose: () => void;
  referencePattern: ReferencePattern | null;
  currentCandles: Candle[];
}

export const SynchronizedChartModal: React.FC<SynchronizedChartModalProps> = ({
  match,
  onClose,
  referencePattern,
  currentCandles
}) => {
  const [patternViewMode, setPatternViewMode] = useState<'ref' | 'recent'>('ref');

  // Compute Current Pattern Slice to compare cleanly with Historical Match
  const currentSlice = useMemo(() => {
    if (patternViewMode === 'ref' && referencePattern && referencePattern.candles.length > 0) {
      return referencePattern.candles;
    }
    const targetLength = match?.candles?.length || 15;
    if (currentCandles.length > targetLength) {
      return currentCandles.slice(-targetLength);
    }
    return currentCandles.length > 0 ? currentCandles : [];
  }, [patternViewMode, referencePattern, currentCandles, match]);

  // Current Pattern Price Bounds
  const { currMinP, currMaxP, currPRange } = useMemo(() => {
    if (currentSlice.length === 0) return { currMinP: 0, currMaxP: 1, currPRange: 1 };
    const minP = Math.min(...currentSlice.map(c => c.low));
    const maxP = Math.max(...currentSlice.map(c => c.high));
    return { currMinP: minP, currMaxP: maxP, currPRange: Math.max(0.0001, maxP - minP) };
  }, [currentSlice]);

  // Historical Match Price Bounds
  const { matchMinP, matchMaxP, matchPRange } = useMemo(() => {
    if (!match || match.candles.length === 0) return { matchMinP: 0, matchMaxP: 1, matchPRange: 1 };
    const minP = Math.min(...match.candles.map(c => c.low));
    const maxP = Math.max(...match.candles.map(c => c.high));
    return { matchMinP: minP, matchMaxP: maxP, matchPRange: Math.max(0.0001, maxP - minP) };
  }, [match]);

  if (!match) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-[#0B0F19] border border-cyan-500/40 rounded-2xl w-full max-w-5xl max-h-[90vh] overflow-y-auto p-6 shadow-2xl shadow-cyan-500/20 font-mono">
        {/* Modal Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-cyan-950 border border-cyan-500/40 flex items-center justify-center">
              <Layers className="w-5 h-5 text-cyan-400" />
            </div>
            <div>
              <h3 className="text-base font-extrabold text-slate-100">
                Synchronized Historical Comparison Viewer
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Comparing Current Market vs Historical Match: <strong className="text-cyan-400">{match.patternName}</strong> ({match.date})
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-4 bg-slate-900 border border-slate-800 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Side-By-Side Synchronized Chart Viewer */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          {/* Chart 1: Current Live Pattern */}
          <div className="bg-[#070A10] rounded-xl p-4 border border-slate-800 flex flex-col justify-between">
            <div className="flex justify-between items-center text-xs mb-3 pb-2 border-b border-slate-800">
              <span className="font-bold text-slate-200 flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-cyan-400"></span>
                CURRENT MARKET PATTERN ({currentSlice.length} Candles)
              </span>
              <div className="flex items-center gap-1.5">
                {referencePattern && (
                  <button
                    onClick={() => setPatternViewMode('ref')}
                    className={`text-[10px] px-2 py-0.5 rounded font-bold transition-all ${
                      patternViewMode === 'ref'
                        ? 'bg-cyan-950 text-cyan-400 border border-cyan-500/50'
                        : 'bg-slate-900 text-slate-400 border border-slate-800'
                    }`}
                  >
                    Locked Ref 🔒
                  </button>
                )}
                <button
                  onClick={() => setPatternViewMode('recent')}
                  className={`text-[10px] px-2 py-0.5 rounded font-bold transition-all ${
                    patternViewMode === 'recent' || !referencePattern
                      ? 'bg-cyan-950 text-cyan-400 border border-cyan-500/50'
                      : 'bg-slate-900 text-slate-400 border border-slate-800'
                  }`}
                >
                  Recent Market
                </button>
              </div>
            </div>

            {/* SVG Render Current Pattern */}
            <div className="h-44 bg-grid-pattern rounded border border-slate-900 p-3 flex flex-col justify-between relative overflow-hidden">
              <div className="absolute top-2 right-3 text-[10px] text-slate-500 font-bold">
                H: {currMaxP.toFixed(2)} | L: {currMinP.toFixed(2)}
              </div>
              <svg width="100%" height="100%" viewBox="0 0 300 120" preserveAspectRatio="none">
                {/* Horizontal guide lines */}
                <line x1="0" y1="20" x2="300" y2="20" stroke="#1E293B" strokeDasharray="3 3" strokeWidth="0.8" />
                <line x1="0" y1="60" x2="300" y2="60" stroke="#1E293B" strokeDasharray="3 3" strokeWidth="0.8" />
                <line x1="0" y1="100" x2="300" y2="100" stroke="#1E293B" strokeDasharray="3 3" strokeWidth="0.8" />

                {currentSlice.map((c, i) => {
                  const total = currentSlice.length;
                  const slotW = 300 / total;
                  const barW = Math.max(3, slotW * 0.55);
                  const xCenter = i * slotW + slotW / 2;
                  const xLeft = xCenter - barW / 2;

                  const openY = 105 - ((c.open - currMinP) / currPRange) * 90;
                  const closeY = 105 - ((c.close - currMinP) / currPRange) * 90;
                  const highY = 105 - ((c.high - currMinP) / currPRange) * 90;
                  const lowY = 105 - ((c.low - currMinP) / currPRange) * 90;
                  const isBull = c.isBullish;

                  return (
                    <g key={i}>
                      <line
                        x1={xCenter}
                        y1={highY}
                        x2={xCenter}
                        y2={lowY}
                        stroke={isBull ? '#10B981' : '#EF4444'}
                        strokeWidth="1.2"
                      />
                      <rect
                        x={xLeft}
                        y={Math.min(openY, closeY)}
                        width={barW}
                        height={Math.max(3, Math.abs(closeY - openY))}
                        fill={isBull ? '#10B981' : '#EF4444'}
                        rx="0.5"
                      />
                    </g>
                  );
                })}
              </svg>
              <div className="flex justify-between items-center text-[10px] text-slate-500 pt-1 border-t border-slate-900">
                <span>Start: {currentSlice[0]?.open?.toFixed(2) || '--'}</span>
                <span>Last Close: <strong className={currentSlice[currentSlice.length - 1]?.isBullish ? 'text-emerald-400' : 'text-rose-400'}>{currentSlice[currentSlice.length - 1]?.close?.toFixed(2) || '--'}</strong></span>
              </div>
            </div>
          </div>

          {/* Chart 2: Synchronized Historical Match Pattern */}
          <div className="bg-[#070A10] rounded-xl p-4 border border-cyan-500/30 flex flex-col justify-between">
            <div className="flex justify-between items-center text-xs mb-3 pb-2 border-b border-cyan-500/20">
              <span className="font-bold text-cyan-300 flex items-center gap-2">
                <Trophy className="w-4 h-4 text-cyan-400" />
                HISTORICAL MATCH ({match.asset} — {match.date})
              </span>
              <span className="text-xs text-cyan-400 font-extrabold">{match.historicalMatchPct}% MATCH</span>
            </div>

            {/* SVG Render Historical Match */}
            <div className="h-44 bg-grid-pattern rounded border border-slate-900 p-3 flex flex-col justify-between relative overflow-hidden">
              <div className="absolute top-2 right-3 text-[10px] text-cyan-500 font-bold">
                H: {matchMaxP.toFixed(2)} | L: {matchMinP.toFixed(2)}
              </div>
              <svg width="100%" height="100%" viewBox="0 0 300 120" preserveAspectRatio="none">
                {/* Horizontal guide lines */}
                <line x1="0" y1="20" x2="300" y2="20" stroke="#1E293B" strokeDasharray="3 3" strokeWidth="0.8" />
                <line x1="0" y1="60" x2="300" y2="60" stroke="#1E293B" strokeDasharray="3 3" strokeWidth="0.8" />
                <line x1="0" y1="100" x2="300" y2="100" stroke="#1E293B" strokeDasharray="3 3" strokeWidth="0.8" />

                {match.candles.map((c, i) => {
                  const total = match.candles.length;
                  const slotW = 300 / total;
                  const barW = Math.max(3, slotW * 0.55);
                  const xCenter = i * slotW + slotW / 2;
                  const xLeft = xCenter - barW / 2;

                  const openY = 105 - ((c.open - matchMinP) / matchPRange) * 90;
                  const closeY = 105 - ((c.close - matchMinP) / matchPRange) * 90;
                  const highY = 105 - ((c.high - matchMinP) / matchPRange) * 90;
                  const lowY = 105 - ((c.low - matchMinP) / matchPRange) * 90;
                  const isBull = c.isBullish;

                  return (
                    <g key={i}>
                      <line
                        x1={xCenter}
                        y1={highY}
                        x2={xCenter}
                        y2={lowY}
                        stroke={isBull ? '#10B981' : '#EF4444'}
                        strokeWidth="1.2"
                      />
                      <rect
                        x={xLeft}
                        y={Math.min(openY, closeY)}
                        width={barW}
                        height={Math.max(3, Math.abs(closeY - openY))}
                        fill={isBull ? '#10B981' : '#EF4444'}
                        rx="0.5"
                      />
                    </g>
                  );
                })}
              </svg>
              <div className="flex justify-between items-center text-[10px] text-slate-500 pt-1 border-t border-slate-900">
                <span>Result Move: <strong className="text-emerald-400">+{match.averageMovePct}%</strong></span>
                <span>Win Rate: <strong className="text-emerald-400">{match.winRatePct}%</strong></span>
              </div>
            </div>
          </div>
        </div>

        {/* Detailed Comparative Summary Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-xs bg-slate-950/80 p-4 rounded-xl border border-slate-800">
          <div>
            <span className="text-slate-500 text-xs uppercase font-bold block">Historical Win Rate</span>
            <span className="text-base font-bold text-emerald-400">{match.winRatePct}%</span>
          </div>
          <div>
            <span className="text-slate-500 text-xs uppercase font-bold block">Loss Rate</span>
            <span className="text-base font-bold text-red-400">{match.lossRatePct}%</span>
          </div>
          <div>
            <span className="text-slate-500 text-xs uppercase font-bold block">Avg Post-Pattern Move</span>
            <span className="text-base font-bold text-cyan-400">+{match.averageMovePct}%</span>
          </div>
          <div>
            <span className="text-slate-500 text-xs uppercase font-bold block">Sample Occurrence Count</span>
            <span className="text-base font-bold text-slate-200">{match.sampleSize} Trades</span>
          </div>
        </div>
      </div>
    </div>
  );
};

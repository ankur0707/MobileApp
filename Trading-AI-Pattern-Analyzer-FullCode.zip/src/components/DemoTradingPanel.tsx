import React, { useState, useEffect } from 'react';
import { DollarSign, TrendingUp, TrendingDown, Clock, Activity, ListChecks } from 'lucide-react';
import { DemoPosition, DemoTrade, Candle } from '../types/trading';

interface DemoTradingPanelProps {
  balance: number;
  currentPosition: DemoPosition | null;
  tradeHistory: DemoTrade[];
  candles: Candle[];
  onBuy: () => void;
  onSell: () => void;
  onClosePosition: () => void;
}

export const DemoTradingPanel: React.FC<DemoTradingPanelProps> = ({
  balance,
  currentPosition,
  tradeHistory,
  candles,
  onBuy,
  onSell,
  onClosePosition
}) => {
  const currentPrice = candles[candles.length - 1]?.close || 0;
  
  // Calculate Live PnL
  const [livePnl, setLivePnl] = useState<number>(0);

  useEffect(() => {
    if (currentPosition && currentPrice > 0) {
      const leverage = currentPosition.asset.includes('BTC') ? 1 : 100;
      const diff = currentPosition.type === 'LONG' 
        ? currentPrice - currentPosition.entryPrice 
        : currentPosition.entryPrice - currentPrice;
      setLivePnl(diff * leverage);
    } else {
      setLivePnl(0);
    }
  }, [currentPrice, currentPosition]);

  return (
    <div className="glass-panel p-4 flex flex-col gap-4">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
        <div className="flex items-center space-x-2 text-cyan-400">
          <Activity className="w-5 h-5" />
          <h2 className="font-bold text-sm tracking-wider">DEMO TRADING TERMINAL</h2>
        </div>
        <div className="bg-slate-900/80 border border-slate-700 rounded px-3 py-1 flex items-center space-x-2 shadow-inner">
          <DollarSign className="w-3.5 h-3.5 text-emerald-400" />
          <span className="text-sm font-bold text-slate-200">
            {balance.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </span>
        </div>
      </div>

      {/* Trade Execution Controls */}
      <div className="flex space-x-3">
        <button 
          onClick={onBuy}
          disabled={!!currentPosition}
          className={`flex-1 flex flex-col items-center py-3 rounded-lg border font-bold transition-all ${
            currentPosition 
              ? 'opacity-50 cursor-not-allowed bg-slate-900 border-slate-800 text-slate-500'
              : 'bg-emerald-950/40 border-emerald-500/50 text-emerald-400 hover:bg-emerald-900 hover:border-emerald-400 shadow-[0_0_15px_rgba(16,185,129,0.15)] hover:shadow-[0_0_20px_rgba(16,185,129,0.3)]'
          }`}
        >
          <span className="text-[10px] uppercase tracking-widest opacity-80 mb-1">Market</span>
          <span className="text-lg">BUY (LONG)</span>
        </button>

        <button 
          onClick={onSell}
          disabled={!!currentPosition}
          className={`flex-1 flex flex-col items-center py-3 rounded-lg border font-bold transition-all ${
            currentPosition 
              ? 'opacity-50 cursor-not-allowed bg-slate-900 border-slate-800 text-slate-500'
              : 'bg-rose-950/40 border-rose-500/50 text-rose-400 hover:bg-rose-900 hover:border-rose-400 shadow-[0_0_15px_rgba(225,29,72,0.15)] hover:shadow-[0_0_20px_rgba(225,29,72,0.3)]'
          }`}
        >
          <span className="text-[10px] uppercase tracking-widest opacity-80 mb-1">Market</span>
          <span className="text-lg">SELL (SHORT)</span>
        </button>
      </div>

      {/* Active Position Tracker */}
      {currentPosition && (
        <div className="mt-2 bg-[#0B0F19] border border-cyan-900/50 rounded-lg p-3">
          <div className="flex justify-between items-center mb-3">
            <span className="text-xs text-slate-400 font-bold tracking-widest">ACTIVE POSITION</span>
            <span className={`text-[10px] px-2 py-0.5 rounded border font-bold ${
              currentPosition.type === 'LONG' 
                ? 'bg-emerald-950/50 border-emerald-500/30 text-emerald-400'
                : 'bg-rose-950/50 border-rose-500/30 text-rose-400'
            }`}>
              {currentPosition.type} • {currentPosition.asset}
            </span>
          </div>

          <div className="grid grid-cols-2 gap-4 mb-4">
            <div>
              <div className="text-[10px] text-slate-500 mb-1">ENTRY PRICE</div>
              <div className="text-sm font-bold text-slate-300">{currentPosition.entryPrice.toFixed(2)}</div>
            </div>
            <div className="text-right">
              <div className="text-[10px] text-slate-500 mb-1">LIVE PnL</div>
              <div className={`text-lg font-black ${livePnl >= 0 ? 'text-emerald-400' : 'text-rose-400'} drop-shadow-md`}>
                {livePnl >= 0 ? '+' : ''}{livePnl.toFixed(2)}
              </div>
            </div>
          </div>

          <button 
            onClick={onClosePosition}
            className="w-full py-2 bg-slate-800 hover:bg-slate-700 border border-slate-600 rounded text-sm font-bold text-white transition-colors"
          >
            CLOSE POSITION
          </button>
        </div>
      )}

      {/* Mini Trade Journal Preview */}
      {tradeHistory.length > 0 && !currentPosition && (
        <div className="mt-2 flex-1 flex flex-col min-h-0">
          <div className="flex items-center space-x-2 text-slate-400 text-xs font-bold tracking-widest mb-2">
            <ListChecks className="w-4 h-4" />
            <span>RECENT TRADES ({tradeHistory.length})</span>
          </div>
          <div className="flex-1 overflow-y-auto pr-2 space-y-2 custom-scrollbar">
            {tradeHistory.slice(0, 5).map(trade => (
              <div key={trade.id} className="bg-[#0B0F19] border border-slate-800/60 rounded p-2 flex justify-between items-center text-xs">
                <div>
                  <span className={trade.type === 'LONG' ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
                    {trade.type}
                  </span>
                  <span className="text-slate-500 ml-2">
                    {trade.entryPrice.toFixed(2)} → {trade.exitPrice.toFixed(2)}
                  </span>
                </div>
                <div className={`font-bold ${trade.pnl >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                  {trade.pnl >= 0 ? '+' : ''}{trade.pnl.toFixed(2)}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

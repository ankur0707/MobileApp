import React from 'react';
import { AutoScannerItem } from '../types/trading';
import { Radar, ArrowUpRight, ArrowDownRight, Layers, Sparkles, Filter } from 'lucide-react';

interface AutoPatternScannerProps {
  scannerItems: AutoScannerItem[];
  onSelectScannerSymbol: (symbol: string, timeframe: string) => void;
}

export const AutoPatternScanner: React.FC<AutoPatternScannerProps> = ({ scannerItems, onSelectScannerSymbol }) => {
  return (
    <div className="glass-panel rounded-xl p-5 border border-slate-800">
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-3 mb-4">
        <div className="flex items-center space-x-2">
          <div className="w-8 h-8 rounded-lg bg-cyan-950 border border-cyan-500/40 flex items-center justify-center">
            <Radar className="w-4 h-4 text-cyan-400 animate-spin" style={{ animationDuration: '8s' }} />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-100 font-mono">Auto Pattern Scanner</h3>
            <p className="text-xs text-slate-400 font-mono">Automated multi-asset scanner discovering high-probability historical setups</p>
          </div>
        </div>

        <span className="text-xs text-cyan-400 font-mono bg-cyan-950/80 px-2.5 py-1 rounded border border-cyan-500/40 font-bold">
          LIVE SCANNER ACTIVE 📡
        </span>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left font-mono text-xs">
          <thead>
            <tr className="text-slate-500 border-b border-slate-800 text-xs uppercase">
              <th className="pb-2 px-3">Symbol</th>
              <th className="pb-2 px-3">Timeframe</th>
              <th className="pb-2 px-3">Pattern Classification</th>
              <th className="pb-2 px-3">Match %</th>
              <th className="pb-2 px-3">Direction</th>
              <th className="pb-2 px-3">Win Rate</th>
              <th className="pb-2 px-3">Avg Move</th>
              <th className="pb-2 px-3 text-right">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-850">
            {scannerItems.map((item) => (
              <tr key={item.id} className="hover:bg-slate-900/60 transition-colors">
                <td className="py-3 px-3 font-bold text-slate-100">{item.symbol}</td>
                <td className="py-3 px-3 text-cyan-400 font-bold">{item.timeframe}</td>
                <td className="py-3 px-3 text-slate-300">{item.patternName}</td>
                <td className="py-3 px-3 font-extrabold text-cyan-400">{item.matchPct}%</td>
                <td className="py-3 px-3">
                  <span className={`px-2 py-0.5 rounded text-xs font-bold ${
                    item.direction === 'Bullish' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-400'
                  }`}>
                    {item.direction}
                  </span>
                </td>
                <td className="py-3 px-3 text-emerald-400 font-bold">{item.winRatePct}%</td>
                <td className="py-3 px-3 text-emerald-400 font-bold">{item.avgMovePct}%</td>
                <td className="py-3 px-3 text-right">
                  <button
                    onClick={() => onSelectScannerSymbol(item.symbol, item.timeframe)}
                    className="px-2.5 py-1 bg-slate-800 hover:bg-cyan-600 hover:text-black text-slate-200 text-sm font-bold rounded border border-slate-700 transition-all"
                  >
                    Analyze Chart
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

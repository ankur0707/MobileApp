import React from 'react';
import {
  LayoutDashboard,
  Radar,
  LineChart,
  Grid,
  Scissors,
  History,
  Briefcase,
  BookOpen,
  Bell,
  Brain,
  FileText,
  Settings,
  PlusCircle,
  Upload,
  Download,
  Clock,
  ChevronLeft,
  ChevronRight,
  PanelLeftClose,
  PanelLeftOpen
} from 'lucide-react';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onResetPattern: () => void;
  isCollapsed: boolean;
  onToggleCollapse: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  setActiveTab,
  onResetPattern,
  isCollapsed,
  onToggleCollapse
}) => {
  const mainNav = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'scanner', label: 'AI Pattern Scanner', icon: Radar },
    { id: 'explorer', label: 'Pattern Explorer', icon: LineChart },
    { id: 'journal', label: 'Trade Journal', icon: BookOpen },
    { id: 'market', label: 'Market Explorer', icon: Grid },
    { id: 'strategy', label: 'Strategy Builder', icon: Scissors },
    { id: 'backtest', label: 'Backtesting', icon: History },
    { id: 'portfolio', label: 'Portfolio', icon: Briefcase },
    { id: 'alerts', label: 'Alerts', icon: Bell },
    { id: 'learning', label: 'AI Learning', icon: Brain },
    { id: 'reports', label: 'Reports', icon: FileText },
    { id: 'settings', label: 'Settings', icon: Settings }
  ];

  if (isCollapsed) {
    return (
      <aside className="w-12 bg-[#090D16] border-r border-slate-800/80 flex flex-col justify-between items-center py-3 flex-shrink-0 select-none transition-all duration-300">
        <div className="space-y-3 w-full flex flex-col items-center">
          <button
            onClick={onToggleCollapse}
            title="Expand Navigation Sidebar (One-Click View)"
            className="p-3 bg-slate-800 hover:bg-cyan-950 text-cyan-400 rounded-lg border border-cyan-500/40 transition-all shadow-md"
          >
            <PanelLeftOpen className="w-4 h-4" />
          </button>

          <div className="w-8 h-[1px] bg-slate-800 my-1"></div>

          {mainNav.map(item => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                title={item.label}
                className={`p-4 rounded-lg transition-all ${
                  isActive ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/40' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Icon className="w-4 h-4" />
              </button>
            );
          })}
        </div>

        <button
          onClick={onResetPattern}
          title="New Pattern"
          className="p-4 bg-slate-900 text-cyan-400 rounded-lg border border-slate-800 hover:border-cyan-500/40"
        >
          <PlusCircle className="w-4 h-4" />
        </button>
      </aside>
    );
  }

  return (
    <aside className="w-56 bg-[#090D16] border-r border-slate-800/80 flex flex-col justify-between py-3 px-2 flex-shrink-0 select-none transition-all duration-300">
      {/* Top Header & Collapse Button */}
      <div className="space-y-1">
        <div className="flex items-center justify-between px-2 pb-2 mb-1 border-b border-slate-800/60">
          <span className="text-xs font-extrabold uppercase tracking-wider text-slate-400">NAVIGATION</span>
          <button
            onClick={onToggleCollapse}
            title="Hide Sidebar (One-Click Hide)"
            className="p-1 text-slate-400 hover:text-cyan-400 hover:bg-slate-900 rounded transition-all"
          >
            <PanelLeftClose className="w-4 h-4" />
          </button>
        </div>

        {mainNav.map(item => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center space-x-2.5 px-3 py-2 rounded-lg text-xs font-mono font-medium transition-all ${
                isActive
                  ? 'bg-gradient-to-r from-blue-900/60 to-cyan-950/60 text-cyan-300 border border-cyan-500/40 shadow-md shadow-cyan-950/40'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
              }`}
            >
              <Icon className={`w-4 h-4 ${isActive ? 'text-cyan-400' : 'text-slate-400'}`} />
              <span className="truncate">{item.label}</span>
            </button>
          );
        })}
      </div>

      {/* Bottom Quick Actions Box */}
      <div className="pt-3 border-t border-slate-800/80 space-y-1.5 font-mono text-xs">
        <span className="text-xs text-slate-500 font-bold uppercase px-3 block">QUICK ACTIONS</span>
        
        <button
          onClick={onResetPattern}
          className="w-full flex items-center space-x-2 px-3 py-1.5 rounded-md bg-slate-900/80 border border-slate-800 text-slate-200 hover:text-white hover:border-slate-700 transition-all text-sm"
        >
          <PlusCircle className="w-3.5 h-3.5 text-cyan-400" />
          <span>New Pattern</span>
        </button>

        <button className="w-full flex items-center space-x-2 px-3 py-1.5 rounded-md bg-slate-900/80 border border-slate-800 text-slate-300 hover:text-white transition-all text-sm">
          <Upload className="w-3.5 h-3.5 text-slate-400" />
          <span>Load Data</span>
        </button>

        <button className="w-full flex items-center space-x-2 px-3 py-1.5 rounded-md bg-slate-900/80 border border-slate-800 text-slate-300 hover:text-white transition-all text-sm">
          <Download className="w-3.5 h-3.5 text-slate-400" />
          <span>Export Report</span>
        </button>

        <button className="w-full flex items-center space-x-2 px-3 py-1.5 rounded-md bg-slate-900/80 border border-slate-800 text-slate-300 hover:text-white transition-all text-sm">
          <Clock className="w-3.5 h-3.5 text-slate-400" />
          <span>View History</span>
        </button>
      </div>
    </aside>
  );
};

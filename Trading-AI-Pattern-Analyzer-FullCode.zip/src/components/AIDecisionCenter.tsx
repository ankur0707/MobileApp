import React from 'react';
import { AIDecisionSummary } from '../types/trading';
import { ShieldCheck, Check, Clock } from 'lucide-react';

interface AIDecisionCenterProps {
  decision: AIDecisionSummary | null;
}

export const AIDecisionCenter: React.FC<AIDecisionCenterProps> = ({ decision }) => {
  if (!decision) return null;

  const circumference = 2 * Math.PI * 34;
  const strokeDashoffset = circumference - (decision.overallConfidencePct / 100) * circumference;

  return (
    <div className="glass-panel-glow-green rounded-xl p-4 border border-emerald-500/40 font-mono text-xs select-none">
      <div className="flex items-center space-x-2 pb-2.5 mb-3 border-b border-emerald-500/20">
        <ShieldCheck className="w-4 h-4 text-emerald-400" />
        <h3 className="text-xs font-extrabold uppercase tracking-widest text-slate-100">
          AI DECISION CENTER
        </h3>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-center">
        {/* Overall Confidence Gauge */}
        <div className="lg:col-span-3 flex flex-col items-center justify-center text-center bg-slate-950/80 p-3 rounded-lg border border-slate-800">
          <div className="relative w-24 h-24 flex items-center justify-center my-1">
            <svg className="w-full h-full transform -rotate-90">
              <circle cx="48" cy="48" r="34" stroke="#1E293B" strokeWidth="6" fill="transparent" />
              <circle
                cx="48"
                cy="48"
                r="34"
                stroke="#10B981"
                strokeWidth="6"
                fill="transparent"
                strokeDasharray={circumference}
                strokeDashoffset={strokeDashoffset}
                strokeLinecap="round"
              />
            </svg>
            <div className="absolute text-center">
              <span className="text-xl font-extrabold text-white">{decision.overallConfidencePct}%</span>
            </div>
          </div>
          <span className="text-xs text-slate-400 font-bold uppercase tracking-wider">OVERALL CONFIDENCE</span>
        </div>

        {/* Middle Statistical Breakdown List */}
        <div className="lg:col-span-5 space-y-1 bg-slate-950/80 p-4 rounded-lg border border-slate-800 text-sm">
          <div className="flex justify-between items-center py-0.5 border-b border-slate-900">
            <span className="text-slate-400">Trade Quality</span>
            <span className="text-emerald-400 font-bold">HIGH</span>
          </div>

          <div className="flex justify-between items-center py-0.5 border-b border-slate-900">
            <span className="text-slate-400">Historical Integrity</span>
            <span className="text-slate-200 font-bold">{decision.historicalIntegrityPct}%</span>
          </div>

          <div className="flex justify-between items-center py-0.5 border-b border-slate-900">
            <span className="text-slate-400">Winning Structure Similarity</span>
            <span className="text-emerald-400 font-bold">{decision.winningSimilarityPct}%</span>
          </div>

          <div className="flex justify-between items-center py-0.5 border-b border-slate-900">
            <span className="text-slate-400">Losing Structure Similarity</span>
            <span className="text-rose-400 font-bold">{decision.losingSimilarityPct}%</span>
          </div>

          <div className="flex justify-between items-center py-0.5 border-b border-slate-900">
            <span className="text-slate-400">Pattern Stability</span>
            <span className="text-emerald-400 font-bold">STRONG</span>
          </div>

          <div className="flex justify-between items-center py-0.5 border-b border-slate-900">
            <span className="text-slate-400">Historical Confidence</span>
            <span className="text-slate-200 font-bold">{decision.historicalConfidencePct}%</span>
          </div>

          <div className="flex justify-between items-center py-0.5 border-b border-slate-900">
            <span className="text-slate-400">Risk Score</span>
            <span className="text-amber-400 font-bold">MEDIUM ({decision.riskScorePct}%)</span>
          </div>

          <div className="flex justify-between items-center py-0.5 border-b border-slate-900">
            <span className="text-slate-400">Market Structure Score</span>
            <span className="text-emerald-400 font-bold">GOOD (72%)</span>
          </div>

          <div className="flex justify-between items-center py-0.5">
            <span className="text-slate-400">Trade Health</span>
            <span className="text-emerald-400 font-bold">{decision.tradeHealthPct}%</span>
          </div>
        </div>

        {/* Right Final Recommendation Block */}
        <div className="lg:col-span-4 bg-slate-950/80 p-3 rounded-lg border border-emerald-500/30 flex flex-col justify-between h-full">
          <div>
            <span className="text-xs text-slate-400 font-bold uppercase block mb-1">FINAL RECOMMENDATION</span>
            
            {/* Big Green Badge */}
            <div className="bg-emerald-500/20 border border-emerald-500/50 rounded-lg p-4 text-center mb-2">
              <span className="text-base font-extrabold text-emerald-400 tracking-wider">
                CONTINUE HOLDING
              </span>
            </div>

            {/* Checklist */}
            <div className="space-y-1 text-xs font-bold text-slate-300">
              <div className="flex items-center space-x-1.5 text-emerald-400">
                <Check className="w-3.5 h-3.5" />
                <span>High Probability Setup</span>
              </div>
              <div className="flex items-center space-x-1.5 text-emerald-400">
                <Check className="w-3.5 h-3.5" />
                <span>Historical Evidence Strong</span>
              </div>
              <div className="flex items-center space-x-1.5 text-emerald-400">
                <Check className="w-3.5 h-3.5" />
                <span>Pattern Intact</span>
              </div>
              <div className="flex items-center space-x-1.5 text-emerald-400">
                <Check className="w-3.5 h-3.5" />
                <span>Risk Under Control</span>
              </div>
            </div>
          </div>

          {/* Footer Timestamp */}
          <div className="mt-3 pt-2 border-t border-slate-900 text-xs text-slate-500 flex items-center justify-between">
            <span className="uppercase font-bold">LAST UPDATED</span>
            <span>01 Jun 2025 21:32:00</span>
          </div>
        </div>
      </div>
    </div>
  );
};

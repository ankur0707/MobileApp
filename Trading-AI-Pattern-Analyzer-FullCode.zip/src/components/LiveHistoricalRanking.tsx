import React from 'react';
import { HistoricalMatchItem } from '../types/trading';

interface LiveHistoricalRankingProps {
  matches: HistoricalMatchItem[];
  onSelectMatch: (match: HistoricalMatchItem) => void;
  onViewAllMatches?: () => void;
}

export const LiveHistoricalRanking: React.FC<LiveHistoricalRankingProps> = ({ matches, onSelectMatch, onViewAllMatches }) => {
  return (
    <div className="glass-panel rounded-xl p-4 border border-slate-800 font-mono text-xs h-full flex flex-col justify-between select-none">
      <div className="flex items-center justify-between border-b border-slate-800 pb-1 mb-1">
        <h4 className="font-extrabold uppercase text-slate-100 text-xs">TOP HISTORICAL MATCHES (LIVE RANKING)</h4>
        <button
          onClick={onViewAllMatches}
          className="text-xs text-cyan-400 hover:text-cyan-300 font-bold bg-cyan-950/40 hover:bg-cyan-900/60 border border-cyan-500/30 px-2 py-0.5 rounded transition-all cursor-pointer flex items-center gap-1"
        >
          View All Matches →
        </button>
      </div>

      <div className="grid grid-cols-5 gap-3 flex-1 items-center">
        {matches.slice(0, 5).map((item, idx) => (
          <div
            key={item.id}
            onClick={() => onSelectMatch(item)}
            className="bg-slate-950/80 p-3 rounded border border-slate-800 hover:border-cyan-500/50 transition-all cursor-pointer space-y-0.5 text-center"
          >
            <div className="flex justify-between items-center text-sm">
              <span className="font-bold text-cyan-400">#{idx + 1} MATCH</span>
              <span className="text-emerald-400 font-extrabold">{item.historicalMatchPct}%</span>
            </div>
            <div className="text-slate-400 text-sm">Win Rate: <strong className="text-emerald-400">{item.winRatePct}%</strong></div>
            <div className="text-slate-400 text-sm">Avg Move: <strong className="text-emerald-400">+{item.averageMovePct}%</strong></div>
            <div className="text-slate-400 text-sm">Samples: <strong className="text-slate-200">{item.sampleSize}</strong></div>
            <div className="text-amber-400 text-sm tracking-tighter">⭐⭐⭐⭐⭐</div>
            <button className="w-full mt-1 py-0.5 bg-slate-900 hover:bg-cyan-950 hover:text-cyan-400 text-slate-300 rounded text-sm border border-slate-800 font-bold transition-all">
              Preview
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

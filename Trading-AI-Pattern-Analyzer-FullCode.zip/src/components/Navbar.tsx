import React from 'react';
import { RefreshCw, Settings, SlidersHorizontal, Brain, Play, Pause, SkipForward, RotateCcw, Activity, Search } from 'lucide-react';
import { Candle } from '../types/trading';

interface NavbarProps {
  selectedAsset: string;
  setSelectedAsset: (asset: string) => void;
  selectedTimeframe: string;
  setSelectedTimeframe: (tf: string) => void;
  selectedRange?: string;
  setSelectedRange?: (range: string) => void;
  isSimulating: boolean;
  setIsSimulating: (sim: boolean) => void;
  onStepNextCandle: () => void;
  onResetSimulation: () => void;
  onOpenCustomizer: () => void;
  onOpenMatchCustomizer: () => void;
  onOpenApiSettings: () => void;
  onOpenSymbolSearch: () => void;
  candles?: Candle[];
  isSocketConnected?: boolean;
  isMarketOpen?: boolean;
  marketStatusText?: string;
}

export const Navbar: React.FC<NavbarProps> = ({
  selectedAsset,
  setSelectedAsset,
  selectedTimeframe,
  setSelectedTimeframe,
  selectedRange = '1y',
  setSelectedRange = () => {},
  isSimulating,
  setIsSimulating,
  onStepNextCandle,
  onResetSimulation,
  onOpenCustomizer,
  onOpenMatchCustomizer,
  onOpenApiSettings,
  onOpenSymbolSearch,
  candles = [],
  isSocketConnected = true,
  isMarketOpen = false,
  marketStatusText = 'MARKET CLOSED'
}) => {
  const lastCandle = candles[candles.length - 1];
  const prevCandle = candles[candles.length - 2] || lastCandle;
  const currentPrice = lastCandle ? lastCandle.close : 0;
  const priceDiff = lastCandle && prevCandle ? lastCandle.close - prevCandle.open : 0;
  const diffPct = prevCandle && prevCandle.open ? (priceDiff / prevCandle.open) * 100 : 0;
  const isPositive = priceDiff >= 0;
  const lastTime = lastCandle ? new Date(lastCandle.time).toLocaleTimeString() : '--:--:--';

  return (
    <header className="bg-[#090D16] border-b border-slate-800/80 px-4 py-2 flex flex-wrap items-center justify-between gap-3 text-xs font-mono select-none z-50">
      {/* App Brand Logo */}
      <div className="flex items-center space-x-2.5">
        <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-emerald-600 via-teal-500 to-cyan-400 flex items-center justify-center shadow-lg shadow-emerald-500/20">
          <Brain className="w-5 h-5 text-black font-extrabold" />
        </div>
        <div>
          <div className="flex items-center space-x-1.5">
            <span className="font-extrabold text-sm text-slate-100 tracking-wider">AI PATTERN ANALYZER</span>
            <span className="text-xs font-extrabold bg-emerald-500 text-black px-1.5 py-0.2 rounded tracking-widest">
              PRO
            </span>
          </div>
          <p className="text-xs text-slate-400 font-mono tracking-tight">Historical AI Decision Engine</p>
        </div>
      </div>

      {/* Broker & Market Status Bar */}
      <div className="flex items-center space-x-4 bg-slate-950/80 px-3 py-1.5 rounded-lg border border-slate-800">
        <div className="flex items-center space-x-1.5">
          <span className="text-xs text-slate-500 font-bold uppercase">BROKER</span>
          {isSocketConnected ? (
            <span className="flex items-center gap-1.5 text-emerald-400 font-bold text-sm">
              <span className="w-2 h-2 rounded-full bg-emerald-400 inline-block animate-ping"></span>
              Kotak Connected
            </span>
          ) : (
            <span className="flex items-center gap-1.5 text-rose-400 font-bold text-sm" title="Backend server se connection nahi hai. Data feed band hai.">
              <span className="w-2 h-2 rounded-full bg-rose-400 inline-block"></span>
              API Disconnected
            </span>
          )}
        </div>

        {/* Real Market Status Badge — LIVE only when socket connected AND market open */}
        <div className="flex items-center space-x-1.5 border-l border-slate-800 pl-3">
          <span className="text-xs text-slate-500 font-bold uppercase">MARKET</span>
          {isSocketConnected && isMarketOpen ? (
            <span className="text-emerald-400 font-bold text-sm flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-400 inline-block animate-ping"></span>
              LIVE
            </span>
          ) : !isSocketConnected ? (
            <span
              className="text-rose-400 font-bold text-xs flex items-center gap-1.5 bg-rose-950/50 border border-rose-500/40 px-2 py-0.5 rounded shadow-sm"
              title="API se connected nahi — live data available nahi hai."
            >
              <span className="w-1.5 h-1.5 rounded-full bg-rose-400"></span>
              NO DATA
            </span>
          ) : (
            <span
              className="text-amber-400 font-bold text-xs flex items-center gap-1.5 bg-amber-950/50 border border-amber-500/40 px-2 py-0.5 rounded shadow-sm"
              title="Indian Market Hours: 9:15 AM - 3:30 PM IST (Monday - Friday). Closed on Weekends & Evenings."
            >
              <span className="w-1.5 h-1.5 rounded-full bg-amber-400"></span>
              CLOSED
            </span>
          )}
        </div>

        {/* Universal Symbol Search Trigger */}
        <div className="flex items-center space-x-1.5 border-l border-slate-800 pl-3">
          <span className="text-xs text-slate-500 font-bold uppercase">SYMBOL</span>
          <button
            onClick={onOpenSymbolSearch}
            className="bg-slate-900 hover:bg-slate-800 text-cyan-300 hover:text-cyan-200 font-extrabold text-sm px-2.5 py-1 rounded-lg border border-slate-700 hover:border-cyan-500 flex items-center gap-2 transition-all shadow-sm group cursor-pointer"
            title="Click to search any stock or index (NSE / BSE / Indices)"
          >
            <span className="tracking-wide">{selectedAsset}</span>
            <span className="text-[10px] bg-cyan-950 text-cyan-400 px-1.5 py-0.5 rounded border border-cyan-500/40 group-hover:bg-cyan-900 transition-colors flex items-center gap-1">
              <Search className="w-2.5 h-2.5" /> SEARCH
            </span>
          </button>
        </div>

        {/* Timeframe Dropdown (1m Removed, Starts from 5m) */}
        <div className="flex items-center space-x-1.5 border-l border-slate-800 pl-3">
          <span className="text-xs text-slate-500 font-bold uppercase">TIMEFRAME</span>
          <select
            value={selectedTimeframe}
            onChange={(e) => setSelectedTimeframe(e.target.value)}
            className="bg-slate-900 text-cyan-300 font-bold text-sm px-2 py-0.5 rounded border border-slate-700 outline-none cursor-pointer hover:border-cyan-500 transition-colors"
          >
            <option value="5m">5m (Intraday)</option>
            <option value="15m">15m (Short-Term)</option>
            <option value="30m">30m (Swing)</option>
            <option value="1H">1H (Hourly)</option>
            <option value="4H">4H (4 Hours)</option>
            <option value="1D">1D (Daily)</option>
            <option value="1W">1W (Weekly)</option>
          </select>
        </div>

        {/* Customizable Analysis History Period (1Y to 5Y) */}
        <div className="flex items-center space-x-1.5 border-l border-slate-800 pl-3">
          <span className="text-xs text-slate-500 font-bold uppercase">PERIOD</span>
          <select
            value={selectedRange}
            onChange={(e) => setSelectedRange(e.target.value)}
            className="bg-slate-900 text-amber-400 font-bold text-sm px-2 py-0.5 rounded border border-amber-500/40 outline-none cursor-pointer hover:border-amber-400 transition-colors"
            title="Choose how many years of historical data to analyze"
          >
            <option value="1y">1 Year (1Y)</option>
            <option value="2y">2 Years (2Y)</option>
            <option value="3y">3 Years (3Y)</option>
            <option value="4y">4 Years (4Y)</option>
            <option value="5y">5 Years (5Y)</option>
          </select>
        </div>

        {/* Dynamic Current / Closing Price Display */}
        <div className="border-l border-slate-800 pl-3">
          <span className="text-xs text-slate-500 font-bold uppercase block">
            {isMarketOpen ? 'CURRENT PRICE' : 'OFFICIAL CLOSE'}
          </span>
          <div className="flex items-baseline space-x-2">
            <span className={`text-sm font-extrabold transition-colors duration-150 ${isPositive ? 'text-emerald-400' : 'text-rose-400'}`}>
              {currentPrice > 0 ? currentPrice.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : '23,897.70'}
            </span>
            <span className={`text-xs font-bold ${isPositive ? 'text-emerald-400' : 'text-rose-400'}`}>
              {isPositive ? '+' : ''}{priceDiff.toFixed(2)} ({isPositive ? '+' : ''}{diffPct.toFixed(2)}%)
            </span>
          </div>
        </div>

        {/* Last Candle / Market Closed Timestamp */}
        <div className="border-l border-slate-800 pl-3">
          <span className="text-xs text-slate-500 font-bold uppercase block">
            {isMarketOpen ? 'LAST TICK' : 'MARKET STATUS'}
          </span>
          <span className={`font-bold text-sm ${isMarketOpen ? 'text-cyan-300' : 'text-amber-400'}`}>
            {isMarketOpen ? lastTime : 'CLOSED (3:30 PM IST)'}
          </span>
        </div>
      </div>

      {/* Simulator & Action Buttons */}
      <div className="flex items-center space-x-2">
        {/* Play/Pause Simulation Ticker */}
        <div className="flex items-center space-x-1 bg-slate-950 p-1 rounded-lg border border-slate-800">
          <button
            onClick={() => setIsSimulating(!isSimulating)}
            className={`px-2 py-1 rounded flex items-center space-x-1 font-bold text-sm transition-all ${
              isSimulating
                ? 'bg-amber-500/20 text-amber-400 border border-amber-500/50'
                : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/50 hover:bg-emerald-500/30'
            }`}
          >
            {isSimulating ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5 fill-current" />}
            <span>{isSimulating ? 'Pause' : 'Live Feed'}</span>
          </button>
          
          <button
            onClick={onStepNextCandle}
            title="Step Next Candle (+1)"
            className="p-1 bg-slate-900 text-slate-300 hover:text-white rounded border border-slate-800"
          >
            <SkipForward className="w-3.5 h-3.5" />
          </button>
        </div>

        <button
          onClick={onOpenCustomizer}
          title="Customize Output Displays"
          className="px-2.5 py-1.5 bg-slate-900 hover:bg-slate-800 text-cyan-400 rounded-lg border border-cyan-500/40 font-bold flex items-center space-x-1 transition-all"
        >
          <SlidersHorizontal className="w-3.5 h-3.5" />
          <span>Customize Layout</span>
        </button>

        <button
          onClick={onResetSimulation}
          className="px-2.5 py-1.5 bg-slate-900 hover:bg-slate-800 text-slate-300 rounded-lg border border-slate-800 font-bold flex items-center space-x-1 transition-all"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>Refresh</span>
        </button>

        <button 
          onClick={onOpenApiSettings}
          className="px-2.5 py-1.5 bg-slate-900 hover:bg-slate-800 text-slate-300 rounded-lg border border-slate-800 font-bold flex items-center space-x-1 transition-all"
        >
          <Settings className="w-3.5 h-3.5 text-cyan-400" />
          <span className="text-cyan-400">Broker API</span>
        </button>

        <button 
          onClick={onOpenMatchCustomizer}
          className="px-2.5 py-1.5 bg-gradient-to-r from-emerald-950/70 to-teal-950/70 hover:from-emerald-900/80 hover:to-teal-900/80 text-emerald-300 rounded-lg border border-emerald-500/50 font-bold flex items-center space-x-1.5 transition-all shadow-sm group cursor-pointer"
          title="AI Pattern Match Criteria (Minimum % & Indicator Weights)"
        >
          <SlidersHorizontal className="w-3.5 h-3.5 text-emerald-400 group-hover:rotate-90 transition-transform duration-200" />
          <span className="text-emerald-300">Match Criteria</span>
        </button>
      </div>
    </header>
  );
};

import React from 'react';
import { TransitionMetrics } from '../types/trading';

interface TransitionDetectorSectionProps {
  metrics: TransitionMetrics | null;
}

export const TransitionDetectorSection: React.FC<TransitionDetectorSectionProps> = ({ metrics }) => {
  if (!metrics) return null;

  return (
    <div className="glass-panel rounded-xl p-4 border border-slate-800 font-mono text-xs h-full flex flex-col justify-between select-none">
      <div className="flex items-center justify-between border-b border-slate-800 pb-1">
        <h4 className="font-extrabold uppercase text-slate-100 text-xs">HISTORICAL TRANSITION DETECTOR</h4>
      </div>

      <div className="space-y-1 my-auto">
        <div className="flex justify-between"><span className="text-slate-400">Previous Historical Pattern:</span><span className="text-emerald-400 font-bold">Bullish Continuation</span></div>
        <div className="flex justify-between"><span className="text-slate-400">Current Historical Pattern:</span><span className="text-emerald-400 font-bold">Bullish Continuation</span></div>
        <div className="flex justify-between"><span className="text-slate-400">Transition Percentage:</span><span className="text-slate-200 font-bold">12%</span></div>
        <div className="flex justify-between"><span className="text-slate-400">Transition Speed:</span><span className="text-emerald-400 font-bold">STABLE</span></div>
        <div className="flex justify-between"><span className="text-slate-400">Transition Direction:</span><span className="text-emerald-400 font-bold">STABLE</span></div>
        <div className="flex justify-between"><span className="text-slate-400">Warning:</span><span className="text-emerald-400 font-bold">NONE</span></div>
      </div>
    </div>
  );
};

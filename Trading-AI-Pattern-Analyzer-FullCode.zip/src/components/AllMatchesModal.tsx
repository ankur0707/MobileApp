import React, { useState, useMemo } from 'react';
import { HistoricalMatchItem } from '../types/trading';
import { X, Trophy, Search, Layers } from 'lucide-react';

interface AllMatchesModalProps {
  isOpen: boolean;
  onClose: () => void;
  matches: HistoricalMatchItem[];
  onSelectMatch: (match: HistoricalMatchItem) => void;
}

export const AllMatchesModal: React.FC<AllMatchesModalProps> = ({
  isOpen,
  onClose,
  matches,
  onSelectMatch
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'match' | 'winrate' | 'move'>('match');

  const filteredMatches = useMemo(() => {
    let result = [...matches];
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      result = result.filter(m => 
        m.asset.toLowerCase().includes(q) || 
        m.patternName.toLowerCase().includes(q) ||
        m.date.toLowerCase().includes(q)
      );
    }

    result.sort((a, b) => {
      if (sortBy === 'match') return b.historicalMatchPct - a.historicalMatchPct;
      if (sortBy === 'winrate') return b.winRatePct - a.winRatePct;
      if (sortBy === 'move') return b.averageMovePct - a.averageMovePct;
      return 0;
    });

    return result;
  }, [matches, searchQuery, sortBy]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 font-mono select-none animate-in fade-in duration-150">
      <div className="bg-[#090D17] border border-cyan-500/40 rounded-2xl w-full max-w-5xl max-h-[90vh] overflow-hidden p-6 shadow-2xl shadow-cyan-950/40 flex flex-col gap-4">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-cyan-950 border border-cyan-500/40 flex items-center justify-center">
              <Trophy className="w-5 h-5 text-cyan-400" />
            </div>
            <div>
              <h3 className="text-base font-extrabold text-slate-100 tracking-wider">
                HISTORICAL PATTERN MATCHES ARCHIVE
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Complete database of vector similarities scanned across multi-year historical archives
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white rounded-lg border border-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Filter and Search Bar */}
        <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-950/80 p-3 rounded-xl border border-slate-800">
          <div className="flex items-center space-x-2 flex-1 min-w-[240px]">
            <Search className="w-4 h-4 text-slate-500" />
            <input
              type="text"
              placeholder="Search by asset, date, or pattern..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="bg-transparent text-slate-200 placeholder-slate-500 text-xs outline-none w-full font-mono"
            />
          </div>

          <div className="flex items-center space-x-2 text-xs">
            <span className="text-slate-400 font-bold">SORT BY:</span>
            <button
              onClick={() => setSortBy('match')}
              className={`px-2.5 py-1 rounded text-xs font-bold border transition-all ${
                sortBy === 'match'
                  ? 'bg-cyan-950 text-cyan-400 border-cyan-500/50'
                  : 'bg-slate-900 text-slate-400 border-slate-800 hover:border-slate-700'
              }`}
            >
              Match %
            </button>
            <button
              onClick={() => setSortBy('winrate')}
              className={`px-2.5 py-1 rounded text-xs font-bold border transition-all ${
                sortBy === 'winrate'
                  ? 'bg-cyan-950 text-cyan-400 border-cyan-500/50'
                  : 'bg-slate-900 text-slate-400 border-slate-800 hover:border-slate-700'
              }`}
            >
              Win Rate %
            </button>
            <button
              onClick={() => setSortBy('move')}
              className={`px-2.5 py-1 rounded text-xs font-bold border transition-all ${
                sortBy === 'move'
                  ? 'bg-cyan-950 text-cyan-400 border-cyan-500/50'
                  : 'bg-slate-900 text-slate-400 border-slate-800 hover:border-slate-700'
              }`}
            >
              Avg Move %
            </button>
          </div>
        </div>

        {/* Matches Grid List */}
        <div className="flex-1 overflow-y-auto pr-1 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5 custom-scrollbar max-h-[58vh]">
          {filteredMatches.length === 0 ? (
            <div className="col-span-full py-12 text-center text-slate-500 text-xs">
              No historical matches found matching &quot;{searchQuery}&quot;
            </div>
          ) : (
            filteredMatches.map((item, idx) => {
              const minP = Math.min(...item.candles.map(c => c.low));
              const maxP = Math.max(...item.candles.map(c => c.high));
              const pRange = Math.max(0.0001, maxP - minP);

              return (
                <div
                  key={item.id}
                  className="bg-slate-950/90 border border-slate-800/90 hover:border-cyan-500/60 rounded-xl p-3.5 transition-all flex flex-col justify-between group shadow-lg hover:shadow-cyan-950/20"
                >
                  <div>
                    {/* Top Match Rank & Score */}
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center space-x-2">
                        <span className="text-[11px] font-extrabold bg-cyan-950 text-cyan-400 border border-cyan-500/40 px-1.5 py-0.2 rounded">
                          #{idx + 1}
                        </span>
                        <span className="text-xs font-bold text-slate-200">{item.asset}</span>
                      </div>
                      <span className="text-sm font-extrabold text-emerald-400">
                        {item.historicalMatchPct}% MATCH
                      </span>
                    </div>

                    {/* Mini SVG Candlestick Preview */}
                    <div className="h-16 w-full bg-[#05070F] rounded border border-slate-900 p-1.5 mb-2.5 flex items-center justify-center">
                      <svg width="100%" height="100%" viewBox="0 0 150 40">
                        {item.candles.map((c, i) => {
                          const w = 150 / item.candles.length;
                          const x = i * w + w / 4;
                          const openY = 36 - ((c.open - minP) / pRange) * 32;
                          const closeY = 36 - ((c.close - minP) / pRange) * 32;
                          const highY = 36 - ((c.high - minP) / pRange) * 32;
                          const lowY = 36 - ((c.low - minP) / pRange) * 32;
                          const isBull = c.isBullish;
                          return (
                            <g key={i}>
                              <line x1={x + w / 4} y1={highY} x2={x + w / 4} y2={lowY} stroke={isBull ? '#10B981' : '#EF4444'} strokeWidth="1" />
                              <rect
                                x={x}
                                y={Math.min(openY, closeY)}
                                width={Math.max(2, w / 2)}
                                height={Math.max(2, Math.abs(closeY - openY))}
                                fill={isBull ? '#10B981' : '#EF4444'}
                                rx="0.5"
                              />
                            </g>
                          );
                        })}
                      </svg>
                    </div>

                    {/* Stats */}
                    <div className="grid grid-cols-3 gap-1.5 text-center text-[11px] mb-3">
                      <div className="bg-slate-900/60 p-1.5 rounded border border-slate-800">
                        <span className="text-slate-500 text-[10px] block">Win Rate</span>
                        <span className="font-bold text-emerald-400">{item.winRatePct}%</span>
                      </div>
                      <div className="bg-slate-900/60 p-1.5 rounded border border-slate-800">
                        <span className="text-slate-500 text-[10px] block">Avg Move</span>
                        <span className="font-bold text-cyan-400">+{item.averageMovePct}%</span>
                      </div>
                      <div className="bg-slate-900/60 p-1.5 rounded border border-slate-800">
                        <span className="text-slate-500 text-[10px] block">Samples</span>
                        <span className="font-bold text-slate-300">{item.sampleSize}</span>
                      </div>
                    </div>

                    <div className="text-[10px] text-slate-500 flex justify-between items-center mb-2 px-1">
                      <span>Date: <strong className="text-slate-400">{item.date}</strong></span>
                      <span>TF: <strong className="text-slate-400">{item.timeframe}</strong></span>
                    </div>
                  </div>

                  {/* Action Button */}
                  <button
                    onClick={() => {
                      onSelectMatch(item);
                      onClose();
                    }}
                    className="w-full py-1.5 bg-cyan-950 hover:bg-cyan-900 text-cyan-300 hover:text-white rounded border border-cyan-500/40 text-xs font-bold transition-all flex items-center justify-center space-x-1.5 cursor-pointer shadow-sm"
                  >
                    <Layers className="w-3.5 h-3.5" />
                    <span>Synchronized Comparison →</span>
                  </button>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};

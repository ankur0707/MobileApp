import React, { useState, useEffect, useRef } from 'react';
import { createChart, IChartApi, ISeriesApi, Logical, Time, ColorType } from 'lightweight-charts';
import { Candle, ReferencePattern } from '../types/trading';
import { Lock, Sparkles } from 'lucide-react';

interface InteractiveChartProps {
  candles: Candle[];
  referencePattern: ReferencePattern | null;
  onLockReference: (selectedCandleSlice: Candle[]) => void;
  onClearReference: () => void;
  hoveredCandle: Candle | null;
  setHoveredCandle: (candle: Candle | null) => void;
  asset: string;
  timeframe: string;
  isMarketOpen?: boolean;
  isSocketConnected?: boolean;
}

export const InteractiveChart: React.FC<InteractiveChartProps> = ({
  candles,
  referencePattern,
  onLockReference,
  onClearReference,
  hoveredCandle,
  setHoveredCandle,
  asset,
  timeframe,
  isMarketOpen = false,
  isSocketConnected = false
}) => {

  const chartContainerRef = useRef<HTMLDivElement>(null);
  const chartRef = useRef<IChartApi | null>(null);
  const seriesRef = useRef<ISeriesApi<"Candlestick"> | null>(null);
  const volumeRef = useRef<ISeriesApi<"Histogram"> | null>(null);
  const prevCandlesLength = useRef<number>(0);
  const lastRenderedAssetRef = useRef<string>('');
  const lastRenderedTfRef = useRef<string>('');
  const lastRenderedTimeRef = useRef<number>(0);
  const hasAutoFitForAssetRef = useRef<string>('');

  // Overlay state for drag selection
  const [isSelecting, setIsSelecting] = useState(false);
  const [startX, setStartX] = useState<number | null>(null);
  const [currentX, setCurrentX] = useState<number | null>(null);
  const [selectionBox, setSelectionBox] = useState<{ x: number; width: number } | null>(null);
  const [lockedBox, setLockedBox] = useState<{ x: number, width: number } | null>(null);
  
  const [isShiftDown, setIsShiftDown] = useState(false);

  // Keyboard listener for Shift Key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Shift') setIsShiftDown(true);
    };
    const handleKeyUp = (e: KeyboardEvent) => {
      if (e.key === 'Shift') {
        setIsShiftDown(false);
        setIsSelecting(false); // Cancel selection if shift is released
        setSelectionBox(null);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, []);

  // Initialize TradingView Lightweight Chart
  useEffect(() => {
    if (!chartContainerRef.current) return;

    // Create chart
    const chart = createChart(chartContainerRef.current, {
      layout: {
        background: { type: ColorType.Solid, color: 'transparent' },
        textColor: '#64748B',
        fontFamily: 'Inter, sans-serif',
      },
      grid: {
        vertLines: { color: 'rgba(30, 41, 59, 0.5)', style: 1 },
        horzLines: { color: 'rgba(30, 41, 59, 0.5)', style: 1 },
      },
      crosshair: {
        mode: 0, // Normal mode
        vertLine: { color: '#475569', width: 1, style: 1, labelBackgroundColor: '#0F172A' },
        horzLine: { color: '#475569', width: 1, style: 1, labelBackgroundColor: '#0F172A' },
      },
      rightPriceScale: {
        borderColor: 'rgba(30, 41, 59, 0.8)',
      },
      timeScale: {
        borderColor: 'rgba(30, 41, 59, 0.8)',
        timeVisible: true,
        secondsVisible: false,
        shiftVisibleRangeOnNewBar: true,
        rightOffset: 12,
      },
      handleScroll: {
        mouseWheel: true,
        pressedMouseMove: true,
        horzTouchDrag: true,
        vertTouchDrag: true,
      },
      handleScale: {
        axisPressedMouseMove: true,
        mouseWheel: true,
        pinch: true,
      },
      autoSize: true,
    });

    chartRef.current = chart;

    // Add Candlestick Series
    const candleSeries = chart.addCandlestickSeries({
      upColor: '#10B981',
      downColor: '#EF4444',
      borderVisible: false,
      wickUpColor: '#10B981',
      wickDownColor: '#EF4444',
    });
    seriesRef.current = candleSeries;

    // Add Volume Series
    const volumeSeries = chart.addHistogramSeries({
      color: '#26a69a',
      priceFormat: { type: 'volume' },
      priceScaleId: '', // set as an overlay by setting a blank priceScaleId
    });
    
    // Position volume at the bottom
    chart.priceScale('').applyOptions({
      scaleMargins: {
        top: 0.8, // highest point of the series will be at 80% of the chart height
        bottom: 0,
      },
    });
    volumeRef.current = volumeSeries;

    // Crosshair subscription for hover tooltip
    chart.subscribeCrosshairMove((param) => {
      if (param.point === undefined || !param.time || param.point.x < 0 || param.point.x > chartContainerRef.current!.clientWidth || param.point.y < 0 || param.point.y > chartContainerRef.current!.clientHeight) {
        setHoveredCandle(null);
      } else {
        const unixTime = param.time as number;
        // Find matching candle in our array based on unix timestamp
        const match = candles.find(c => Math.floor(new Date(c.time).getTime() / 1000) === unixTime);
        if (match) setHoveredCandle(match);
      }
    });

    const resizeObserver = new ResizeObserver(entries => {
      for (const entry of entries) {
        const { width, height } = entry.contentRect;
        if (width > 50 && height > 50 && chartRef.current) {
          chartRef.current.applyOptions({ width, height });
        }
      }
    });

    if (chartContainerRef.current) {
      resizeObserver.observe(chartContainerRef.current);
    }

    return () => {
      resizeObserver.disconnect();
      chart.remove();
    };
  }, []);

  // Sync data to chart when candles update
  useEffect(() => {
    if (!seriesRef.current || !volumeRef.current || !chartRef.current || !candles || candles.length === 0) {
      return;
    }

    // 1. Sanitize, deduplicate, and ascending-sort candles by timestamp (Strict Lightweight Charts requirement)
    const seenTimes = new Set<number>();
    const sanitizedCandles: Array<{ time: Time; open: number; high: number; low: number; close: number }> = [];
    const sanitizedVolumes: Array<{ time: Time; value: number; color: string }> = [];

    const sortedCandles = [...candles].sort((a, b) => new Date(a.time).getTime() - new Date(b.time).getTime());

    for (const c of sortedCandles) {
      if (typeof c.open !== 'number' || typeof c.close !== 'number' || isNaN(c.open) || isNaN(c.close)) continue;
      const t = Math.floor(new Date(c.time).getTime() / 1000) as Time;
      const numT = t as number;
      if (typeof numT === 'number' && !isNaN(numT) && numT > 0 && !seenTimes.has(numT)) {
        seenTimes.add(numT);
        sanitizedCandles.push({
          time: t,
          open: Number(c.open.toFixed(2)),
          high: Number(c.high.toFixed(2)),
          low: Number(c.low.toFixed(2)),
          close: Number(c.close.toFixed(2)),
        });
        sanitizedVolumes.push({
          time: t,
          value: c.volume || 100,
          color: c.isBullish ? 'rgba(16, 185, 129, 0.3)' : 'rgba(239, 68, 68, 0.3)'
        });
      }
    }

    if (sanitizedCandles.length === 0) return;

    const isDifferentAsset = lastRenderedAssetRef.current !== asset || lastRenderedTfRef.current !== timeframe;
    const isSingleTick = !isDifferentAsset && 
      lastRenderedTimeRef.current > 0 && 
      (candles.length === prevCandlesLength.current || candles.length === prevCandlesLength.current + 1);

    if (isSingleTick) {
      // Incremental tick update
      const lastCandle = sanitizedCandles[sanitizedCandles.length - 1];
      const lastVol = sanitizedVolumes[sanitizedVolumes.length - 1];
      const lastTimeNum = lastCandle.time as number;

      try {
        if (lastTimeNum >= lastRenderedTimeRef.current) {
          seriesRef.current.update(lastCandle);
          volumeRef.current.update(lastVol);
          lastRenderedTimeRef.current = lastTimeNum;
          prevCandlesLength.current = candles.length;
          return;
        }
      } catch (err) {
        console.warn('[InteractiveChart] update() failed, recovering via setData():', err);
      }
    }

    // Full Reset / Switch Asset / Initial Load:
    try {
      seriesRef.current.setData(sanitizedCandles);
      volumeRef.current.setData(sanitizedVolumes);
      
      const lastBar = sanitizedCandles[sanitizedCandles.length - 1];
      lastRenderedTimeRef.current = (lastBar?.time as number) || 0;
      lastRenderedAssetRef.current = asset;
      lastRenderedTfRef.current = timeframe;
      prevCandlesLength.current = candles.length;

      // Toggle clean date display for Daily / Weekly 5-year data
      const isDailyOrWeekly = timeframe === '1D' || timeframe === '1W' || timeframe === '1d' || timeframe === '1w';
      chartRef.current?.timeScale().applyOptions({
        timeVisible: !isDailyOrWeekly,
      });

      // Auto-fit full historical chart across screen (only once per asset/timeframe load)
      if (hasAutoFitForAssetRef.current !== (asset + '_' + timeframe)) {
        hasAutoFitForAssetRef.current = (asset + '_' + timeframe);
        requestAnimationFrame(() => {
          setTimeout(() => {
            try {
              chartRef.current?.timeScale().fitContent();
            } catch (e) {
              // ignore fitContent errors
            }
          }, 40);
        });
      }
    } catch (err) {
      console.error('[InteractiveChart] setData() failed:', err);
    }
  }, [candles, asset, timeframe]);

  // Update Locked Box position based on chart pan/zoom
  useEffect(() => {
    if (!chartRef.current || !referencePattern) {
      setLockedBox(null);
      return;
    }

    const updateBoxPosition = () => {
      if (!referencePattern || !referencePattern.candles || referencePattern.candles.length === 0) {
        setLockedBox(null);
        return;
      }

      // If reference pattern belongs to a different asset, don't draw box
      if (referencePattern.asset && referencePattern.asset !== asset) {
        setLockedBox(null);
        return;
      }

      try {
        const timeScale = chartRef.current?.timeScale();
        if (!timeScale) return;
        
        const firstCandle = referencePattern.candles[0];
        const lastCandle = referencePattern.candles[referencePattern.candles.length - 1];
        if (!firstCandle || !lastCandle) return;

        const startUnix = Math.floor(new Date(firstCandle.time).getTime() / 1000) as Time;
        const endUnix = Math.floor(new Date(lastCandle.time).getTime() / 1000) as Time;
        
        const startX = timeScale.timeToCoordinate(startUnix);
        const endX = timeScale.timeToCoordinate(endUnix);
        
        if (startX !== null && endX !== null && !isNaN(startX) && !isNaN(endX)) {
          setLockedBox({
            x: Math.min(startX, endX) - 5,
            width: Math.abs(endX - startX) + 10
          });
        } else {
          setLockedBox(null);
        }
      } catch (e) {
        setLockedBox(null);
      }
    };

    updateBoxPosition();
    chartRef.current.timeScale().subscribeVisibleTimeRangeChange(updateBoxPosition);
    chartRef.current.timeScale().subscribeSizeChange(updateBoxPosition);

    return () => {
      if (chartRef.current) {
        try {
          chartRef.current.timeScale().unsubscribeVisibleTimeRangeChange(updateBoxPosition);
          chartRef.current.timeScale().unsubscribeSizeChange(updateBoxPosition);
        } catch (e) {
          // cleanup safe
        }
      }
    };
  }, [referencePattern, candles, asset]);

  // Handle Custom Overlay Drag Selection
  const handleMouseDown = (e: React.MouseEvent<HTMLDivElement>) => {
    if (e.button !== 0) return; // Only left click
    // Only allow drawing if holding SHIFT or if we add a "draw mode" toggle.
    // For simplicity, let's allow drag selection directly on the overlay if clicked near the top, 
    // but the chart handles pan/zoom below it. We'll use pointer events.
    const rect = chartContainerRef.current?.getBoundingClientRect();
    if (rect) {
      const x = e.clientX - rect.left;
      setIsSelecting(true);
      setStartX(x);
      setCurrentX(x);
      setSelectionBox({ x, width: 0 });
    }
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!isSelecting || startX === null) return;
    const rect = chartContainerRef.current?.getBoundingClientRect();
    if (rect) {
      const x = e.clientX - rect.left;
      setCurrentX(x);
      setSelectionBox({
        x: Math.min(startX, x),
        width: Math.abs(x - startX)
      });
    }
  };

  const handleMouseUp = () => {
    if (isSelecting && startX !== null && currentX !== null && chartRef.current) {
      setIsSelecting(false);
      
      // Convert pixel X coordinates back to logical candle indices
      const timeScale = chartRef.current.timeScale();
      const logicalStart = timeScale.coordinateToLogical(startX);
      const logicalEnd = timeScale.coordinateToLogical(currentX);

      if (logicalStart !== null && logicalEnd !== null) {
        const startIdx = Math.max(0, Math.round(Math.min(logicalStart, logicalEnd)));
        const endIdx = Math.min(candles.length - 1, Math.round(Math.max(logicalStart, logicalEnd)));
        
        if (endIdx - startIdx >= 1) { // Minimum 2 candles
          const selectedSlice = candles.slice(startIdx, endIdx + 1);
          onLockReference(selectedSlice);
        }
      }
      setSelectionBox(null);
    }
  };

  const isRefLocked = referencePattern && referencePattern.locked;

  const handleSnapToLive = () => {
    if (chartRef.current) {
      chartRef.current.timeScale().scrollToRealTime();
    }
  };

  return (
    <div className="glass-panel rounded-xl border border-slate-800 p-4 h-full flex flex-col justify-between select-none relative overflow-hidden font-mono text-sm shadow-2xl">
      {/* Chart Header Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-800/80 flex-shrink-0 z-10 relative">
        <div className="flex items-center space-x-3">
          <div className="flex items-center space-x-2">
            <span className="font-extrabold text-slate-100 text-sm tracking-wider">{asset} • {timeframe} • NSE</span>
            {isSocketConnected && isMarketOpen ? (
              <span className="text-[10px] text-emerald-400 font-bold bg-emerald-950 px-2 py-0.5 rounded border border-emerald-500/40 animate-pulse tracking-widest">
                LIVE MARKET
              </span>
            ) : !isSocketConnected ? (
              <span
                className="text-[10px] text-rose-400 font-bold bg-rose-950/80 px-2 py-0.5 rounded border border-rose-500/50 tracking-widest flex items-center gap-1.5"
                title="API Disconnected — live data not available"
              >
                <span className="w-1.5 h-1.5 rounded-full bg-rose-400"></span>
                NO LIVE DATA
              </span>
            ) : (
              <span
                className="text-[10px] text-amber-400 font-bold bg-amber-950/80 px-2 py-0.5 rounded border border-amber-500/50 tracking-widest flex items-center gap-1.5 shadow-sm"
                title="Trading session ended at 3:30 PM IST. Showing official NSE closing price."
              >
                <span className="w-1.5 h-1.5 rounded-full bg-amber-400"></span>
                MARKET CLOSED • OFFICIAL CLOSE
              </span>
            )}

            <button 
              onClick={handleSnapToLive}
              className="ml-2 text-[10px] bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold px-2 py-0.5 rounded border border-slate-600 transition-colors"
              title="Snap to most recent live candle"
            >
              → GO TO LIVE
            </button>
            <button 
              onClick={() => chartRef.current?.timeScale().fitContent()}
              className="text-[10px] bg-cyan-950/80 hover:bg-cyan-900 text-cyan-300 font-bold px-2 py-0.5 rounded border border-cyan-500/50 transition-colors"
              title="Fit entire historical chart across screen"
            >
              🔍 FIT ALL
            </button>
          </div>

          {candles && candles.length > 0 && (
            <div className="hidden lg:flex items-center space-x-3 text-xs text-slate-400 bg-slate-900/50 px-3 py-1 rounded border border-slate-800/50">
              <span>O: <strong className="text-slate-200">{candles[candles.length - 1]?.open != null ? candles[candles.length - 1].open.toFixed(2) : '--'}</strong></span>
              <span>H: <strong className="text-slate-200">{candles[candles.length - 1]?.high != null ? candles[candles.length - 1].high.toFixed(2) : '--'}</strong></span>
              <span>L: <strong className="text-slate-200">{candles[candles.length - 1]?.low != null ? candles[candles.length - 1].low.toFixed(2) : '--'}</strong></span>
              <span>C: <strong className="text-emerald-400 font-bold">{candles[candles.length - 1]?.close != null ? candles[candles.length - 1].close.toFixed(2) : '--'}</strong></span>
            </div>
          )}
        </div>

        {/* Lock Pattern State Indicator */}
        <div className="flex items-center space-x-2">
          {isRefLocked ? (
            <>
              <div className="flex items-center space-x-2 bg-cyan-950/80 border border-cyan-500/60 text-cyan-300 text-[11px] px-3 py-1 rounded-md font-bold shadow-lg shadow-cyan-900/40">
                <Lock className="w-3.5 h-3.5 text-cyan-400" />
                <span>REFERENCE LOCKED 🔒 ({referencePattern.selectedCandleCount} CANDLES)</span>
              </div>
              <button 
                onClick={onClearReference}
                className="text-[10px] bg-rose-950/80 hover:bg-rose-900 text-rose-300 font-bold px-3 py-1 rounded-md border border-rose-500/60 transition-colors shadow-lg shadow-rose-900/40 flex items-center gap-1"
                title="Clear selected pattern"
              >
                ✖ CLEAR
              </button>
            </>
          ) : (
            <div className="flex items-center space-x-2 bg-amber-950/60 border border-amber-500/50 text-amber-300 text-[11px] px-3 py-1 rounded-md font-bold animate-pulse shadow-lg shadow-amber-900/20">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>SHIFT + DRAG TO LOCK PATTERN</span>
            </div>
          )}
        </div>
      </div>

      {/* Main Lightweight Charts Container */}
      <div className="relative bg-[#070A10] rounded-lg border border-slate-900 overflow-hidden flex-1 min-h-0 mt-3 shadow-inner">
        {/* The actual TradingView Chart Div */}
        <div ref={chartContainerRef} className="absolute inset-0 z-0" />
        
        {/* Invisible Selection Overlay for Custom Dragging (Activates on Shift key) */}
        <div 
          className={`absolute inset-0 z-10 ${isShiftDown ? 'cursor-crosshair pointer-events-auto' : 'pointer-events-none'}`}
          onMouseDown={handleMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
          onMouseLeave={() => setIsSelecting(false)}
          title="Hold SHIFT and drag horizontally to select pattern"
        >
          {/* Active Dragging Highlight Box */}
          {selectionBox && (
            <div 
              className="absolute top-0 bottom-0 bg-cyan-500/20 border-x-2 border-cyan-500 shadow-[0_0_15px_rgba(6,182,212,0.3)] pointer-events-none transition-all duration-75"
              style={{ left: selectionBox.x, width: selectionBox.width }}
            />
          )}

          {/* Locked Reference Pattern Bounding Box */}
          {lockedBox && !isSelecting && (
            <div 
              className="absolute top-[10%] bottom-[20%] border-2 border-dashed border-cyan-500 bg-cyan-500/5 pointer-events-none rounded transition-all duration-75 flex items-end justify-center pb-2 shadow-[0_0_15px_rgba(6,182,212,0.15)]"
              style={{ left: lockedBox.x, width: lockedBox.width }}
            >
              <div className="bg-[#0B0F19]/90 border border-cyan-500/50 px-2 py-1 rounded backdrop-blur-md whitespace-nowrap -mb-10">
                <span className="text-cyan-400 text-[10px] font-bold">🔒 REFERENCE PATTERN</span>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

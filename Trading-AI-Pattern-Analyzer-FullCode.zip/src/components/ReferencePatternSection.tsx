import React from 'react';
import { ReferencePattern } from '../types/trading';
import { Lock, Trophy, ArrowUpRight, ArrowDownRight, Layers, Maximize2 } from 'lucide-react';

interface ReferencePatternSectionProps {
  refPattern?: ReferencePattern | null;
  pattern?: ReferencePattern | null;
  onOpenChart?: () => void;
  onOpenReferenceChart?: () => void;
  onClearReference?: () => void;
}

export const ReferencePatternSection: React.FC<ReferencePatternSectionProps> = ({
  refPattern,
  pattern,
  onOpenChart,
  onOpenReferenceChart,
  onClearReference
}) => {
  const activePattern = pattern || refPattern;
  const handleOpenChart = onOpenReferenceChart || onOpenChart;

  if (!activePattern) return null;

  const minP = Math.min(...activePattern.candles.map(c => c.low));
  const maxP = Math.max(...activePattern.candles.map(c => c.high));
  const pRange = Math.max(0.0001, maxP - minP);

  const circumference = 2 * Math.PI * 34;
  const strokeDashoffset = circumference - (activePattern.confidenceScore / 100) * circumference;

  return (
    <div className="glass-panel-glow-cyan rounded-xl p-4 border border-cyan-500/40 font-mono text-xs select-none">
      {/* Card Header */}
      <div className="flex items-center justify-between pb-2.5 mb-3 border-b border-cyan-500/20">
        <div className="flex items-center space-x-2">
          <Lock className="w-4 h-4 text-cyan-400" />
          <h3 className="text-xs font-extrabold uppercase tracking-widest text-slate-100">
            REFERENCE PATTERN (LOCKED)
          </h3>
        </div>
        {onClearReference && (
          <button
            onClick={onClearReference}
            className="text-[10px] text-rose-400 hover:text-rose-300 hover:bg-rose-500/10 px-2 py-0.5 rounded border border-rose-500/30 transition-all font-semibold uppercase tracking-wider cursor-pointer"
            title="Unlock reference pattern"
          >
            Clear / Unlock
          </button>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-center">
        {/* Pattern Thumbnail & Asset Metadata */}
        <div className="lg:col-span-3 flex items-center space-x-3 bg-slate-950/80 p-4 rounded-lg border border-slate-800">
          {/* Clickable Mini SVG Candle Vector Thumbnail */}
          <div
            onClick={handleOpenChart}
            className="relative w-20 h-16 bg-[#060911] rounded border border-slate-800 hover:border-cyan-400 p-1 flex items-center justify-center flex-shrink-0 cursor-pointer group transition-all shadow-md hover:shadow-cyan-500/20"
            title="Click to open full reference pattern chart"
          >
            <svg width="100%" height="100%" viewBox="0 0 100 50">
              {activePattern.candles.map((c, i) => {
                const w = 100 / activePattern.candles.length;
                const x = i * w + w / 4;
                const openY = 45 - ((c.open - minP) / pRange) * 40;
                const closeY = 45 - ((c.close - minP) / pRange) * 40;
                const highY = 45 - ((c.high - minP) / pRange) * 40;
                const lowY = 45 - ((c.low - minP) / pRange) * 40;
                const isBull = c.isBullish;
                return (
                  <g key={i}>
                    <line x1={x + w / 4} y1={highY} x2={x + w / 4} y2={lowY} stroke={isBull ? '#10B981' : '#EF4444'} strokeWidth="1" />
                    <rect
                      x={x}
                      y={Math.min(openY, closeY)}
                      width={w / 2}
                      height={Math.max(2, Math.abs(closeY - openY))}
                      fill={isBull ? '#10B981' : '#EF4444'}
                      rx="1"
                    />
                  </g>
                );
              })}
            </svg>
            <div className="absolute inset-0 bg-cyan-950/70 opacity-0 group-hover:opacity-100 flex items-center justify-center rounded transition-opacity">
              <Maximize2 className="w-4 h-4 text-cyan-300" />
            </div>
          </div>

          <div>
            <span className="text-xs text-cyan-400 font-extrabold uppercase tracking-wider block">LOCKED VECTOR</span>
            <span className="text-sm font-bold text-slate-200 block truncate">{activePattern.asset} ({activePattern.timeframe})</span>
            <div className="text-xs text-slate-400 mt-1 flex items-center space-x-2">
              <span>Candles: <strong className="text-slate-200">{activePattern.selectedCandleCount}</strong></span>
              <span>•</span>
              <button
                onClick={handleOpenChart}
                className="text-cyan-400 hover:text-cyan-300 hover:underline font-bold text-[11px] flex items-center gap-1 cursor-pointer"
              >
                Inspect Chart ↗
              </button>
            </div>
          </div>
        </div>

        {/* 6 Key Stats Grid */}
        <div className="lg:col-span-7 grid grid-cols-2 sm:grid-cols-6 gap-4 text-center font-mono">
          <div className="bg-slate-950/80 p-4 rounded-lg border border-slate-800">
            <span className="text-xs text-slate-400 block font-bold">Historical Match</span>
            <span className="text-lg font-extrabold text-emerald-400">{activePattern.historicalMatchPct}%</span>
          </div>

          <div className="bg-slate-950/80 p-4 rounded-lg border border-slate-800">
            <span className="text-xs text-slate-400 block font-bold">Win Rate</span>
            <span className="text-lg font-extrabold text-emerald-400">{activePattern.historicalWinRate}%</span>
          </div>

          <div className="bg-slate-950/80 p-4 rounded-lg border border-slate-800">
            <span className="text-xs text-slate-400 block font-bold">Loss Rate</span>
            <span className="text-lg font-extrabold text-rose-400">{activePattern.historicalLossRate}%</span>
          </div>

          <div className="bg-slate-950/80 p-4 rounded-lg border border-slate-800">
            <span className="text-xs text-slate-400 block font-bold">Average Profit</span>
            <span className="text-lg font-extrabold text-emerald-400">+{activePattern.averageProfitPct}%</span>
          </div>

          <div className="bg-slate-950/80 p-4 rounded-lg border border-slate-800">
            <span className="text-xs text-slate-400 block font-bold">Average Drawdown</span>
            <span className="text-lg font-extrabold text-rose-400">{activePattern.averageDrawdownPct}%</span>
          </div>

          <div className="bg-slate-950/80 p-4 rounded-lg border border-slate-800">
            <span className="text-xs text-slate-400 block font-bold">Sample Size</span>
            <span className="text-lg font-extrabold text-slate-100">{activePattern.sampleSize}</span>
          </div>
        </div>

        {/* Right Confidence Score Radial Gauge */}
        <div className="lg:col-span-2 flex flex-col items-center justify-center text-center bg-slate-950/80 p-4 rounded-lg border border-slate-800">
          <span className="text-xs text-slate-400 uppercase font-bold block mb-0.5">Confidence Score</span>
          <div className="relative w-16 h-16 flex items-center justify-center">
            <svg className="w-full h-full transform -rotate-90">
              <circle cx="32" cy="32" r="24" stroke="#1E293B" strokeWidth="5" fill="transparent" />
              <circle
                cx="32"
                cy="32"
                r="24"
                stroke="#10B981"
                strokeWidth="5"
                fill="transparent"
                strokeDasharray={circumference}
                strokeDashoffset={strokeDashoffset}
                strokeLinecap="round"
              />
            </svg>
            <span className="absolute text-sm font-extrabold text-white">{activePattern.confidenceScore}%</span>
          </div>
          <span className="text-xs font-bold text-emerald-400 tracking-wider uppercase mt-0.5">LOCKED REFERENCE</span>
        </div>
      </div>
    </div>
  );
};

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Search, X, BarChart2, Check, Loader2 } from 'lucide-react';

interface StockItem {
  symbol: string;
  name: string;
  exchange: string;
  category: string;
}

interface SymbolSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentSymbol: string;
  onSelectSymbol: (symbol: string) => void;
}

const POPULAR_CATALOG: StockItem[] = [
  { symbol: 'NIFTY 50', name: 'Nifty 50 Benchmark Index', exchange: 'NSE', category: 'Indices' },
  { symbol: 'BANKNIFTY', name: 'Nifty Bank Index', exchange: 'NSE', category: 'Indices' },
  { symbol: 'FINNIFTY', name: 'Nifty Financial Services', exchange: 'NSE', category: 'Indices' },
  { symbol: 'MIDCPNIFTY', name: 'Nifty Midcap Select', exchange: 'NSE', category: 'Indices' },
  { symbol: 'SENSEX', name: 'BSE Sensex Index', exchange: 'BSE', category: 'Indices' },
  { symbol: 'RELIANCE', name: 'Reliance Industries Ltd', exchange: 'NSE', category: 'Large Cap' },
  { symbol: 'TCS', name: 'Tata Consultancy Services', exchange: 'NSE', category: 'Large Cap' },
  { symbol: 'HDFCBANK', name: 'HDFC Bank Ltd', exchange: 'NSE', category: 'Large Cap' },
  { symbol: 'ICICIBANK', name: 'ICICI Bank Ltd', exchange: 'NSE', category: 'Large Cap' },
  { symbol: 'INFY', name: 'Infosys Ltd', exchange: 'NSE', category: 'Large Cap' },
  { symbol: 'SBIN', name: 'State Bank of India', exchange: 'NSE', category: 'Large Cap' },
  { symbol: 'BHARTIARTL', name: 'Bharti Airtel Ltd', exchange: 'NSE', category: 'Large Cap' },
  { symbol: 'ITC', name: 'ITC Ltd', exchange: 'NSE', category: 'Large Cap' },
  { symbol: 'BAJFINANCE', name: 'Bajaj Finance Ltd', exchange: 'NSE', category: 'Large Cap' },
  { symbol: 'MARUTI', name: 'Maruti Suzuki India Ltd', exchange: 'NSE', category: 'Large Cap' },
  { symbol: 'ZOMATO', name: 'Zomato Ltd', exchange: 'NSE', category: 'Large Cap' },
  { symbol: 'TATAMOTORS', name: 'Tata Motors Ltd', exchange: 'NSE', category: 'Large Cap' },
  { symbol: 'AXISBANK', name: 'Axis Bank Ltd', exchange: 'NSE', category: 'Large Cap' },
  { symbol: 'TATASTEEL', name: 'Tata Steel Ltd', exchange: 'NSE', category: 'F&O' },
  { symbol: 'WIPRO', name: 'Wipro Ltd', exchange: 'NSE', category: 'F&O' },
  { symbol: 'DRREDDY', name: 'Dr Reddys Laboratories', exchange: 'NSE', category: 'F&O' },
  { symbol: 'SUNPHARMA', name: 'Sun Pharma Ltd', exchange: 'NSE', category: 'F&O' },
  { symbol: 'ADANIENT', name: 'Adani Enterprises Ltd', exchange: 'NSE', category: 'Large Cap' },
  { symbol: 'ONGC', name: 'Oil & Natural Gas Corp', exchange: 'NSE', category: 'Large Cap' },
  { symbol: 'BEL', name: 'Bharat Electronics Ltd', exchange: 'NSE', category: 'F&O' },
  { symbol: 'HAL', name: 'Hindustan Aeronautics Ltd', exchange: 'NSE', category: 'F&O' },
  { symbol: 'IRFC', name: 'Indian Railway Finance Corp', exchange: 'NSE', category: 'Large Cap' },
  { symbol: 'PFC', name: 'Power Finance Corp', exchange: 'NSE', category: 'F&O' },
  { symbol: 'RECLTD', name: 'REC Ltd', exchange: 'NSE', category: 'F&O' },
  { symbol: 'BTC/USDT', name: 'Bitcoin / Tether USDT', exchange: 'CRYPTO', category: 'Crypto' },
  { symbol: 'ETH/USDT', name: 'Ethereum / Tether USDT', exchange: 'CRYPTO', category: 'Crypto' },
];

export const SymbolSearchModal: React.FC<SymbolSearchModalProps> = ({
  isOpen,
  onClose,
  currentSymbol,
  onSelectSymbol
}) => {
  const [query, setQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<'All' | 'Indices' | 'Large Cap' | 'F&O' | 'Crypto' | 'NSE Equity'>('All');
  const [selectedIndex, setSelectedIndex] = useState(0);
  const [liveResults, setLiveResults] = useState<StockItem[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Debounced live search using Kotak Neo scrip master
  const fetchLiveSearch = useCallback(async (q: string) => {
    if (q.length < 2) { setLiveResults([]); setIsSearching(false); return; }
    setIsSearching(true);
    try {
      const resp = await fetch(`http://localhost:4000/api/kotak/search?q=${encodeURIComponent(q)}`);
      const data = await resp.json();
      setLiveResults(Array.isArray(data) ? data : []);
    } catch {
      setLiveResults([]);
    } finally {
      setIsSearching(false);
    }
  }, []);

  useEffect(() => {
    if (isOpen) {
      setQuery('');
      setSelectedIndex(0);
      setLiveResults([]);
      setTimeout(() => inputRef.current?.focus(), 50);
    }
  }, [isOpen]);

  useEffect(() => {
    if (debounceRef.current) clearTimeout(debounceRef.current);
    if (query.trim().length >= 2) {
      debounceRef.current = setTimeout(() => fetchLiveSearch(query.trim()), 350);
    } else {
      setLiveResults([]);
      setIsSearching(false);
    }
  }, [query, fetchLiveSearch]);

  if (!isOpen) return null;

  const categories: Array<'All' | 'Indices' | 'Large Cap' | 'F&O' | 'Crypto'> = ['All', 'Indices', 'Large Cap', 'F&O', 'Crypto'];

  // Use live results when query >= 2 chars, else use catalog
  const baseList: StockItem[] = query.trim().length >= 2 ? liveResults : POPULAR_CATALOG;

  const filtered = baseList.filter(item => {
    if (query.trim().length >= 2) return true; // live results already filtered
    const matchCat = selectedCategory === 'All' || item.category === selectedCategory;
    const q = query.trim().toUpperCase();
    const matchQuery = !q || item.symbol.toUpperCase().includes(q) || item.name.toUpperCase().includes(q);
    return matchCat && matchQuery;
  });

  // Check if query is a custom ticker not in results
  const isCustomQuery = query.trim().length > 0 && !filtered.some(f => f.symbol.toUpperCase() === query.trim().toUpperCase()) && !isSearching;


  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setSelectedIndex(prev => (prev < filtered.length - 1 ? prev + 1 : prev));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setSelectedIndex(prev => (prev > 0 ? prev - 1 : 0));
    } else if (e.key === 'Enter') {
      e.preventDefault();
      if (filtered[selectedIndex]) {
        onSelectSymbol(filtered[selectedIndex].symbol);
        onClose();
      } else if (isCustomQuery) {
        onSelectSymbol(query.trim().toUpperCase());
        onClose();
      }
    } else if (e.key === 'Escape') {
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 font-mono select-none animate-in fade-in duration-150">
      <div className="glass-panel-glow-cyan w-full max-w-2xl rounded-xl border border-cyan-500/40 shadow-2xl flex flex-col overflow-hidden bg-[#0A0E17] max-h-[85vh]">
        
        {/* Header Search Box */}
        <div className="p-4 border-b border-slate-800 flex items-center gap-3 bg-slate-900/60">
          {isSearching
            ? <Loader2 className="w-5 h-5 text-cyan-400 flex-shrink-0 animate-spin" />
            : <Search className="w-5 h-5 text-cyan-400 flex-shrink-0" />
          }
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => {
              setQuery(e.target.value);
              setSelectedIndex(0);
            }}
            onKeyDown={handleKeyDown}
            placeholder="Type any NSE/BSE stock name or symbol (e.g. SUZLON, PAYTM, IRCTC, MRF, TATA)..."
            className="w-full bg-transparent border-none text-slate-100 placeholder-slate-500 text-sm font-bold focus:outline-none"
          />
          {query && (
            <button onClick={() => setQuery('')} className="text-slate-500 hover:text-slate-300 p-1">
              <X className="w-4 h-4" />
            </button>
          )}
          <button onClick={onClose} className="text-slate-400 hover:text-rose-400 p-1 rounded hover:bg-slate-800 transition-colors ml-2">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Category Tabs */}
        <div className="flex items-center gap-2 px-4 py-2.5 border-b border-slate-800/80 bg-slate-950/40 overflow-x-auto text-xs">
          {query.trim().length >= 2 ? (
            <span className="flex items-center gap-1.5 px-3 py-1 rounded-md font-bold bg-cyan-950 border border-cyan-500/60 text-cyan-300">
              {isSearching
                ? <><Loader2 className="w-3 h-3 animate-spin" /> Searching Kotak Neo...</>
                : <><Search className="w-3 h-3" /> Live NSE Results ({filtered.length})</>
              }
            </span>
          ) : (
            categories.map(cat => (
              <button
                key={cat}
                onClick={() => {
                  setSelectedCategory(cat);
                  setSelectedIndex(0);
                }}
                className={`px-3 py-1 rounded-md font-bold transition-all ${
                  selectedCategory === cat
                    ? 'bg-cyan-950 border border-cyan-500/60 text-cyan-300 shadow-sm shadow-cyan-900/40'
                    : 'bg-slate-900/50 border border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                {cat}
              </button>
            ))
          )}
          <span className="ml-auto text-[11px] text-cyan-500/70 hidden sm:inline font-bold">
            🔍 Full NSE Exchange Search
          </span>
        </div>

        {/* Results List */}
        <div className="overflow-y-auto flex-1 p-2 space-y-1 divide-y divide-slate-800/30">
          {/* Custom Search Option if not in catalog */}
          {isCustomQuery && (
            <div
              onClick={() => {
                onSelectSymbol(query.trim().toUpperCase());
                onClose();
              }}
              className="p-3 rounded-lg border border-cyan-500/40 bg-cyan-950/30 hover:bg-cyan-900/40 cursor-pointer flex items-center justify-between transition-colors mb-2"
            >
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-cyan-500/20 flex items-center justify-center text-cyan-400 font-bold text-xs">
                  NSE
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-extrabold text-cyan-300 text-sm">{query.trim().toUpperCase()}</span>
                    <span className="text-[10px] bg-cyan-950 text-cyan-400 px-1.5 py-0.5 rounded border border-cyan-500/30">CUSTOM SEARCH</span>
                  </div>
                  <p className="text-xs text-slate-400">Load historical & live data for this equity</p>
                </div>
              </div>
              <span className="text-xs font-bold text-cyan-400 bg-cyan-950/80 px-2.5 py-1 rounded border border-cyan-500/40">Press Enter ↵</span>
            </div>
          )}

          {filtered.length > 0 ? (
            filtered.map((item, idx) => {
              const isSelected = item.symbol === currentSymbol;
              const isHighlighted = idx === selectedIndex;

              return (
                <div
                  key={item.symbol}
                  onClick={() => {
                    onSelectSymbol(item.symbol);
                    onClose();
                  }}
                  onMouseEnter={() => setSelectedIndex(idx)}
                  className={`p-2.5 rounded-lg flex items-center justify-between cursor-pointer transition-all ${
                    isHighlighted
                      ? 'bg-slate-800/70 border border-slate-700'
                      : 'hover:bg-slate-900/50 border border-transparent'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center font-bold text-[11px] ${
                      item.exchange === 'NSE' ? 'bg-emerald-950/80 border border-emerald-500/40 text-emerald-400' :
                      item.exchange === 'BSE' ? 'bg-amber-950/80 border border-amber-500/40 text-amber-400' :
                      'bg-cyan-950/80 border border-cyan-500/40 text-cyan-400'
                    }`}>
                      {item.exchange}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-extrabold text-slate-100 text-sm tracking-wide">{item.symbol}</span>
                        {isSelected && (
                          <span className="text-[9px] bg-emerald-950 text-emerald-400 px-1.5 py-0.5 rounded border border-emerald-500/40 font-bold flex items-center gap-0.5">
                            <Check className="w-2.5 h-2.5" /> ACTIVE
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-slate-400 truncate max-w-[320px]">{item.name}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-[10px] bg-slate-900 text-slate-400 px-2 py-0.5 rounded border border-slate-800">
                      {item.category}
                    </span>
                  </div>
                </div>
              );
            })
          ) : (
            <div className="p-8 text-center text-slate-500 space-y-2">
              <BarChart2 className="w-8 h-8 mx-auto opacity-40" />
              <p className="text-sm">No matching symbols found.</p>
              {query && (
                <button
                  onClick={() => {
                    onSelectSymbol(query.trim().toUpperCase());
                    onClose();
                  }}
                  className="text-xs font-bold text-cyan-400 hover:underline mt-2"
                >
                  Load "{query.trim().toUpperCase()}" directly from NSE/Kotak API →
                </button>
              )}
            </div>
          )}
        </div>

        {/* Footer info bar */}
        <div className="p-3 border-t border-slate-800 bg-slate-950/80 flex items-center justify-between text-[11px] text-slate-500">
          <div className="flex items-center gap-2">
            <span className="bg-slate-900 px-1.5 py-0.5 rounded border border-slate-800">↑↓</span> to navigate
            <span className="bg-slate-900 px-1.5 py-0.5 rounded border border-slate-800">↵</span> to select
            <span className="bg-slate-900 px-1.5 py-0.5 rounded border border-slate-800">ESC</span> to close
          </div>
          <span className="text-cyan-400/80 font-bold">Powered by Kotak Neo Engine</span>
        </div>

      </div>
    </div>
  );
};

import React from 'react';
import { TradeHealthMetrics } from '../types/trading';

interface TradeHealthSectionProps {
  health: TradeHealthMetrics | null;
}

export const TradeHealthSection: React.FC<TradeHealthSectionProps> = ({ health }) => {
  if (!health) return null;

  return (
    <div className="glass-panel rounded-xl p-4 border border-slate-800 font-mono text-xs h-full flex items-center justify-between select-none">
      {/* Gauge */}
      <div className="flex flex-col items-center justify-center text-center px-1">
        <div className="relative w-14 h-14 flex items-center justify-center">
          <svg className="w-full h-full transform -rotate-90">
            <circle cx="28" cy="28" r="21" stroke="#1E293B" strokeWidth="4" fill="transparent" />
            <circle cx="28" cy="28" r="21" stroke="#10B981" strokeWidth="4" fill="transparent" strokeDasharray="131" strokeDashoffset="21" strokeLinecap="round" />
          </svg>
          <span className="absolute text-xs font-extrabold text-white">84%</span>
        </div>
        <span className="text-sm font-bold text-slate-400 uppercase mt-0.5">TRADE HEALTH</span>
      </div>

      {/* Metrics List */}
      <div className="flex-1 space-y-0.5 pl-2 text-xs border-l border-slate-800">
        <div className="flex justify-between"><span className="text-slate-400">Holding Prob:</span><span className="text-emerald-400 font-bold">78%</span></div>
        <div className="flex justify-between"><span className="text-slate-400">Reduce Position Prob:</span><span className="text-slate-200 font-bold">14%</span></div>
        <div className="flex justify-between"><span className="text-slate-400">Exit Prob:</span><span className="text-slate-200 font-bold">8%</span></div>
        <div className="flex justify-between"><span className="text-slate-400">Risk Level:</span><span className="text-amber-400 font-bold">MEDIUM</span></div>
        <div className="flex justify-between"><span className="text-slate-400">Momentum Strength:</span><span className="text-emerald-400 font-bold">STRONG</span></div>
        <div className="flex justify-between"><span className="text-slate-400">Market Structure Quality:</span><span className="text-emerald-400 font-bold">GOOD</span></div>
        <div className="flex justify-between"><span className="text-slate-400">Historical Conf:</span><span className="text-slate-200 font-bold">87%</span></div>
        <div className="flex justify-between"><span className="text-slate-400">AI Conf:</span><span className="text-emerald-400 font-bold">88%</span></div>
      </div>
    </div>
  );
};

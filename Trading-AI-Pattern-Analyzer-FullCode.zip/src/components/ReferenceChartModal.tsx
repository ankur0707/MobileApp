import React, { useState } from 'react';
import { ReferencePattern } from '../types/trading';
import { X, Lock, Maximize2 } from 'lucide-react';

interface ReferenceChartModalProps {
  isOpen: boolean;
  onClose: () => void;
  refPattern: ReferencePattern | null;
}

export const ReferenceChartModal: React.FC<ReferenceChartModalProps> = ({
  isOpen,
  onClose,
  refPattern
}) => {
  const [selectedCandleIdx, setSelectedCandleIdx] = useState<number | null>(null);

  if (!isOpen || !refPattern) return null;

  const candles = refPattern.candles || [];
  if (candles.length === 0) return null;

  const minP = Math.min(...candles.map(c => c.low));
  const maxP = Math.max(...candles.map(c => c.high));
  const pRange = Math.max(0.0001, maxP - minP);

  const activeCandle = selectedCandleIdx !== null ? candles[selectedCandleIdx] : candles[candles.length - 1];

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 font-mono select-none animate-in fade-in duration-150">
      <div className="bg-[#080C16] border border-cyan-500/50 rounded-2xl w-full max-w-4xl max-h-[90vh] overflow-y-auto p-6 shadow-2xl shadow-cyan-900/30 flex flex-col gap-4">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-cyan-950 border border-cyan-500/40 flex items-center justify-center">
              <Lock className="w-5 h-5 text-cyan-400" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h3 className="text-base font-extrabold text-slate-100 tracking-wider">
                  REFERENCE PATTERN CHART
                </h3>
                <span className="text-[11px] bg-cyan-950 text-cyan-400 px-2 py-0.5 rounded border border-cyan-500/40 font-bold">
                  {refPattern.asset} • {refPattern.timeframe}
                </span>
                <span className="text-[11px] bg-emerald-950 text-emerald-400 px-2 py-0.5 rounded border border-emerald-500/40 font-bold">
                  {candles.length} Candles Locked
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Exact reference vector used for mathematical similarity matching & historical probability models
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white rounded-lg border border-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Selected Candle Inspector HUD Bar */}
        {activeCandle && (
          <div className="bg-[#050811] border border-slate-800 rounded-xl p-3 flex flex-wrap items-center justify-between gap-3 text-xs">
            <div className="flex items-center space-x-2">
              <span className="text-slate-400 font-bold">CANDLE #{activeCandle.index}</span>
              <span className="text-slate-600">•</span>
              <span className="text-slate-400">{new Date(activeCandle.time).toLocaleTimeString()}</span>
              <span className={`px-1.5 py-0.5 rounded text-[10px] font-extrabold ${activeCandle.isBullish ? 'bg-emerald-950 text-emerald-400 border border-emerald-500/30' : 'bg-rose-950 text-rose-400 border border-rose-500/30'}`}>
                {activeCandle.isBullish ? 'BULLISH' : 'BEARISH'}
              </span>
            </div>

            <div className="flex items-center space-x-4 text-xs font-mono">
              <span>O: <strong className="text-slate-200">{activeCandle.open.toFixed(2)}</strong></span>
              <span>H: <strong className="text-slate-200">{activeCandle.high.toFixed(2)}</strong></span>
              <span>L: <strong className="text-slate-200">{activeCandle.low.toFixed(2)}</strong></span>
              <span>C: <strong className={activeCandle.isBullish ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>{activeCandle.close.toFixed(2)}</strong></span>
              <span>Vol: <strong className="text-cyan-400">{activeCandle.volume}</strong></span>
              <span>RSI: <strong className="text-amber-400">{activeCandle.rsi || 50}</strong></span>
            </div>
          </div>
        )}

        {/* Candlestick Vector Canvas / SVG Chart */}
        <div className="bg-[#04060C] border border-slate-800/80 rounded-xl p-5 relative overflow-hidden">
          {/* Price Range Labels */}
          <div className="absolute top-3 right-4 text-[11px] font-bold text-slate-500 flex items-center gap-1">
            <span>HIGH:</span> <span className="text-slate-300 font-mono">{maxP.toFixed(2)}</span>
          </div>
          <div className="absolute bottom-3 right-4 text-[11px] font-bold text-slate-500 flex items-center gap-1">
            <span>LOW:</span> <span className="text-slate-300 font-mono">{minP.toFixed(2)}</span>
          </div>

          <div className="w-full h-64 flex items-center justify-center">
            <svg width="100%" height="100%" viewBox="0 0 600 220" preserveAspectRatio="none" className="overflow-visible">
              {/* Horizontal grid lines */}
              <line x1="0" y1="30" x2="600" y2="30" stroke="#1E293B" strokeDasharray="3 3" strokeWidth="0.8" />
              <line x1="0" y1="110" x2="600" y2="110" stroke="#1E293B" strokeDasharray="3 3" strokeWidth="0.8" />
              <line x1="0" y1="190" x2="600" y2="190" stroke="#1E293B" strokeDasharray="3 3" strokeWidth="0.8" />

              {candles.map((c, i) => {
                const totalCandles = candles.length;
                const slotWidth = 600 / totalCandles;
                const candleWidth = Math.max(6, slotWidth * 0.55);
                const xCenter = i * slotWidth + slotWidth / 2;
                const xLeft = xCenter - candleWidth / 2;

                const openY = 200 - ((c.open - minP) / pRange) * 175;
                const closeY = 200 - ((c.close - minP) / pRange) * 175;
                const highY = 200 - ((c.high - minP) / pRange) * 175;
                const lowY = 200 - ((c.low - minP) / pRange) * 175;
                const isBull = c.isBullish;
                const isSelected = selectedCandleIdx === i;

                return (
                  <g
                    key={i}
                    className="cursor-pointer transition-all hover:opacity-100 group"
                    onClick={() => setSelectedCandleIdx(i)}
                  >
                    {/* Hover column background */}
                    <rect
                      x={i * slotWidth}
                      y="10"
                      width={slotWidth}
                      height="200"
                      fill={isSelected ? 'rgba(6, 182, 212, 0.12)' : 'transparent'}
                      className="group-hover:fill-cyan-500/10 transition-colors"
                    />

                    {/* Wick */}
                    <line
                      x1={xCenter}
                      y1={highY}
                      x2={xCenter}
                      y2={lowY}
                      stroke={isBull ? '#10B981' : '#EF4444'}
                      strokeWidth={isSelected ? '2.5' : '1.8'}
                    />

                    {/* Body */}
                    <rect
                      x={xLeft}
                      y={Math.min(openY, closeY)}
                      width={candleWidth}
                      height={Math.max(4, Math.abs(closeY - openY))}
                      fill={isBull ? '#10B981' : '#EF4444'}
                      stroke={isSelected ? '#38BDF8' : isBull ? '#059669' : '#DC2626'}
                      strokeWidth={isSelected ? '1.5' : '0.8'}
                      rx="1"
                    />

                    {/* Candle index number at bottom */}
                    <text
                      x={xCenter}
                      y="215"
                      fill={isSelected ? '#38BDF8' : '#64748B'}
                      fontSize="9"
                      textAnchor="middle"
                      fontWeight="bold"
                    >
                      {i + 1}
                    </text>
                  </g>
                );
              })}
            </svg>
          </div>
          <div className="text-center text-[10px] text-slate-500 mt-2">
            Click on any candle above to inspect individual price points and volume
          </div>
        </div>

        {/* Vector Statistics Footer Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <div className="bg-slate-950/80 p-3 rounded-lg border border-slate-800 text-center">
            <span className="text-[11px] text-slate-400 block font-bold">Historical Match</span>
            <span className="text-base font-extrabold text-emerald-400">{refPattern.historicalMatchPct}%</span>
          </div>
          <div className="bg-slate-950/80 p-3 rounded-lg border border-slate-800 text-center">
            <span className="text-[11px] text-slate-400 block font-bold">Historical Win Rate</span>
            <span className="text-base font-extrabold text-emerald-400">{refPattern.historicalWinRate}%</span>
          </div>
          <div className="bg-slate-950/80 p-3 rounded-lg border border-slate-800 text-center">
            <span className="text-[11px] text-slate-400 block font-bold">Average Post-Pattern Move</span>
            <span className="text-base font-extrabold text-cyan-400">+{refPattern.averageProfitPct}%</span>
          </div>
          <div className="bg-slate-950/80 p-3 rounded-lg border border-slate-800 text-center">
            <span className="text-[11px] text-slate-400 block font-bold">Confidence Score</span>
            <span className="text-base font-extrabold text-amber-400">{refPattern.confidenceScore}%</span>
          </div>
        </div>
      </div>
    </div>
  );
};

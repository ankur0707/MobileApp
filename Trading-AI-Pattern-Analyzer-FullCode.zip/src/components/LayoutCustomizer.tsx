import React from 'react';
import { SectionVisibility } from '../types/trading';
import { SlidersHorizontal, Eye, EyeOff, CheckSquare, Square, X, RotateCcw } from 'lucide-react';

interface LayoutCustomizerProps {
  isOpen: boolean;
  onClose: () => void;
  visibility: SectionVisibility;
  onToggleSection: (key: keyof SectionVisibility) => void;
  onShowAll: () => void;
  onHideAll: () => void;
}

export const LayoutCustomizer: React.FC<LayoutCustomizerProps> = ({
  isOpen,
  onClose,
  visibility,
  onToggleSection,
  onShowAll,
  onHideAll
}) => {
  if (!isOpen) return null;

  const sectionsList: { key: keyof SectionVisibility; label: string; tag: string }[] = [
    { key: 'referencePattern', label: 'Section 1: Locked Reference Pattern Engine', tag: 'REF LOCK' },
    { key: 'aiDecision', label: 'Section 10: AI Decision Center (Master Summary)', tag: 'DECISION' },
    { key: 'patternIntegrity', label: 'Section 2: Pattern Integrity Engine', tag: 'INTEGRITY' },
    { key: 'tradeHealth', label: 'Section 4: Trade Health Engine & Meters', tag: 'HEALTH' },
    { key: 'winLossStructure', label: 'Section 3: Winning vs Losing Structure Engine', tag: 'WIN/LOSS' },
    { key: 'futureProjections', label: 'Section 5: Historical Future Projection Engine', tag: 'PROJECTION' },
    { key: 'evolutionTimeline', label: 'Section 6: Pattern Evolution Timeline', tag: 'TIMELINE' },
    { key: 'transitionDetector', label: 'Section 8: Historical Transition Detector', tag: 'TRANSITION' },
    { key: 'liveRanking', label: 'Section 7: Live Historical Ranking Cards', tag: 'RANKING' },
    { key: 'matchGallery', label: 'Section 9: Historical Match Gallery Grid', tag: 'GALLERY' },
    { key: 'candleInspector', label: 'Section 18: Candle Deep Structural Inspector', tag: 'INSPECTOR' }
  ];

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-[#0B0F19] border border-cyan-500/40 rounded-2xl w-full max-w-xl p-5 shadow-2xl shadow-cyan-500/20 font-mono">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
          <div className="flex items-center space-x-2">
            <SlidersHorizontal className="w-5 h-5 text-cyan-400" />
            <h3 className="text-sm font-extrabold text-slate-100">
              Customize Output Layout Display
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-3 bg-slate-900 border border-slate-800 rounded-lg text-slate-400 hover:text-white transition-all"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <p className="text-xs text-slate-400 mb-4">
          Select which output decision engines you want to display on your workspace. Uncheck any card to hide it.
        </p>

        {/* Global Controls */}
        <div className="flex items-center justify-between bg-slate-950 p-4 rounded-lg border border-slate-850 mb-4 text-xs">
          <span className="text-slate-400">Quick Layout Controls:</span>
          <div className="flex items-center space-x-2">
            <button
              onClick={onShowAll}
              className="px-2.5 py-1 bg-cyan-950 text-cyan-400 border border-cyan-500/40 hover:bg-cyan-900 rounded font-bold transition-all flex items-center space-x-1"
            >
              <Eye className="w-3.5 h-3.5" />
              <span>Show All</span>
            </button>
            <button
              onClick={onHideAll}
              className="px-2.5 py-1 bg-slate-900 text-slate-300 border border-slate-700 hover:bg-slate-800 rounded font-bold transition-all flex items-center space-x-1"
            >
              <EyeOff className="w-3.5 h-3.5" />
              <span>Hide All</span>
            </button>
          </div>
        </div>

        {/* List of Section Visibility Toggles */}
        <div className="space-y-2 max-h-80 overflow-y-auto pr-1">
          {sectionsList.map(sec => {
            const isVisible = visibility[sec.key];
            return (
              <div
                key={sec.key}
                onClick={() => onToggleSection(sec.key)}
                className={`p-3 rounded-lg border transition-all cursor-pointer flex items-center justify-between text-xs ${
                  isVisible
                    ? 'bg-slate-900/90 border-cyan-500/40 text-slate-100'
                    : 'bg-slate-950/40 border-slate-850 text-slate-500 opacity-60 hover:opacity-100'
                }`}
              >
                <div className="flex items-center space-x-3">
                  {isVisible ? (
                    <CheckSquare className="w-4 h-4 text-cyan-400 flex-shrink-0" />
                  ) : (
                    <Square className="w-4 h-4 text-slate-600 flex-shrink-0" />
                  )}
                  <span className="font-bold">{sec.label}</span>
                </div>
                <span className={`text-xs px-2 py-0.5 rounded font-bold ${
                  isVisible ? 'bg-cyan-950 text-cyan-400 border border-cyan-500/40' : 'bg-slate-900 text-slate-600'
                }`}>
                  {isVisible ? 'VISIBLE' : 'HIDDEN'}
                </span>
              </div>
            );
          })}
        </div>

        {/* Done Button */}
        <div className="mt-5 pt-3 border-t border-slate-800 text-right">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-gradient-to-r from-cyan-500 to-blue-600 text-black font-extrabold text-xs rounded-lg shadow-lg shadow-cyan-500/20"
          >
            Apply & Save Layout Settings
          </button>
        </div>
      </div>
    </div>
  );
};

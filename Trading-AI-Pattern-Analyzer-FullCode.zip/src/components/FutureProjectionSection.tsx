import React from 'react';
import { FutureProjectionMetrics } from '../types/trading';

interface FutureProjectionSectionProps {
  projections: FutureProjectionMetrics | null;
}

export const FutureProjectionSection: React.FC<FutureProjectionSectionProps> = ({ projections }) => {
  if (!projections) return null;

  return (
    <div className="glass-panel rounded-xl p-4 border border-slate-800 font-mono text-xs h-full flex flex-col justify-between select-none">
      <div className="flex items-center justify-between border-b border-slate-800 pb-1">
        <h4 className="font-extrabold uppercase text-slate-100 text-xs">HISTORICAL FUTURE PROJECTION ENGINE</h4>
      </div>

      <div className="space-y-0.5">
        <div className="flex justify-between"><span className="text-slate-400">Target Probability:</span><span className="text-emerald-400 font-bold">72%</span></div>
        <div className="flex justify-between"><span className="text-slate-400">Stop Loss Probability:</span><span className="text-rose-400 font-bold">18%</span></div>
        <div className="flex justify-between"><span className="text-slate-400">Breakout Probability:</span><span className="text-emerald-400 font-bold">61%</span></div>
        <div className="flex justify-between"><span className="text-slate-400">Breakdown Probability:</span><span className="text-amber-400 font-bold">19%</span></div>
        <div className="flex justify-between"><span className="text-slate-400">Sideways Probability:</span><span className="text-amber-400 font-bold">21%</span></div>
      </div>

      <div className="pt-1 border-t border-slate-900 grid grid-cols-2 gap-x-2 gap-y-0.5 text-xs">
        <div><span className="text-slate-400">Avg Move:</span> <strong className="text-emerald-400">+2.42%</strong></div>
        <div><span className="text-slate-400">Avg Drawdown:</span> <strong className="text-rose-400">-0.91%</strong></div>
        <div><span className="text-slate-400">Duration:</span> <strong className="text-slate-200">8.4 Candles</strong></div>
        <div><span className="text-slate-400">Volatility:</span> <strong className="text-slate-200">0.78%</strong></div>
        <div className="col-span-2"><span className="text-slate-400">CI:</span> <strong className="text-cyan-400">68% - 86%</strong></div>
      </div>
    </div>
  );
};

import React from 'react';
import { Candle } from '../types/trading';
import { Sliders, Gauge, Activity, TrendingUp, TrendingDown, Layers } from 'lucide-react';

interface CandleInspectorProps {
  candle: Candle | null;
}

export const CandleInspector: React.FC<CandleInspectorProps> = ({ candle }) => {
  if (!candle) {
    return (
      <div className="glass-panel rounded-xl p-4 border border-slate-800 text-center py-6">
        <Sliders className="w-6 h-6 text-slate-600 mx-auto mb-2 animate-bounce" />
        <p className="text-xs text-slate-400 font-mono">Hover over any candle on the chart to inspect full OHLC, Structure, and Technical Indicators.</p>
      </div>
    );
  }

  return (
    <div className="glass-panel-glow-cyan rounded-xl p-4 border border-cyan-500/30">
      <div className="flex items-center justify-between border-b border-slate-800 pb-2.5 mb-3">
        <div className="flex items-center space-x-2">
          <Activity className="w-4 h-4 text-cyan-400" />
          <h4 className="text-xs font-extrabold uppercase tracking-wider text-slate-200 font-mono">
            Candle Deep Structural Inspector (#{candle.index})
          </h4>
        </div>
        <span className={`text-xs font-bold font-mono px-2 py-0.5 rounded ${
          candle.isBullish ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40' : 'bg-red-500/20 text-red-400 border border-red-500/40'
        }`}>
          {candle.isBullish ? 'BULLISH CANDLE' : 'BEARISH CANDLE'}
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs font-mono">
        {/* 1. OHLC Data */}
        <div className="bg-slate-900/80 rounded-lg p-4 border border-slate-800">
          <span className="text-xs text-slate-500 font-semibold uppercase block mb-1.5">OHLC Price Data</span>
          <div className="grid grid-cols-2 gap-4">
            <div><span className="text-slate-400">Open:</span> <span className="text-slate-100 font-bold">${candle.open}</span></div>
            <div><span className="text-slate-400">High:</span> <span className="text-emerald-400 font-bold">${candle.high}</span></div>
            <div><span className="text-slate-400">Low:</span> <span className="text-red-400 font-bold">${candle.low}</span></div>
            <div><span className="text-slate-400">Close:</span> <span className="text-slate-100 font-bold">${candle.close}</span></div>
          </div>
        </div>

        {/* 2. Candle Structure Data */}
        <div className="bg-slate-900/80 rounded-lg p-4 border border-slate-800">
          <span className="text-xs text-slate-500 font-semibold uppercase block mb-1.5">Body & Wick Ratios</span>
          <div className="space-y-1.5">
            <div className="flex justify-between items-center">
              <span className="text-slate-400">Body Size:</span>
              <span className="text-cyan-400 font-bold">{candle.body} ({candle.bodyPct}%)</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-400">Upper Wick:</span>
              <span className="text-slate-200">{candle.upperWick}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-400">Lower Wick:</span>
              <span className="text-slate-200">{candle.lowerWick}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-400">Total Wick Ratio:</span>
              <span className="text-amber-400 font-bold">{candle.wickPct}%</span>
            </div>
          </div>
        </div>

        {/* 3. Indicators Data */}
        <div className="bg-slate-900/80 rounded-lg p-4 border border-slate-800">
          <span className="text-xs text-slate-500 font-semibold uppercase block mb-1.5">Technical Indicators</span>
          <div className="grid grid-cols-2 gap-x-2 gap-y-1">
            <div><span className="text-slate-400">RSI (14):</span> <span className="text-purple-400 font-bold">{candle.rsi}</span></div>
            <div><span className="text-slate-400">ATR:</span> <span className="text-slate-200 font-bold">{candle.atr}</span></div>
            <div><span className="text-slate-400">EMA20:</span> <span className="text-cyan-300">${candle.ema20}</span></div>
            <div><span className="text-slate-400">EMA50:</span> <span className="text-blue-300">${candle.ema50}</span></div>
            <div className="col-span-2"><span className="text-slate-400">MACD Hist:</span> <span className={candle.macd.histogram >= 0 ? 'text-emerald-400 font-bold' : 'text-red-400 font-bold'}>{candle.macd.histogram}</span></div>
          </div>
        </div>
      </div>
    </div>
  );
};

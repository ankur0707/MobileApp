import React from 'react';
import { PatternEvolutionStep } from '../types/trading';

interface PatternEvolutionTimelineProps {
  steps: PatternEvolutionStep[];
}

export const PatternEvolutionTimeline: React.FC<PatternEvolutionTimelineProps> = ({ steps }) => {
  return (
    <div className="glass-panel rounded-xl p-4 border border-slate-800 font-mono text-xs h-full flex flex-col justify-between select-none">
      <div className="flex items-center justify-between border-b border-slate-800 pb-1">
        <h4 className="font-extrabold uppercase text-slate-100 text-xs">EVOLUTION TIMELINE</h4>
      </div>

      <div className="space-y-1 my-auto pr-1">
        <div className="flex items-center justify-between border-l-2 border-blue-500 pl-2">
          <span className="text-slate-200 font-bold">Reference Pattern</span>
          <span className="text-cyan-400 font-bold">Match 94% | Win 76%</span>
        </div>
        <div className="flex items-center justify-between border-l-2 border-blue-500 pl-2">
          <span className="text-slate-300">Candle +1</span>
          <span className="text-slate-300">Match 93% | Win 75%</span>
        </div>
        <div className="flex items-center justify-between border-l-2 border-emerald-500 pl-2">
          <span className="text-slate-300">Candle +2</span>
          <span className="text-slate-300">Match 92% | Win 74%</span>
        </div>
        <div className="flex items-center justify-between border-l-2 border-amber-500 pl-2">
          <span className="text-slate-300">Candle +3</span>
          <span className="text-slate-300">Match 89% | Win 73%</span>
        </div>
        <div className="flex items-center justify-between border-l-2 border-amber-500 pl-2">
          <span className="text-slate-100 font-bold">Current Candle</span>
          <span className="text-emerald-400 font-bold">Match 87% | Win 72%</span>
        </div>
      </div>
    </div>
  );
};

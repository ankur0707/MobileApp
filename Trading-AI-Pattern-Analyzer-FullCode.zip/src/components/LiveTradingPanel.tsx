import React, { useState, useEffect, useMemo } from 'react';
import { 
  Zap, 
  ShieldCheck, 
  ChevronDown, 
  ChevronUp,
  AlertTriangle,
  CheckCircle2,
  Lock,
  ExternalLink
} from 'lucide-react';
import { Candle, LiveOrder, LivePosition, LiveOrderType, LiveProductType, LiveOrderSide } from '../types/trading';

interface LiveTradingPanelProps {
  asset: string;
  candles: Candle[];
  isMarketOpen?: boolean;
  onOpenApiSettings?: () => void;
  onLogPaperTrade?: (trade: any) => void;
}

export const LiveTradingPanel: React.FC<LiveTradingPanelProps> = ({
  asset,
  candles,
  isMarketOpen = false,
  onOpenApiSettings,
  onLogPaperTrade
}) => {
  const lastCandle = candles[candles.length - 1];
  const currentPrice = lastCandle ? lastCandle.close : 0;

  // Trading Mode: REAL DEMAT vs VIRTUAL PAPER
  const [executionMode, setExecutionMode] = useState<'REAL_DEMAT' | 'PAPER'>('REAL_DEMAT');
  const [isDematAuth, setIsDematAuth] = useState<boolean>(false);
  const [dematUcc, setDematUcc] = useState<string>('');

  // Order Configurations
  const [productType, setProductType] = useState<LiveProductType>('MIS');
  const [orderType, setOrderType] = useState<LiveOrderType>('MARKET');
  const [qty, setQty] = useState<number>(() => {
    if (asset.includes('NIFTY') && !asset.includes('BANK')) return 25;
    if (asset.includes('BANK')) return 15;
    return 1;
  });
  const [limitPrice, setLimitPrice] = useState<number>(currentPrice || 0);
  const [triggerPrice, setTriggerPrice] = useState<number>(currentPrice || 0);
  const [enableSLTarget, setEnableSLTarget] = useState<boolean>(false);
  const [stopLossPts, setStopLossPts] = useState<number>(10);
  const [targetPts, setTargetPts] = useState<number>(20);

  // Status & Orders State
  const [activeTab, setActiveTab] = useState<'positions' | 'orders'>('positions');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [orderAlert, setOrderAlert] = useState<{ type: 'success' | 'error'; message: string } | null>(null);
  const [positions, setPositions] = useState<LivePosition[]>([]);
  const [orders, setOrders] = useState<LiveOrder[]>([]);

  // Update default qty when asset changes
  useEffect(() => {
    if (asset.includes('NIFTY') && !asset.includes('BANK')) {
      setQty(25);
    } else if (asset.includes('BANK')) {
      setQty(15);
    } else {
      setQty(1);
    }
  }, [asset]);

  // Keep limit price synchronized with CMP if untouched
  useEffect(() => {
    if (currentPrice > 0 && orderType === 'MARKET') {
      setLimitPrice(currentPrice);
      setTriggerPrice(currentPrice);
    }
  }, [currentPrice, orderType]);

  // Check Demat Status
  const checkBrokerStatus = async () => {
    try {
      const res = await fetch('http://localhost:4000/api/kotak/status');
      if (res.ok) {
        const data = await res.json();
        setIsDematAuth(Boolean(data.dematAuthenticated));
        setDematUcc(data.ucc || '');
      }
    } catch (_) {}
  };

  // Fetch live positions and orders from backend
  const fetchLivePortfolio = async () => {
    try {
      const posRes = await fetch('http://localhost:4000/api/kotak/positions');
      if (posRes.ok) {
        const data = await posRes.json();
        setPositions(data.positions || []);
      }
      const ordRes = await fetch('http://localhost:4000/api/kotak/orders');
      if (ordRes.ok) {
        const data = await ordRes.json();
        setOrders(data.orders || []);
      }
    } catch (e) {
      // Backend offline or local fallback
    }
  };

  useEffect(() => {
    checkBrokerStatus();
    fetchLivePortfolio();
    const interval = setInterval(() => {
      checkBrokerStatus();
      fetchLivePortfolio();
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  // Calculate live PnL for active positions
  const totalUnrealizedPnl = useMemo(() => {
    return positions.reduce((acc, pos) => {
      const posPrice = pos.symbol === asset ? currentPrice : pos.currentPrice;
      const diff = pos.side === 'BUY' ? posPrice - pos.entryPrice : pos.entryPrice - posPrice;
      return acc + (diff * pos.qty);
    }, 0);
  }, [positions, currentPrice, asset]);

  // Margin calculation estimate
  const marginRequired = useMemo(() => {
    const rawValue = (orderType === 'MARKET' ? currentPrice : limitPrice) * qty;
    return productType === 'MIS' ? rawValue * 0.2 : rawValue;
  }, [currentPrice, limitPrice, qty, productType, orderType]);

  // Handle Order Placement
  const handlePlaceOrder = async (side: LiveOrderSide) => {
    if (qty <= 0) return;
    setIsSubmitting(true);
    setOrderAlert(null);

    const execPrice = orderType === 'MARKET' ? currentPrice : limitPrice;

    const payload = {
      mode: executionMode,
      symbol: asset,
      side,
      orderType,
      product: productType,
      qty,
      price: execPrice,
      triggerPrice: orderType.includes('SL') ? triggerPrice : undefined,
      stopLoss: enableSLTarget ? stopLossPts : undefined,
      target: enableSLTarget ? targetPts : undefined
    };

    try {
      const res = await fetch('http://localhost:4000/api/kotak/order', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      const data = await res.json();
      if (res.ok && data.success) {
        if (executionMode === 'REAL_DEMAT') {
          const ordId = data.order?.orderId || 'Submitted';
          setOrderAlert({
            type: 'success',
            message: `✓ DEMAT ORDER PUNCHED: ${side} ${qty} ${asset} @ ₹${execPrice.toFixed(2)} | Kotak ID: ${ordId}`
          });
        } else {
          setOrderAlert({
            type: 'success',
            message: `✓ PAPER TRADE EXECUTED: ${side} ${qty} ${asset} @ ₹${execPrice.toFixed(2)}`
          });
        }
        fetchLivePortfolio();
      } else {
        // Real Kotak Neo failure or unauthenticated session
        const errText = data.error || (
          executionMode === 'REAL_DEMAT'
            ? 'Kotak Neo Demat account not authenticated. Please complete 2FA login in API Settings.'
            : 'Order Placement Failed.'
        );
        setOrderAlert({
          type: 'error',
          message: `✗ ${errText}`
        });
      }
    } catch (e: any) {
      setOrderAlert({
        type: 'error',
        message: `✗ Network Connection Error: ${e.message}`
      });
    } finally {
      setIsSubmitting(false);
      setTimeout(() => setOrderAlert(null), 12000);
    }
  };

  // Handle Square-Off / Exit Position
  const handleExitPosition = async (positionId: string) => {
    const posToExit = positions.find(p => p.positionId === positionId);
    let pnlNum = 0;
    if (posToExit) {
      const exitPrice = posToExit.symbol === asset ? currentPrice : posToExit.currentPrice;
      const pnl = posToExit.side === 'BUY'
        ? (exitPrice - posToExit.entryPrice) * posToExit.qty
        : (posToExit.entryPrice - exitPrice) * posToExit.qty;
      pnlNum = Number(pnl.toFixed(2));

      if (onLogPaperTrade) {
        onLogPaperTrade({
          id: 'trade_' + Math.random().toString(36).substring(2, 9),
          asset: posToExit.symbol,
          type: posToExit.side === 'BUY' ? 'LONG' : 'SHORT',
          entryPrice: posToExit.entryPrice,
          exitPrice,
          pnl: pnlNum,
          qty: posToExit.qty,
          openTime: posToExit.openTime || new Date().toLocaleTimeString(),
          closeTime: new Date().toISOString(),
          isDemat: Boolean(posToExit.isDemat)
        });
      }
    }

    try {
      await fetch('http://localhost:4000/api/kotak/exit-position', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ positionId })
      });
      fetchLivePortfolio();
    } catch (e) {
      // Local fallback
    }
    setPositions(prev => prev.filter(p => p.positionId !== positionId));
    setOrderAlert({ 
      type: 'success', 
      message: `✓ Position Exited (${posToExit?.symbol || ''} P&L: ${pnlNum >= 0 ? '+' : ''}₹${pnlNum.toFixed(2)}) & Saved to Trading Journal` 
    });
    setTimeout(() => setOrderAlert(null), 8000);
  };

  // Quick Qty Preset Handlers
  const handlePresetQty = (val: number) => {
    setQty(prev => Math.max(1, prev + val));
  };

  return (
    <div className="glass-panel p-4 flex flex-col gap-3 font-mono border border-cyan-500/30 shadow-lg shadow-cyan-950/20 text-xs select-none">
      
      {/* Panel Header & Mode Switcher */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
        <div className="flex items-center space-x-2">
          <div className={`w-2.5 h-2.5 rounded-full ${executionMode === 'REAL_DEMAT' ? 'bg-rose-500 animate-pulse' : 'bg-emerald-400'}`}></div>
          <h2 className="font-extrabold text-sm tracking-wider text-slate-100 flex items-center gap-1.5">
            <Zap className="w-4 h-4 text-cyan-400" />
            LIVE TRADING TERMINAL
          </h2>
        </div>

        {/* Dual Mode Selector */}
        <div className="flex items-center space-x-1.5 bg-slate-950 p-1 rounded-lg border border-slate-800">
          <button
            onClick={() => setExecutionMode('REAL_DEMAT')}
            className={`px-2.5 py-1 rounded text-[10px] font-extrabold flex items-center space-x-1 transition-all cursor-pointer ${
              executionMode === 'REAL_DEMAT'
                ? 'bg-rose-950 text-rose-300 border border-rose-500/60 shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <span className="w-1.5 h-1.5 rounded-full bg-rose-500"></span>
            <span>🔴 REAL DEMAT</span>
          </button>
          
          <button
            onClick={() => setExecutionMode('PAPER')}
            className={`px-2.5 py-1 rounded text-[10px] font-extrabold flex items-center space-x-1 transition-all cursor-pointer ${
              executionMode === 'PAPER'
                ? 'bg-emerald-950 text-emerald-300 border border-emerald-500/60 shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
            <span>🟢 PAPER TRADE</span>
          </button>

          {onOpenApiSettings && (
            <button
              onClick={onOpenApiSettings}
              className="ml-1 text-[10px] text-cyan-400 hover:text-cyan-300 hover:underline px-1.5 py-0.5 border border-cyan-500/30 rounded cursor-pointer"
            >
              2FA Login
            </button>
          )}
        </div>
      </div>

      {/* Demat Mode Status Banner */}
      {executionMode === 'REAL_DEMAT' && (
        isDematAuth ? (
          <div className="bg-emerald-950/40 border border-emerald-500/40 rounded p-2 flex items-center justify-between text-[11px] text-emerald-300">
            <div className="flex items-center space-x-2">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
              <span><strong>Demat Active:</strong> Client ID <code>{dematUcc || 'Logged In'}</code> — Orders punch to Kotak</span>
            </div>
            <span className="text-[9px] bg-emerald-900/60 border border-emerald-500/40 px-1.5 py-0.5 rounded font-bold">
              REAL DEMAT READY
            </span>
          </div>
        ) : (
          <div className="bg-amber-950/40 border border-amber-500/40 rounded p-2 flex items-center justify-between text-[11px] text-amber-300">
            <div className="flex items-center space-x-2">
              <AlertTriangle className="w-3.5 h-3.5 text-amber-400 flex-shrink-0" />
              <span><strong>Demat 2FA Required:</strong> Real orders require TOTP/MPIN session.</span>
            </div>
            {onOpenApiSettings && (
              <button
                onClick={onOpenApiSettings}
                className="text-[10px] font-bold bg-amber-500 text-black px-2 py-0.5 rounded hover:bg-amber-400 transition-colors flex items-center space-x-1 cursor-pointer"
              >
                <span>Login 2FA</span>
                <ExternalLink className="w-2.5 h-2.5" />
              </button>
            )}
          </div>
        )
      )}

      {executionMode === 'PAPER' && (
        <div className="bg-slate-900/60 border border-cyan-500/20 rounded p-2 flex items-center justify-between text-[11px] text-slate-300">
          <span className="text-cyan-300"><strong>Virtual Simulation Active:</strong> Live market ticks used for safe paper practice (No real money).</span>
          <span className="text-[9px] bg-slate-800 text-slate-400 px-1.5 py-0.5 rounded">VIRTUAL</span>
        </div>
      )}

      {/* Real Execution Alert / Notification Banner */}
      {orderAlert && (
        <div
          className={`p-2.5 rounded-lg border text-[11px] flex items-start space-x-2 transition-all ${
            orderAlert.type === 'success'
              ? 'bg-emerald-950/70 border-emerald-500 text-emerald-200'
              : 'bg-rose-950/70 border-rose-500 text-rose-200'
          }`}
        >
          {orderAlert.type === 'success' ? (
            <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
          ) : (
            <AlertTriangle className="w-4 h-4 text-rose-400 flex-shrink-0 mt-0.5" />
          )}
          <div className="flex-1 font-bold leading-tight">
            {orderAlert.message}
          </div>
        </div>
      )}

      {/* Asset & Current Market Price Strip */}
      <div className="flex items-center justify-between bg-slate-950/80 p-2.5 rounded-lg border border-slate-800">
        <div>
          <span className="text-[10px] text-slate-500 font-bold block">SYMBOL</span>
          <span className="text-xs font-extrabold text-cyan-300">{asset}</span>
        </div>
        <div className="text-right">
          <span className="text-[10px] text-slate-500 font-bold block">
            {isMarketOpen ? 'LIVE CMP' : 'OFFICIAL CLOSE'}
          </span>
          <span className="text-sm font-extrabold text-emerald-400">
            ₹{currentPrice > 0 ? currentPrice.toFixed(2) : '--'}
          </span>
        </div>
      </div>

      {/* Product & Order Type Selector */}
      <div className="grid grid-cols-2 gap-2">
        {/* Product Type (MIS vs CNC) */}
        <div>
          <label className="text-[10px] text-slate-400 font-bold block mb-1">PRODUCT</label>
          <div className="grid grid-cols-2 gap-1 bg-slate-950 p-0.5 rounded border border-slate-800">
            <button
              onClick={() => setProductType('MIS')}
              className={`py-1 text-[11px] font-bold rounded transition-all cursor-pointer ${
                productType === 'MIS'
                  ? 'bg-cyan-950 text-cyan-300 border border-cyan-500/40'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              MIS (Intra)
            </button>
            <button
              onClick={() => setProductType('CNC')}
              className={`py-1 text-[11px] font-bold rounded transition-all cursor-pointer ${
                productType === 'CNC'
                  ? 'bg-cyan-950 text-cyan-300 border border-cyan-500/40'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              CNC (Carry)
            </button>
          </div>
        </div>

        {/* Order Type */}
        <div>
          <label className="text-[10px] text-slate-400 font-bold block mb-1">ORDER TYPE</label>
          <div className="grid grid-cols-4 gap-0.5 bg-slate-950 p-0.5 rounded border border-slate-800">
            {(['MARKET', 'LIMIT', 'SL', 'SL-M'] as LiveOrderType[]).map((t) => (
              <button
                key={t}
                onClick={() => setOrderType(t)}
                className={`py-1 text-[10px] font-bold rounded transition-all cursor-pointer ${
                  orderType === t
                    ? 'bg-cyan-950 text-cyan-300 border border-cyan-500/40'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {t}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Quantity & Preset Selectors */}
      <div className="space-y-1.5">
        <div className="flex items-center justify-between">
          <label className="text-[10px] text-slate-400 font-bold">QUANTITY (LOTS / SHARES)</label>
          <span className="text-[10px] text-slate-500">
            Approx Margin: ₹{marginRequired.toLocaleString('en-IN', { maximumFractionDigits: 0 })}
          </span>
        </div>

        <div className="flex items-center space-x-2">
          <input
            type="number"
            min={1}
            value={qty}
            onChange={(e) => setQty(Math.max(1, parseInt(e.target.value) || 1))}
            className="w-28 bg-slate-950 border border-slate-700 rounded py-1.5 px-2 text-center text-slate-100 font-bold focus:outline-none focus:border-cyan-500"
          />

          {/* Preset Buttons for Indian Indices & Stocks */}
          <div className="flex-1 flex space-x-1 overflow-x-auto custom-scrollbar">
            {asset.includes('NIFTY') && !asset.includes('BANK') ? (
              <>
                <button
                  onClick={() => setQty(25)}
                  className="px-2 py-1 bg-slate-900 hover:bg-slate-800 border border-slate-800 text-[10px] font-bold text-slate-300 rounded cursor-pointer"
                >
                  1L (25)
                </button>
                <button
                  onClick={() => setQty(50)}
                  className="px-2 py-1 bg-slate-900 hover:bg-slate-800 border border-slate-800 text-[10px] font-bold text-slate-300 rounded cursor-pointer"
                >
                  2L (50)
                </button>
                <button
                  onClick={() => handlePresetQty(25)}
                  className="px-2 py-1 bg-slate-900 hover:bg-slate-800 border border-slate-800 text-[10px] font-bold text-cyan-400 rounded cursor-pointer"
                >
                  +25
                </button>
              </>
            ) : asset.includes('BANK') ? (
              <>
                <button
                  onClick={() => setQty(15)}
                  className="px-2 py-1 bg-slate-900 hover:bg-slate-800 border border-slate-800 text-[10px] font-bold text-slate-300 rounded cursor-pointer"
                >
                  1L (15)
                </button>
                <button
                  onClick={() => setQty(30)}
                  className="px-2 py-1 bg-slate-900 hover:bg-slate-800 border border-slate-800 text-[10px] font-bold text-slate-300 rounded cursor-pointer"
                >
                  2L (30)
                </button>
                <button
                  onClick={() => handlePresetQty(15)}
                  className="px-2 py-1 bg-slate-900 hover:bg-slate-800 border border-slate-800 text-[10px] font-bold text-cyan-400 rounded cursor-pointer"
                >
                  +15
                </button>
              </>
            ) : (
              <>
                <button
                  onClick={() => setQty(1)}
                  className="px-2 py-1 bg-slate-900 hover:bg-slate-800 border border-slate-800 text-[10px] font-bold text-slate-300 rounded cursor-pointer"
                >
                  1
                </button>
                <button
                  onClick={() => handlePresetQty(10)}
                  className="px-2 py-1 bg-slate-900 hover:bg-slate-800 border border-slate-800 text-[10px] font-bold text-cyan-400 rounded cursor-pointer"
                >
                  +10
                </button>
                <button
                  onClick={() => handlePresetQty(50)}
                  className="px-2 py-1 bg-slate-900 hover:bg-slate-800 border border-slate-800 text-[10px] font-bold text-cyan-400 rounded cursor-pointer"
                >
                  +50
                </button>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Price Inputs (Limit & Trigger) */}
      {(orderType === 'LIMIT' || orderType.includes('SL')) && (
        <div className="grid grid-cols-2 gap-2 pt-1 border-t border-slate-800/80">
          {(orderType === 'LIMIT' || orderType === 'SL') && (
            <div>
              <label className="text-[10px] text-slate-400 font-bold block mb-1">LIMIT PRICE (₹)</label>
              <input
                type="number"
                step="0.05"
                value={limitPrice}
                onChange={(e) => setLimitPrice(parseFloat(e.target.value) || 0)}
                className="w-full bg-slate-950 border border-slate-700 rounded py-1 px-2 text-slate-200 focus:outline-none focus:border-cyan-500 font-bold text-xs"
              />
            </div>
          )}

          {orderType.includes('SL') && (
            <div>
              <label className="text-[10px] text-slate-400 font-bold block mb-1">TRIGGER PRICE (₹)</label>
              <input
                type="number"
                step="0.05"
                value={triggerPrice}
                onChange={(e) => setTriggerPrice(parseFloat(e.target.value) || 0)}
                className="w-full bg-slate-950 border border-slate-700 rounded py-1 px-2 text-amber-300 focus:outline-none focus:border-cyan-500 font-bold text-xs"
              />
            </div>
          )}
        </div>
      )}

      {/* Target & StopLoss Option */}
      <div className="pt-1">
        <div className="flex items-center justify-between">
          <label className="flex items-center space-x-1.5 cursor-pointer">
            <input
              type="checkbox"
              checked={enableSLTarget}
              onChange={(e) => setEnableSLTarget(e.target.checked)}
              className="accent-cyan-500 rounded"
            />
            <span className="text-[10px] font-bold text-slate-400">Target & Stop Loss Bracket</span>
          </label>
        </div>

        {enableSLTarget && (
          <div className="grid grid-cols-2 gap-2 mt-2 bg-slate-950/60 p-2 rounded border border-slate-800">
            <div>
              <label className="text-[9px] text-rose-400 font-bold block mb-0.5">STOP LOSS (PTS)</label>
              <input
                type="number"
                min={1}
                value={stopLossPts}
                onChange={(e) => setStopLossPts(Math.max(1, parseInt(e.target.value) || 1))}
                className="w-full bg-slate-900 border border-slate-700 rounded py-0.5 px-2 text-rose-300 text-xs font-bold"
              />
            </div>
            <div>
              <label className="text-[9px] text-emerald-400 font-bold block mb-0.5">TARGET (PTS)</label>
              <input
                type="number"
                min={1}
                value={targetPts}
                onChange={(e) => setTargetPts(Math.max(1, parseInt(e.target.value) || 1))}
                className="w-full bg-slate-900 border border-slate-700 rounded py-0.5 px-2 text-emerald-300 text-xs font-bold"
              />
            </div>
          </div>
        )}
      </div>

      {/* Buy & Sell Action Buttons */}
      <div className="grid grid-cols-2 gap-2 pt-2">
        <button
          onClick={() => handlePlaceOrder('BUY')}
          disabled={isSubmitting}
          className="py-2.5 rounded-lg text-xs font-extrabold uppercase tracking-wider bg-emerald-600 hover:bg-emerald-500 text-white shadow-lg shadow-emerald-950/40 transition-all flex items-center justify-center space-x-1 cursor-pointer disabled:opacity-50"
        >
          <span>BUY (LONG)</span>
          <span className="text-[10px] opacity-80">
            ₹{((orderType === 'MARKET' ? currentPrice : limitPrice) * qty).toLocaleString('en-IN', { maximumFractionDigits: 0 })}
          </span>
        </button>

        <button
          onClick={() => handlePlaceOrder('SELL')}
          disabled={isSubmitting}
          className="py-2.5 rounded-lg text-xs font-extrabold uppercase tracking-wider bg-rose-600 hover:bg-rose-500 text-white shadow-lg shadow-rose-950/40 transition-all flex items-center justify-center space-x-1 cursor-pointer disabled:opacity-50"
        >
          <span>SELL (SHORT)</span>
          <span className="text-[10px] opacity-80">
            ₹{((orderType === 'MARKET' ? currentPrice : limitPrice) * qty).toLocaleString('en-IN', { maximumFractionDigits: 0 })}
          </span>
        </button>
      </div>

      {/* Positions & Order Book Strip */}
      <div className="mt-2 pt-2 border-t border-slate-800">
        <div className="flex items-center justify-between mb-2">
          <div className="flex space-x-3">
            <button
              onClick={() => setActiveTab('positions')}
              className={`text-[11px] font-bold pb-1 transition-all cursor-pointer ${
                activeTab === 'positions'
                  ? 'text-cyan-400 border-b-2 border-cyan-400'
                  : 'text-slate-500 hover:text-slate-300'
              }`}
            >
              Open Positions ({positions.length})
            </button>
            <button
              onClick={() => setActiveTab('orders')}
              className={`text-[11px] font-bold pb-1 transition-all cursor-pointer ${
                activeTab === 'orders'
                  ? 'text-cyan-400 border-b-2 border-cyan-400'
                  : 'text-slate-500 hover:text-slate-300'
              }`}
            >
              Order Book ({orders.length})
            </button>
          </div>

          {positions.length > 0 && (
            <span className={`text-[11px] font-bold ${totalUnrealizedPnl >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
              P&L: {totalUnrealizedPnl >= 0 ? '+' : ''}₹{totalUnrealizedPnl.toFixed(2)}
            </span>
          )}
        </div>

        {/* Positions View */}
        {activeTab === 'positions' ? (
          <div className="space-y-1.5 max-h-36 overflow-y-auto pr-1 custom-scrollbar">
            {positions.length === 0 ? (
              <div className="text-slate-500 text-center py-3 text-[10px]">
                No active positions in this session
              </div>
            ) : (
              positions.map((pos) => {
                const posPrice = pos.symbol === asset ? currentPrice : pos.currentPrice;
                const pnl = pos.side === 'BUY'
                  ? (posPrice - pos.entryPrice) * pos.qty
                  : (pos.entryPrice - posPrice) * pos.qty;

                return (
                  <div
                    key={pos.positionId}
                    className="bg-slate-950 p-2 rounded border border-slate-800 flex items-center justify-between text-[11px]"
                  >
                    <div>
                      <div className="flex items-center space-x-1.5">
                        <span className={`font-bold ${pos.side === 'BUY' ? 'text-emerald-400' : 'text-rose-400'}`}>
                          {pos.side}
                        </span>
                        <span className="font-extrabold text-slate-200">{pos.symbol}</span>
                        <span className="text-slate-500">x{pos.qty}</span>
                        <span className="text-[9px] bg-slate-900 text-slate-400 px-1 rounded">{pos.product}</span>
                        {pos.isDemat && (
                          <span className="text-[9px] bg-emerald-950 text-emerald-400 border border-emerald-600/40 px-1 rounded font-bold">
                            DEMAT
                          </span>
                        )}
                      </div>
                      <div className="text-[10px] text-slate-500 mt-0.5">
                        Avg: ₹{pos.entryPrice.toFixed(2)} → LTP: ₹{posPrice.toFixed(2)}
                      </div>
                    </div>

                    <div className="flex items-center space-x-2">
                      <span className={`font-bold ${pnl >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                        {pnl >= 0 ? '+' : ''}₹{pnl.toFixed(2)}
                      </span>
                      <button
                        onClick={() => handleExitPosition(pos.positionId)}
                        className="px-1.5 py-0.5 bg-rose-950 hover:bg-rose-900 text-rose-300 rounded border border-rose-500/30 text-[10px] font-bold cursor-pointer transition-colors"
                        title="Square Off Position"
                      >
                        Exit
                      </button>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        ) : (
          /* Order Book View */
          <div className="space-y-1.5 max-h-36 overflow-y-auto pr-1 custom-scrollbar">
            {orders.length === 0 ? (
              <div className="text-slate-500 text-center py-3 text-[10px]">
                No orders placed in this session
              </div>
            ) : (
              orders.map((ord) => (
                <div
                  key={ord.orderId}
                  className="bg-slate-950 p-2 rounded border border-slate-800 flex items-center justify-between text-[10px]"
                >
                  <div>
                    <div className="flex items-center space-x-1.5">
                      <span className={`font-bold ${ord.side === 'BUY' ? 'text-emerald-400' : 'text-rose-400'}`}>
                        {ord.side}
                      </span>
                      <span className="font-bold text-slate-200">{ord.symbol}</span>
                      <span className="text-slate-500">({ord.qty} Qty)</span>
                      <span className="text-[9px] text-slate-500">{ord.orderType}</span>
                      {ord.isDemat && (
                        <span className="text-[8px] bg-rose-950 text-rose-300 border border-rose-600/40 px-1 rounded font-bold">
                          DEMAT
                        </span>
                      )}
                    </div>
                    <div className="text-slate-500 mt-0.5">
                      {ord.placedTime} • #{ord.orderId}
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="text-emerald-400 font-bold block">₹{ord.price.toFixed(2)}</span>
                    <span className="text-[9px] bg-emerald-950/60 text-emerald-300 border border-emerald-500/30 px-1 py-0.2 rounded font-bold">
                      {ord.status}
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>
        )}
      </div>
    </div>
  );
};
export interface Candle {
  index: number;
  time: string;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  // Candle Structure Metrics
  body: number;
  bodyPct: number;
  upperWick: number;
  lowerWick: number;
  wickPct: number;
  isBullish: boolean;
  // Technical Indicators
  ema20: number;
  ema50: number;
  ema200: number;
  rsi: number;
  macd: {
    macdLine: number;
    signalLine: number;
    histogram: number;
  };
  atr: number;
}

export interface SelectedPattern {
  startIndex: number;
  endIndex: number;
  candles: Candle[];
}

export interface ReferencePattern {
  locked: boolean;
  selectedCandleCount: number;
  timeframe: string;
  asset: string;
  candles: Candle[];
  patternName: string;
  historicalMatchPct: number;
  historicalWinRate: number;
  historicalLossRate: number;
  averageProfitPct: number;
  averageDrawdownPct: number;
  sampleSize: number;
  confidenceScore: number;
  status: 'LOCKED REFERENCE';
  // Indicators snapshot at lock time
  snapshotIndicators: {
    rsi: number;
    emaTrend: 'Bullish' | 'Bearish' | 'Neutral';
    atrVolatility: number;
  };
}

export type PatternIntegrityStatus = 
  | 'Original Pattern Valid' 
  | 'Pattern Weakening' 
  | 'Pattern Breaking' 
  | 'Historical Divergence';

export interface PatternIntegrityMetrics {
  referenceMatchPct: number;
  currentMatchPct: number;
  integrityPct: number;
  driftPct: number;
  patternStability: number;
  status: PatternIntegrityStatus;
}

export type WinLossResultAlignment =
  | 'Closer To Winning Structure'
  | 'Closer To Losing Structure'
  | 'Balanced Structure'
  | 'Historical Transition Detected';

export interface WinLossStructureMetrics {
  winningSimilarityPct: number;
  winningSampleSize: number;
  winningWinRatePct: number;
  winningAvgMovePct: number;
  
  losingSimilarityPct: number;
  losingSampleSize: number;
  historicalLossRatePct: number;
  losingAvgDrawdownPct: number;

  referenceMatchPct: number;
  currentMatchPct: number;
  finalResult: WinLossResultAlignment;
}

export type RiskLevel = 'Low' | 'Moderate' | 'High' | 'Extreme';

export interface TradeHealthMetrics {
  tradeHealthPct: number;
  holdingProbability: number;
  reducePositionProbability: number;
  exitProbability: number;
  riskLevel: RiskLevel;
  momentumStrengthPct: number;
  historicalConfidencePct: number;
  aiConfidencePct: number;
  marketStructureQualityPct: number;
}

export interface FutureProjectionMetrics {
  targetProbabilityPct: number;
  stopLossProbabilityPct: number;
  breakoutProbabilityPct: number;
  breakdownProbabilityPct: number;
  sidewaysProbabilityPct: number;
  averageFutureMovePct: number;
  averageDrawdownPct: number;
  expectedDurationCandles: number;
  expectedVolatilityPct: number;
  confidenceInterval: string; // e.g. "95% CI (+4.2% to +8.7%)"
}

export interface PatternEvolutionStep {
  stepLabel: string; // "Reference Pattern", "Candle +1", "Candle +2", "Current Candle"
  candleIndex: number;
  historicalMatchPct: number;
  patternName: string;
  confidencePct: number;
  winRatePct: number;
  lossRatePct: number;
  direction: 'Bullish' | 'Bearish' | 'Neutral';
  transitionNote: string;
}

export type TransitionSpeed = 'Fast' | 'Moderate' | 'Slow';
export type TransitionDirection = 'Increasing' | 'Stable' | 'Decreasing';

export interface TransitionMetrics {
  previousPattern: string;
  currentPattern: string;
  transitionPct: number;
  transitionSpeed: TransitionSpeed;
  transitionDirection: TransitionDirection;
  warnings: string[];
}

export interface HistoricalMatchItem {
  id: string;
  patternName: string;
  historicalMatchPct: number;
  winRatePct: number;
  lossRatePct: number;
  averageMovePct: number;
  sampleSize: number;
  patternScore: number;
  historicalConfidencePct: number;
  date: string;
  asset: string;
  timeframe: string;
  thumbnailPath?: string;
  candles: Candle[];
}

export type DecisionRecommendation = 
  | 'Continue Holding'
  | 'Hold Carefully'
  | 'Reduce Position'
  | 'Exit Trade'
  | 'High Risk'
  | 'Historical Transition Detected';

export interface AIDecisionSummary {
  overallConfidencePct: number;
  tradeQualityPct: number;
  historicalIntegrityPct: number;
  winningSimilarityPct: number;
  losingSimilarityPct: number;
  patternStabilityPct: number;
  historicalConfidencePct: number;
  riskScorePct: number;
  marketStructureScorePct: number;
  tradeHealthPct: number;
  recommendation: DecisionRecommendation;
}

export interface AutoScannerItem {
  id: string;
  symbol: string;
  timeframe: string;
  patternName: string;
  matchPct: number;
  direction: 'Bullish' | 'Bearish' | 'Neutral';
  winRatePct: number;
  avgMovePct: number;
  status: 'STRONG SETUP' | 'DEVELOPING' | 'NEUTRAL' | 'WARNING';
}

export interface AlertItem {
  id: string;
  timestamp: string;
  type: 'MATCH_THRESHOLD' | 'INTEGRITY_DRIFT' | 'DIRECTION_SHIFT' | 'SCANNER_HIT';
  title: string;
  message: string;
  severity: 'info' | 'success' | 'warning' | 'danger';
}

export interface SectionVisibility {
  referencePattern: boolean;
  patternIntegrity: boolean;
  winLossStructure: boolean;
  tradeHealth: boolean;
  futureProjections: boolean;
  evolutionTimeline: boolean;
  liveRanking: boolean;
  transitionDetector: boolean;
  matchGallery: boolean;
  aiDecision: boolean;
  candleInspector: boolean;
}

// ==========================================
// Demo Trading & Journal Types
// ==========================================

export interface DemoPosition {
  id: string;
  asset: string;
  type: 'LONG' | 'SHORT';
  entryPrice: number;
  size: number;
  openTime: string;
}

export interface DemoTrade {
  id: string;
  asset: string;
  type: 'LONG' | 'SHORT';
  entryPrice: number;
  exitPrice: number;
  size: number;
  pnl: number;
  openTime: string;
  closeTime: string;
}

// ==========================================
// Kotak Neo Live Trading & Terminal Types
// ==========================================

export type LiveOrderType = 'MARKET' | 'LIMIT' | 'SL' | 'SL-M';
export type LiveProductType = 'MIS' | 'CNC' | 'NRML';
export type LiveOrderSide = 'BUY' | 'SELL';
export type LiveOrderStatus = 'COMPLETE' | 'PENDING' | 'REJECTED' | 'CANCELLED';

export interface LiveOrder {
  orderId: string;
  symbol: string;
  side: LiveOrderSide;
  orderType: LiveOrderType;
  product: LiveProductType;
  qty: number;
  price: number;
  triggerPrice?: number;
  stopLoss?: number;
  target?: number;
  status: LiveOrderStatus;
  placedTime: string;
  exchange: string;
  rejectionReason?: string;
  isDemat?: boolean;
}

export interface LivePosition {
  positionId: string;
  symbol: string;
  product: LiveProductType;
  side: LiveOrderSide;
  qty: number;
  entryPrice: number;
  currentPrice: number;
  unrealizedPnl: number;
  realizedPnl: number;
  openTime: string;
  isDemat?: boolean;
}

export interface MatchCriteriaSettings {
  minMatchPct: number; // Minimum match percentage required (e.g. 70%)
  indicators: {
    rsi: boolean;
    movingAvg: boolean;
    volume: boolean;
    macd: boolean;
    bbands: boolean;
    atr: boolean;
  };
  weights: {
    priceAction: number;
    rsi: number;
    movingAvg: number;
    volume: number;
    macd: number;
    bbands: number;
    atr: number;
  };
}

export const DEFAULT_MATCH_CRITERIA: MatchCriteriaSettings = {
  minMatchPct: 70,
  indicators: {
    rsi: true,
    movingAvg: true,
    volume: true,
    macd: true,
    bbands: true,
    atr: true
  },
  weights: {
    priceAction: 30,
    rsi: 15,
    movingAvg: 20,
    volume: 15,
    macd: 10,
    bbands: 5,
    atr: 5
  }
};

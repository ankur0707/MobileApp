const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const cors = require('cors');
const axios = require('axios');
// Duplicate imports removed – kept original imports above
const kotakNeoService = require('./kotakNeoService');
const indicatorsRouter = require('./routes/indicators');

const app = express();
app.use(cors());
app.use(express.json());
app.use('/api/indicators', indicatorsRouter);

// Direct Download endpoint for full code ZIP
app.get('/download', (req, res) => {
  const zipPath = 'C:\\Users\\Dell\\Desktop\\Trading-AI-Pattern-Analyzer-FullCode.zip';
  res.download(zipPath, 'Trading-AI-Pattern-Analyzer-FullCode.zip');
});

const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST']
  }
});

const PORT = 4000;

// Kotak Neo Authentication & Settings Endpoint
app.post('/api/kotak/auth', async (req, res) => {
  const { consumerKey, consumerSecret, token, mobileNumber, ucc } = req.body || {};
  console.log('[Kotak API] Received credentials update for Consumer Key:', consumerKey);
  
  kotakNeoService.saveConfig({
    consumerKey,
    consumerSecret,
    token,
    mobileNumber,
    ucc
  });

  await kotakNeoService.validateConnection();
  const status = await kotakNeoService.getFullStatus();
  res.json(status);
});

// Kotak Neo 2FA TOTP Login (Official Demat Session)
app.post('/api/kotak/login-totp', async (req, res) => {
  const { consumerKey, mobile, ucc, totp, mpin } = req.body || {};
  console.log(`[Kotak API] 2FA Demat Login requested for Client ID / UCC: ${ucc}`);
  try {
    const result = await kotakNeoService.loginTotp({ consumerKey, mobile, ucc, totp, mpin });
    res.json(result);
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Kotak Neo Live Connection Status
app.get('/api/kotak/status', async (req, res) => {
  try {
    const status = await kotakNeoService.getFullStatus();
    res.json(status);
  } catch (err) {
    res.json(kotakNeoService.getStatus());
  }
});

// Kotak Neo Disconnect Endpoint
app.post('/api/kotak/disconnect', async (req, res) => {
  console.log('[Kotak API] Disconnect requested');
  const result = await kotakNeoService.disconnect();
  res.json(result);
});

// Kotak Neo Order Placement (Supports REAL_DEMAT and PAPER)
app.post('/api/kotak/order', async (req, res) => {
  const { mode, symbol, side, orderType, product, qty, price, triggerPrice, stopLoss, target } = req.body || {};
  
  if (mode === 'REAL_DEMAT') {
    console.log(`[Kotak API] 🔴 REAL DEMAT Order: ${side} ${qty} ${symbol} @ ₹${price} (${orderType} / ${product})`);
    try {
      const result = await kotakNeoService.placeDematOrder({ symbol, side, orderType, product, qty, price, triggerPrice, stopLoss, target });
      return res.json(result);
    } catch (err) {
      return res.status(500).json({ success: false, dematExecuted: false, error: err.message });
    }
  }

  // Default: Virtual Paper Trade
  console.log(`[Kotak API] 🟢 VIRTUAL PAPER Order: ${side} ${qty} ${symbol} @ ₹${price} (${orderType} / ${product})`);
  const result = kotakNeoService.placeOrder({ symbol, side, orderType, product, qty, price, triggerPrice, stopLoss, target });
  res.json(result);
});

// Kotak Neo Active Positions
app.get('/api/kotak/positions', async (req, res) => {
  const localPositions = kotakNeoService.getPositions();
  if (kotakNeoService.dematAuthenticated) {
    try {
      const dematRes = await kotakNeoService.getDematPositions();
      const rawPositions = dematRes?.positions || [];
      if (rawPositions.length > 0) {
        const mapped = rawPositions.map(p => ({
          positionId: 'DEMAT-' + (p.tok || Math.random().toString(36).substring(2, 8)),
          symbol: p.sym || p.trdSym?.replace('-EQ', '') || 'STOCK',
          product: p.prod || 'MIS',
          side: Number(p.netQty || p.flBuyQty || 0) >= 0 ? 'BUY' : 'SELL',
          qty: Math.abs(Number(p.netQty || p.flBuyQty || 1)),
          entryPrice: Number(p.buyAvgPrc || p.avgPrc || 0),
          currentPrice: Number(p.ltp || p.buyAvgPrc || 0),
          unrealizedPnl: Number(p.urmtom || 0),
          realizedPnl: Number(p.rpnl || 0),
          isDemat: true
        }));
        return res.json({ positions: mapped });
      }
    } catch (e) {
      console.warn('[Positions] Demat fetch error:', e.message);
    }
  }
  res.json({ positions: localPositions });
});

// Kotak Neo Square-Off / Exit Position
app.post('/api/kotak/exit-position', (req, res) => {
  const { positionId } = req.body || {};
  console.log(`[Kotak API] Square-off position: ${positionId}`);
  const result = kotakNeoService.exitPosition(positionId);
  res.json(result);
});

// Kotak Neo Order Book (Merges Live Demat Orders from Kotak)
app.get('/api/kotak/orders', async (req, res) => {
  const localOrders = kotakNeoService.getOrders();
  try {
    const status = await kotakNeoService.getFullStatus();
    if (status.dematAuthenticated) {
      const dematRes = await kotakNeoService.getDematOrders();
      const rawOrders = dematRes?.orders || [];
      if (rawOrders.length > 0) {
        const dematOrders = rawOrders.map(o => ({
          orderId: String(o.nOrdNo || o.orderId || 'ORD'),
          symbol: o.sym || o.trdSym?.replace('-EQ', '') || 'STOCK',
          side: o.trnsTp === 'B' ? 'BUY' : 'SELL',
          orderType: o.prcTp === 'MKT' ? 'MARKET' : 'LIMIT',
          product: o.prod || 'CNC',
          qty: Number(o.qty || 1),
          price: Number(o.prc || 0),
          status: (o.ordSt || o.stat || 'COMPLETE').toUpperCase(),
          placedTime: o.ordDtTm?.split(' ')[1] || new Date().toLocaleTimeString(),
          exchange: o.exSeg?.toUpperCase().includes('FO') ? 'NFO' : 'NSE',
          isDemat: true,
          rejectionReason: o.rejRsn || o.rejLongDesc || null
        }));
        const existingIds = new Set(dematOrders.map(d => d.orderId));
        const merged = [...dematOrders, ...localOrders.filter(l => !existingIds.has(l.orderId))];
        return res.json({ orders: merged });
      }
    }
  } catch (e) {
    console.warn('[Orders] Demat fetch error:', e.message);
  }
  res.json({ orders: localOrders });
});

// Market Status Endpoint for any symbol
app.get('/api/market-status', (req, res) => {
  const symbol = req.query.symbol || 'NIFTY 50';
  const asset = kotakNeoService.findAsset(symbol);
  const status = kotakNeoService.getMarketStatus(asset.exchange, asset.symbol);
  const cachedQuote = kotakNeoService.quotesCache[asset.symbol] || null;
  res.json({
    ...status,
    asset: asset.symbol,
    exchange: asset.exchange,
    quote: cachedQuote
  });
});

// Universal Stock & Index Search Endpoint (Direct Kotak Neo Live Scrip Search)
app.get('/api/kotak/search', async (req, res) => {
  const query = (req.query.q || '').trim();
  const category = req.query.category || 'All';
  const localResults = kotakNeoService.searchCatalog(query, category);

  // If search query is provided, query Kotak Neo's full NSE exchange master
  if (query.length >= 2) {
    try {
      const scripRes = await kotakNeoService.searchScrip(query);
      const scripItems = scripRes?.results || [];
      if (scripItems.length > 0) {
        const existingSyms = new Set(localResults.map(r => r.symbol.toUpperCase()));
        const uniqueItems = scripItems
          .filter(item => !existingSyms.has(item.symbol.toUpperCase()))
          .map(item => ({
            symbol: item.symbol,
            name: item.name,
            exchange: item.exchange || 'NSE',
            category: 'NSE Equity',
            yahooSym: `${item.symbol}.NS`,
            instrumentToken: item.token
          }));
        return res.json([...localResults, ...uniqueItems].slice(0, 50));
      }
    } catch (e) {
      console.warn('[Search] Scrip search error:', e.message);
    }
  }

  res.json(localResults);
});

// REST: Historical Data Endpoint (Backed by Kotak Neo Engine)
app.get('/api/historical', async (req, res) => {
  const asset = req.query.symbol || 'NIFTY 50';
  const interval = req.query.interval || '5m';
  const range = req.query.range || '1y';
  console.log(`[REST] Requesting historical for: ${asset} (${interval}, range: ${range})`);
  
  try {
    const data = await kotakNeoService.fetchHistoricalCandles(asset, interval, range);
    res.json(data);
  } catch (err) {
    console.error(`Error fetching historical for ${asset}:`, err.message);
    res.status(500).json({ error: 'Failed to fetch historical candles' });
  }
});

// Real-Time Live Ticker Manager
let currentSymbol = 'NIFTY 50';
let activeCandlesMap = {};

function getActiveCandle(symbol) {
  if (!activeCandlesMap[symbol]) {
    const assetMeta = kotakNeoService.findAsset(symbol);
    const cached = kotakNeoService.quotesCache[symbol];
    const lastCandle = cached?.lastCandle;
    const base = cached?.officialClose || (symbol.includes('NIFTY') ? 23897.70 : symbol.includes('BANK') ? 57369.65 : symbol.includes('BTC') ? 79600 : 1500);

    activeCandlesMap[symbol] = {
      index: lastCandle?.index || 100,
      time: lastCandle?.time || new Date().toISOString(),
      open: lastCandle?.open || base,
      high: lastCandle?.high || base,
      low: lastCandle?.low || base,
      close: base,
      volume: lastCandle?.volume || 1200,
      body: 0,
      bodyPct: 50,
      upperWick: 1,
      lowerWick: 1,
      wickPct: 50,
      isBullish: true,
      ema20: Number((base * 0.998).toFixed(2)),
      ema50: Number((base * 0.995).toFixed(2)),
      ema200: Number((base * 0.985).toFixed(2)),
      rsi: 54,
      macd: { macdLine: 1.2, signalLine: 0.8, histogram: 0.4 },
      atr: Number((base * 0.003).toFixed(2))
    };
  }
  return activeCandlesMap[symbol];
}

// Refresh real anchor price from market feed every 15 seconds
setInterval(async () => {
  try {
    const asset = kotakNeoService.findAsset(currentSymbol);
    const mStatus = kotakNeoService.getMarketStatus(asset.exchange, asset.symbol);
    
    // If market is closed, just fetch official close once and do not fluctuate
    const res = await axios.get(`https://query1.finance.yahoo.com/v8/finance/chart/${asset.yahooSym}?interval=1m&range=1d`, {
      headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)' },
      timeout: 4000
    });
    const realPrice = res.data?.chart?.result?.[0]?.meta?.regularMarketPrice;
    if (realPrice && activeCandlesMap[currentSymbol]) {
      const c = activeCandlesMap[currentSymbol];
      c.close = Number(realPrice.toFixed(2));
      if (mStatus.isOpen) {
        c.high = Number(Math.max(c.high, c.close).toFixed(2));
        c.low = Number(Math.min(c.low, c.close).toFixed(2));
      }
    }
  } catch (e) {
    // silently continue
  }
}, 15000);

// Broadcast Live Market Ticks Every 600ms (Respects Market Hours!)
setInterval(() => {
  const asset = kotakNeoService.findAsset(currentSymbol);
  const mStatus = kotakNeoService.getMarketStatus(asset.exchange, asset.symbol);
  const c = getActiveCandle(currentSymbol);

  // If market is closed (e.g. Indian Market at night):
  // DO NOT simulate fake random price drift!
  // Lock price to exact official close and broadcast status!
  if (!mStatus.isOpen) {
    const cached = kotakNeoService.quotesCache[currentSymbol];
    if (cached?.officialClose) {
      c.close = cached.officialClose;
    }

    io.emit('live_candle', {
      ...c,
      asset: currentSymbol,
      isMarketOpen: false,
      marketStatus: mStatus.statusText,
      session: mStatus.session,
      officialClose: c.close,
      isFinal: true
    });
    return;
  }

  // If market IS OPEN (e.g. 9:15 AM - 3:30 PM IST weekdays, or Crypto 24/7):
  const volatility = c.close * 0.0003;
  const delta = (Math.random() - 0.49) * volatility;
  const newClose = Number((c.close + delta).toFixed(2));
  
  c.close = newClose;
  c.high = Number(Math.max(c.high, newClose).toFixed(2));
  c.low = Number(Math.min(c.low, newClose).toFixed(2));
  c.volume += Math.floor(50 + Math.random() * 150);
  c.isBullish = c.close >= c.open;
  c.body = Number(Math.abs(c.close - c.open).toFixed(2));
  
  const range = Math.max(0.01, c.high - c.low);
  c.bodyPct = Math.round((c.body / range) * 100);
  c.upperWick = Number((c.high - Math.max(c.open, c.close)).toFixed(2));
  c.lowerWick = Number((Math.min(c.open, c.close) - c.low).toFixed(2));
  c.wickPct = Math.round(((c.upperWick + c.lowerWick) / range) * 100);

  // Check if candle minute has elapsed
  const candleTime = new Date(c.time).getTime();
  const now = Date.now();
  if (now - candleTime >= 60000) {
    const nextTime = new Date();
    nextTime.setSeconds(0, 0);
    activeCandlesMap[currentSymbol] = {
      ...c,
      index: c.index + 1,
      time: nextTime.toISOString(),
      open: c.close,
      high: c.close,
      low: c.close,
      volume: 100
    };
  }

  // Emit to all connected React clients
  io.emit('live_candle', {
    ...c,
    asset: currentSymbol,
    isMarketOpen: true,
    marketStatus: mStatus.statusText,
    session: mStatus.session,
    isFinal: false
  });
}, 600);

// WebSocket connection handling
io.on('connection', (socket) => {
  console.log(`[Socket] React Client connected: ${socket.id}`);
  
  const asset = kotakNeoService.findAsset(currentSymbol);
  const mStatus = kotakNeoService.getMarketStatus(asset.exchange, asset.symbol);
  const c = getActiveCandle(currentSymbol);

  socket.emit('live_candle', {
    ...c,
    asset: currentSymbol,
    isMarketOpen: mStatus.isOpen,
    marketStatus: mStatus.statusText,
    session: mStatus.session,
    isFinal: !mStatus.isOpen
  });

  // Handle client asset switch
  socket.on('subscribe_symbol', (data) => {
    if (data && data.symbol) {
      console.log(`[Socket] Switching active symbol to: ${data.symbol}`);
      currentSymbol = data.symbol;
      const a = kotakNeoService.findAsset(currentSymbol);
      const ms = kotakNeoService.getMarketStatus(a.exchange, a.symbol);
      const updated = getActiveCandle(currentSymbol);
      
      socket.emit('live_candle', {
        ...updated,
        asset: currentSymbol,
        isMarketOpen: ms.isOpen,
        marketStatus: ms.statusText,
        session: ms.session,
        isFinal: !ms.isOpen
      });
    }
  });

  socket.on('disconnect', () => {
    console.log(`[Socket] Client disconnected: ${socket.id}`);
  });
});

server.listen(PORT, () => {
  console.log(`Backend Server running on http://localhost:${PORT}`);
  console.log(`Kotak Neo Engine active | Current symbol: ${currentSymbol}`);
});

# Kotak Neo Python Bridge for Real Demat Trading
import sys
import json
import os
import socket

# Enforce IPv4 for all outbound connections so Kotak Neo always sees the consistent whitelisted IPv4 address
_original_getaddrinfo = socket.getaddrinfo
def _getaddrinfo_ipv4(host, port, family=0, type=0, proto=0, flags=0):
    return _original_getaddrinfo(host, port, socket.AF_INET, type, proto, flags)
socket.getaddrinfo = _getaddrinfo_ipv4

CONFIG_PATH = os.path.join(os.path.dirname(__file__), 'kotak_config.json')
SESSION_PATH = os.path.join(os.path.dirname(__file__), 'kotak_session.json')

def load_session():
    if os.path.exists(SESSION_PATH):
        try:
            with open(SESSION_PATH, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception:
            pass
    return {}

def save_session(data):
    try:
        with open(SESSION_PATH, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2)
    except Exception as e:
        print(f'Error saving session: {e}', file=sys.stderr)

def delete_session():
    try:
        if os.path.exists(SESSION_PATH):
            os.remove(SESSION_PATH)
        return True
    except Exception as e:
        print(f'Error deleting session: {e}', file=sys.stderr)
        return False

def is_market_open_now():
    try:
        from datetime import datetime, timezone, timedelta
        ist_offset = timezone(timedelta(hours=5, minutes=30))
        now = datetime.now(ist_offset)
        # Saturday = 5, Sunday = 6
        if now.weekday() >= 5:
            return False
        minutes = now.hour * 60 + now.minute
        # 9:15 AM to 3:30 PM IST (555 to 930)
        return 555 <= minutes <= 930
    except Exception:
        return False

def get_authenticated_client():
    from neo_api_client import NeoAPI
    session = load_session()
    consumer_key = session.get('consumer_key') or os.environ.get('KOTAK_CONSUMER_KEY', 'test')
    client = NeoAPI(environment='prod', consumer_key=consumer_key)
    
    token = session.get('bearer_token') or session.get('edit_token') or session.get('token')
    if token:
        sid = session.get('sid', '')
        client.configuration.bearer_token = token
        client.configuration.edit_token = session.get('edit_token', token)
        client.configuration.view_token = session.get('view_token', token)
        client.configuration.sid = sid
        client.configuration.edit_sid = session.get('edit_sid', sid)
        client.configuration.base_url = session.get('base_url', 'https://e22.kotaksecurities.com')
        client.configuration.data_center = session.get('data_center', 'E22')
        client.configuration.ucc = session.get('ucc', '')
        return client, True
    return client, False

def handle_status():
    session = load_session()
    has_session = bool(session.get('bearer_token') or session.get('edit_token') or session.get('token'))
    ucc = session.get('ucc', '')
    res = {
        'authenticated': has_session,
        'ucc': ucc,
        'consumer_key': session.get('consumer_key', ''),
        'has_token': has_session
    }
    print(json.dumps(res))

def handle_login_totp(payload):
    from neo_api_client import NeoAPI
    consumer_key = payload.get('consumer_key', '').strip()
    mobile = payload.get('mobile', '').strip()
    if mobile and not mobile.startswith('+'):
        digits = ''.join(c for c in mobile if c.isdigit())
        if len(digits) == 10:
            mobile = f'+91{digits}'
        elif len(digits) == 12 and digits.startswith('91'):
            mobile = f'+{digits}'
        else:
            mobile = f'+91{digits}'
    ucc = payload.get('ucc', '').strip()
    totp = payload.get('totp', '').strip()
    mpin = payload.get('mpin', '').strip()

    if not consumer_key or not mobile or not ucc or not totp or not mpin:
        print(json.dumps({'success': False, 'error': 'Consumer Key, Mobile, UCC, TOTP, and MPIN are all required'}))
        return

    try:
        client = NeoAPI(environment='prod', consumer_key=consumer_key)
        login_res = client.totp_login(mobile_number=mobile, ucc=ucc, totp=totp)
        if isinstance(login_res, dict) and login_res.get('error'):
            errs = login_res.get('error')
            errMsg = errs[0].get('message') if isinstance(errs, list) and len(errs) > 0 else str(login_res)
            print(json.dumps({'success': False, 'error': f'Kotak 2FA Login Error: {errMsg}'}))
            return

        val_res = client.totp_validate(mpin=mpin)
        if isinstance(val_res, dict) and val_res.get('error'):
            errs = val_res.get('error')
            errMsg = errs[0].get('message') if isinstance(errs, list) and len(errs) > 0 else str(val_res)
            print(json.dumps({'success': False, 'error': f'Kotak MPIN Validate Error: {errMsg}'}))
            return

        # Extract token from validate response or client configuration
        token = None
        if isinstance(val_res, dict):
            val_data = val_res.get('data', {}) if isinstance(val_res.get('data'), dict) else {}
            token = val_data.get('token') or val_res.get('token')
        if not token:
            token = (
                getattr(client.configuration, 'edit_token', None)
                or getattr(client.configuration, 'bearer_token', None)
                or getattr(client.configuration, 'view_token', None)
            )
        if not token and isinstance(login_res, dict):
            login_data = login_res.get('data', {}) if isinstance(login_res.get('data'), dict) else {}
            token = login_data.get('token') or login_res.get('token')

        if not token:
            print(json.dumps({'success': False, 'error': f'Kotak Neo response did not contain token: {val_res}'}))
            return

        client.configuration.bearer_token = token
        client.configuration.edit_token = token

        sid = getattr(client.configuration, 'edit_sid', None) or getattr(client.configuration, 'sid', '')
        base_url = getattr(client.configuration, 'base_url', 'https://e22.kotaksecurities.com')
        data_center = getattr(client.configuration, 'data_center', 'E22')

        session_data = {
            'consumer_key': consumer_key,
            'mobile': mobile,
            'ucc': ucc,
            'bearer_token': token,
            'edit_token': token,
            'view_token': getattr(client.configuration, 'view_token', token),
            'sid': sid,
            'edit_sid': sid,
            'base_url': base_url,
            'data_center': data_center,
            'updated_at': str(val_res)
        }
        save_session(session_data)
        print(json.dumps({'success': True, 'message': 'Kotak Neo 2FA Authenticated Successfully! Demat Active.', 'ucc': ucc}))
    except Exception as e:
        print(json.dumps({'success': False, 'error': str(e)}))

def handle_place_order(payload):
    client, is_auth = get_authenticated_client()
    if not is_auth:
        print(json.dumps({
            'success': False,
            'dematExecuted': False,
            'error': 'Kotak Neo Demat account not logged in. Please complete TOTP / MPIN login in API Settings to place real orders in your Demat account.'
        }))
        return

    symbol = payload.get('symbol', 'RELIANCE')
    side = payload.get('side', 'BUY')
    order_type = payload.get('orderType', 'MARKET')
    product = payload.get('product', 'MIS')
    qty = str(int(payload.get('qty', 1)))
    price = str(payload.get('price', 0))
    trigger_price = str(payload.get('triggerPrice', 0))

    # Market timings & AMO detection
    market_open = is_market_open_now()
    amo = payload.get('amo') or ('NO' if market_open else 'YES')

    exchange_segment = 'nse_cm'
    if 'NIFTY' in symbol or 'BANK' in symbol:
        exchange_segment = 'nse_fo'

    if symbol.endswith('-EQ') or symbol.endswith('-INDEX'):
        trading_symbol = symbol
    elif 'NIFTY' in symbol or 'BANK' in symbol:
        trading_symbol = symbol
    else:
        trading_symbol = f'{symbol}-EQ'

    trns_tp = 'B' if side == 'BUY' else 'S'
    kotak_ord_type = 'MKT' if order_type == 'MARKET' else ('L' if order_type == 'LIMIT' else order_type)
    ord_price = '0' if order_type == 'MARKET' else price
    if kotak_ord_type in ['MKT', 'SL-M']:
        ord_price = '0'

    try:
        res = client.place_order(
            exchange_segment=exchange_segment,
            product=product,
            price=ord_price,
            order_type=kotak_ord_type,
            quantity=qty,
            validity='DAY',
            trading_symbol=trading_symbol,
            transaction_type=trns_tp,
            amo=amo,
            trigger_price=trigger_price if kotak_ord_type in ['SL', 'SL-M'] else '0'
        )
        
        # Check all possible error shapes from Kotak Neo SDK
        if isinstance(res, dict):
            if 'Error Message' in res:
                print(json.dumps({'success': False, 'dematExecuted': False, 'error': res['Error Message'], 'response': res}))
                return
            if 'Error' in res:
                print(json.dumps({'success': False, 'dematExecuted': False, 'error': str(res['Error']), 'response': res}))
                return
            if res.get('stat') == 'Not_Ok' or res.get('status') == 'error':
                errMsg = res.get('errMsg') or res.get('message') or res.get('desc') or 'Order rejected by Kotak Neo'
                print(json.dumps({'success': False, 'dematExecuted': False, 'error': errMsg, 'response': res}))
                return
            if res.get('error'):
                errs = res.get('error')
                errMsg = errs[0].get('message') if isinstance(errs, list) and len(errs) > 0 else str(res['error'])
                print(json.dumps({'success': False, 'dematExecuted': False, 'error': errMsg, 'response': res}))
                return

        order_id = ''
        if isinstance(res, dict):
            order_id = res.get('nOrdNo') or res.get('order_id') or res.get('orderId') or ''
        
        if not order_id and isinstance(res, dict) and res.get('stat') != 'Ok':
            errMsg = res.get('errMsg') or f'Order rejected: {res}'
            print(json.dumps({'success': False, 'dematExecuted': False, 'error': errMsg, 'response': res}))
            return

        print(json.dumps({
            'success': True,
            'dematExecuted': True,
            'orderId': order_id,
            'isAmo': amo == 'YES',
            'response': res
        }))
    except Exception as e:
        print(json.dumps({'success': False, 'dematExecuted': False, 'error': str(e)}))

def handle_get_positions():
    client, is_auth = get_authenticated_client()
    if not is_auth:
        print(json.dumps({'positions': []}))
        return
    try:
        res = client.positions()
        print(json.dumps({'positions': res.get('data', []) if isinstance(res, dict) else []}))
    except Exception as e:
        print(json.dumps({'positions': [], 'error': str(e)}))

def handle_get_orders():
    client, is_auth = get_authenticated_client()
    if not is_auth:
        print(json.dumps({'orders': []}))
        return
    try:
        res = client.order_report()
        print(json.dumps({'orders': res.get('data', []) if isinstance(res, dict) else []}))
    except Exception as e:
        print(json.dumps({'orders': [], 'error': str(e)}))

def handle_analyze_pattern_data(payload):
    """Analyze historical candles for given pattern and compute weighted indicators.
    Expected payload keys: symbol, pattern, percentage, indicators (list), weights (dict).
    For demo purposes this returns mock indicator values and a weighted score.
    """
    import random
    symbol = payload.get('symbol')
    pattern = payload.get('pattern')
    percentage = payload.get('percentage', 100)
    indicators = payload.get('indicators', [])
    weights = payload.get('weights', {})
    # Mock: generate random values for requested indicators
    indicator_values = {}
    total_score = 0.0
    for ind in indicators:
        val = round(random.uniform(0, 100), 2)
        weight = float(weights.get(ind, 1))
        indicator_values[ind] = val
        total_score += val * weight
    result = {
        'symbol': symbol,
        'pattern': pattern,
        'percentage': percentage,
        'indicatorValues': indicator_values,
        'combinedScore': round(total_score, 2)
    }
    print(json.dumps(result))



def handle_disconnect():
    delete_session()
    print(json.dumps({'success': True, 'message': 'Disconnected'}))

def handle_search_scrip(payload):
    client, is_auth = get_authenticated_client()
    symbol = payload.get('symbol', '').strip().upper()
    exchange_segment = payload.get('exchange_segment', 'nse_cm')
    if not symbol:
        print(json.dumps({'results': []}))
        return
    try:
        results = client.search_scrip(exchange_segment=exchange_segment, symbol=symbol)
        cleaned = []
        if isinstance(results, list):
            for r in results[:40]:
                sym = r.get('pSymbolName') or r.get('pTrdSymbol', '').replace('-EQ', '')
                cleaned.append({
                    'symbol': sym,
                    'tradingSymbol': r.get('pTrdSymbol', ''),
                    'name': r.get('pDesc', sym),
                    'exchange': r.get('pExchange', 'NSE'),
                    'token': str(r.get('pSymbol', '')),
                    'lotSize': r.get('lLotSize', 1),
                    'tickSize': r.get('dTickSize', 0.05) / 100 if r.get('dTickSize') else 0.05,
                    'category': 'Stock'
                })
        print(json.dumps({'results': cleaned}))
    except Exception as e:
        print(json.dumps({'results': [], 'error': str(e)}))

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print(json.dumps({'error': 'No action provided'}))
        sys.exit(1)
    
    action = sys.argv[1]
    payload = {}

    # Read JSON payload from sys.argv[2] first if provided
    if len(sys.argv) > 2:
        try:
            payload = json.loads(sys.argv[2])
        except Exception:
            payload = {}

    # Otherwise read from stdin only if action needs payload
    if not payload and action in ['login_totp', 'place_order', 'analyze_pattern_data', 'search_scrip']:
        try:
            stdin_data = sys.stdin.read().strip()
            if stdin_data:
                payload = json.loads(stdin_data)
        except Exception:
            pass

    if action == 'status':
        handle_status()
    elif action == 'login_totp':
        handle_login_totp(payload)
    elif action == 'place_order':
        handle_place_order(payload)
    elif action == 'positions':
        handle_get_positions()
    elif action == 'orders':
        handle_get_orders()
    elif action == 'disconnect':
        handle_disconnect()
    elif action == 'analyze_pattern_data':
        handle_analyze_pattern_data(payload)
    elif action == 'search_scrip':
        handle_search_scrip(payload)
    else:
        print(json.dumps({'error': f'Unknown action: {action}'}))

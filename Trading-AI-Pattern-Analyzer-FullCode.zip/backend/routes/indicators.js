// routes/indicators.js
const express = require('express');
const router = express.Router();
const kotakService = require('../kotakNeoService');

// 1️⃣ List available indicators (1‑9)
const AVAILABLE_INDICATORS = [
  { id: 'volume', name: 'Volume', description: 'Trading volume for the candle' },
  { id: 'rsi', name: 'RSI', description: 'Relative Strength Index (0‑100)' },
  { id: 'sma', name: 'SMA', description: 'Simple Moving Average' },
  { id: 'ema', name: 'EMA', description: 'Exponential Moving Average' },
  { id: 'atr', name: 'ATR', description: 'Average True Range – volatility measure' },
  { id: 'macd', name: 'MACD', description: 'Moving Average Convergence Divergence' },
  { id: 'bollinger', name: 'Bollinger Bands', description: 'Price bands based on SMA ± 2σ' },
  { id: 'stochastic', name: 'Stochastic Oscillator', description: 'Momentum indicator ( %K / %D )' },
  { id: 'adx', name: 'ADX', description: 'Average Directional Index – trend strength' }
];

// GET /api/broker/indicators – returns list for UI selection
router.get('/indicators', (req, res) => {
  res.json({ success: true, indicators: AVAILABLE_INDICATORS });
});

/**
 * POST /api/broker/analyze
 * Body: {
 *   symbol: string,
 *   pattern: string,
 *   percentage: number,   // 0‑100 of matches to return
 *   indicators: string[], // subset of ids from AVAILABLE_INDICATORS
 *   weights: { [id]: number } // optional weight per indicator (default 1)
 * }
 */
router.post('/analyze', async (req, res) => {
  const { symbol, pattern, percentage, indicators, weights } = req.body || {};

  // Basic validation
  if (!symbol || !pattern || typeof percentage !== 'number' || !Array.isArray(indicators)) {
    return res.status(400).json({ success: false, error: 'Missing or invalid parameters' });
  }
  if (percentage < 0 || percentage > 100) {
    return res.status(400).json({ success: false, error: 'percentage must be between 0 and 100' });
  }
  // Ensure requested indicators exist
  const unknown = indicators.filter(i => !AVAILABLE_INDICATORS.some(a => a.id === i));
  if (unknown.length) {
    return res.status(400).json({ success: false, error: `Unknown indicators: ${unknown.join(', ')}` });
  }

  try {
    const result = await kotakService.analyzePatternData({ symbol, pattern, percentage, indicators, weights });
    res.json(result);
  } catch (err) {
    console.error('[Broker Analyze] Error:', err);
    res.status(500).json({ success: false, error: err.message });
  }
});

module.exports = router;
